import { NextRequest, NextResponse } from 'next/server';
import { adminAuth } from '@/src/lib/firebase-admin';
import { getUserFullState, saveUserFullState } from '@/src/db/repository';
import { validateImportPayload } from '@/src/lib/logic/quality-gate';

async function verifyBearerUser(req: NextRequest) {
  const authHeader = req.headers.get('authorization');
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return null;
  }
  const token = authHeader.split('Bearer ')[1];
  try {
    return await adminAuth.verifyIdToken(token);
  } catch (error) {
    console.error('Error verifying Firebase ID token:', error);
    return null;
  }
}

export async function GET(req: NextRequest) {
  const decoded = await verifyBearerUser(req);
  if (!decoded) {
    return NextResponse.json(
      { error: 'Unauthorized: Missing or invalid token' },
      { status: 401, headers: { 'Cache-Control': 'no-store' } }
    );
  }

  try {
    const state = await getUserFullState(decoded.uid, decoded.email || '');
    return NextResponse.json(
      { synced: true, state },
      { headers: { 'Cache-Control': 'no-store' } }
    );
  } catch (error: unknown) {
    const message =
      error instanceof Error ? error.message : 'Failed to load state';
    return NextResponse.json(
      { error: message },
      { status: 500, headers: { 'Cache-Control': 'no-store' } }
    );
  }
}

export async function POST(req: NextRequest) {
  const decoded = await verifyBearerUser(req);
  if (!decoded) {
    return NextResponse.json(
      { error: 'Unauthorized: Missing or invalid token' },
      { status: 401, headers: { 'Cache-Control': 'no-store' } }
    );
  }

  try {
    const body = await req.json();

    if (body.action === 'import') {
      const validation = validateImportPayload(body.payload);
      if (!validation.ok) {
        return NextResponse.json(
          { error: validation.errors.join(' ') },
          { status: 400, headers: { 'Cache-Control': 'no-store' } }
        );
      }
      await saveUserFullState(
        decoded.uid,
        decoded.email || '',
        body.payload.tables
      );
      const updated = await getUserFullState(decoded.uid, decoded.email || '');
      return NextResponse.json(
        { ok: true, state: updated },
        { headers: { 'Cache-Control': 'no-store' } }
      );
    }

    if (!body.state) {
      return NextResponse.json(
        { error: 'Missing state payload' },
        { status: 400, headers: { 'Cache-Control': 'no-store' } }
      );
    }

    await saveUserFullState(decoded.uid, decoded.email || '', body.state);
    return NextResponse.json(
      { ok: true },
      { headers: { 'Cache-Control': 'no-store' } }
    );
  } catch (error: unknown) {
    const message =
      error instanceof Error ? error.message : 'Failed to save state';
    return NextResponse.json(
      { error: message },
      { status: 500, headers: { 'Cache-Control': 'no-store' } }
    );
  }
}
