import crypto from 'node:crypto';
import { NextRequest, NextResponse } from 'next/server';

export async function POST(req: NextRequest) {
  try {
    const { token } = await req.json();
    if (!token || typeof token !== 'string') {
      return NextResponse.json(
        { error: 'Missing token' },
        { status: 400, headers: { 'Cache-Control': 'no-store' } }
      );
    }

    const decoded = JSON.parse(
      Buffer.from(token, 'base64url').toString('utf8')
    ) as {
      uid: string;
      rid: string;
      date: string;
      act: 'done' | 'water';
      exp: number;
      sig: string;
    };

    if (Date.now() > decoded.exp) {
      return NextResponse.json(
        { error: 'Token expired' },
        { status: 401, headers: { 'Cache-Control': 'no-store' } }
      );
    }

    const secret = process.env.DONE_LINK_SECRET || 'goalos-default-local-secret';
    const raw = `${decoded.uid}|${decoded.rid}|${decoded.date}|${decoded.act}|${decoded.exp}`;
    const expectedSig = crypto
      .createHmac('sha256', secret)
      .update(raw)
      .digest('hex');

    if (
      decoded.sig.length !== expectedSig.length ||
      !crypto.timingSafeEqual(
        Buffer.from(decoded.sig),
        Buffer.from(expectedSig)
      )
    ) {
      return NextResponse.json(
        { error: 'Invalid token signature' },
        { status: 401, headers: { 'Cache-Control': 'no-store' } }
      );
    }

    return NextResponse.json(
      {
        ok: true,
        routineId: decoded.rid,
        logDate: decoded.date,
        action: decoded.act,
      },
      { headers: { 'Cache-Control': 'no-store' } }
    );
  } catch (error) {
    console.error('Done token verification failed:', error);
    return NextResponse.json(
      { error: 'Invalid request' },
      { status: 400, headers: { 'Cache-Control': 'no-store' } }
    );
  }
}
