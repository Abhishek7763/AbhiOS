import crypto from 'node:crypto';
import { NextRequest, NextResponse } from 'next/server';
import { evaluateReminderTick } from '@/src/lib/logic/tick-logic';
import { nowMinutes, todayLocal } from '@/src/lib/logic/dates';
import { createInitialSeedData } from '@/src/lib/seed-data';

function verifyCronSecret(req: NextRequest): boolean {
  const secret = process.env.CRON_SECRET;
  if (!secret) return false;
  const authHeader = req.headers.get('authorization') || '';
  const expected = `Bearer ${secret}`;
  if (authHeader.length !== expected.length) return false;
  return crypto.timingSafeEqual(
    Buffer.from(authHeader),
    Buffer.from(expected)
  );
}

function signDoneToken(payload: {
  uid: string;
  rid: string;
  date: string;
  act: 'done' | 'water';
  exp: number;
}): string {
  const secret = process.env.DONE_LINK_SECRET || 'goalos-default-local-secret';
  const raw = `${payload.uid}|${payload.rid}|${payload.date}|${payload.act}|${payload.exp}`;
  const sig = crypto.createHmac('sha256', secret).update(raw).digest('hex');
  return Buffer.from(JSON.stringify({ ...payload, sig })).toString('base64url');
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json().catch(() => ({}));

    // Allow either valid CRON_SECRET or client-supplied simulation state for interactive testing
    const isCronAuthorized = verifyCronSecret(req);
    const state = body.state || createInitialSeedData('local-user');

    const tz = state.settings?.timezone || 'Asia/Kolkata';
    const rollover = state.settings?.dayRolloverHour ?? 4;
    const todayDate = body.overrideDate || todayLocal(tz, rollover);
    const currentMin =
      typeof body.overrideNowMin === 'number'
        ? body.overrideNowMin
        : nowMinutes(tz);

    const dayPlan = (state.dayPlans || []).find(
      (dp: { planDate: string }) => dp.planDate === todayDate
    );
    const hasDailyReviewToday = (state.dailyReviews || []).some(
      (dr: { reviewDate: string }) => dr.reviewDate === todayDate
    );

    const evaluation = evaluateReminderTick({
      todayDate,
      nowMin: currentMin,
      settings: state.settings,
      dayPlan,
      routines: state.routines || [],
      routineLogs: state.routineLogs || [],
      reminderSentToday: (state.reminderSent || []).filter(
        (r: { logDate: string }) => r.logDate === todayDate
      ),
      hasDailyReviewToday,
    });

    const exp = Date.now() + 6 * 60 * 60 * 1000;
    const actionTokens =
      evaluation.digestNotification?.actions.map((a) => ({
        ...a,
        token: a.routineId
          ? signDoneToken({
              uid: state.settings?.userId || 'local-user',
              rid: a.routineId,
              date: todayDate,
              act: a.action,
              exp,
            })
          : null,
      })) || [];

    return NextResponse.json(
      {
        authorizedCron: isCronAuthorized,
        todayDate,
        nowMin: currentMin,
        skippedQuietHours: evaluation.skippedQuietHours,
        skippedCapReached: evaluation.skippedCapReached,
        dueCount: evaluation.dueItems.length,
        digestNotification: evaluation.digestNotification
          ? {
              ...evaluation.digestNotification,
              actions: actionTokens,
            }
          : null,
      },
      { headers: { 'Cache-Control': 'no-store' } }
    );
  } catch (error) {
    console.error('Tick route error:', error);
    return NextResponse.json(
      { error: 'Reminder tick evaluation failed' },
      { status: 500, headers: { 'Cache-Control': 'no-store' } }
    );
  }
}
