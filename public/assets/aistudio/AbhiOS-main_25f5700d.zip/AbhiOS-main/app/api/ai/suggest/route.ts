import { GoogleGenAI, Type } from '@google/genai';
import { NextRequest, NextResponse } from 'next/server';
import { AISuggestionDraft, InboxItemType } from '@/src/lib/types';

function isGeminiKeyConfigured(): boolean {
  const key = process.env.GEMINI_API_KEY;
  return Boolean(key && key.trim().length > 5 && key !== 'MY_GEMINI_API_KEY');
}

function getAiClient(): GoogleGenAI {
  return new GoogleGenAI({
    apiKey: process.env.GEMINI_API_KEY,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

/**
 * Deterministic local heuristic fallback when GEMINI_API_KEY is not set or offline,
 * ensuring the user always gets helpful structured drafts.
 */
function buildDeterministicDraft(
  mode: string,
  text: string
): AISuggestionDraft {
  const clean = text.trim();
  const lower = clean.toLowerCase();

  if (mode === 'task_split') {
    const lines = clean
      .split(/\n|;|aur|\band\b/i)
      .map((s) => s.trim())
      .filter((s) => s.length > 3);
    const subItems =
      lines.length >= 2
        ? lines.slice(0, 4)
        : [
            `Step 1 (5 min setup): ${clean.slice(0, 50)} ke liye zaruri cheez kholo`,
            `Step 2 (15 min core): Pehla chhota hissa poora karo`,
            `Step 3 (5 min close): Check karke status update karo`,
          ];
    return {
      refinedTitle: clean.slice(0, 80),
      subItems,
      explanation:
        'Rule-based breakdown: Bade kaam ko 15-minute ke actionable tukdon me baanta gaya hai.',
    };
  }

  if (mode === 'goal_gate_assist') {
    return {
      refinedTitle: clean.slice(0, 90),
      purposeReason:
        'Isse rozमर्रा ki tension kam hogi aur long-term stability milegi.',
      tradeoffs: 'Roz 20-30 minute low-priority phone scrolling kam karni hogi.',
      nextAction: `Aaj 10 minute nikal kar "${clean.slice(0, 40)}" ka pehla basic step note karo`,
      subItems: [
        'Milestone 1: Baseline स्थिति aur zarurat clear karna',
        'Milestone 2: Pehle 2 hafte ka chhota repeatable system set karna',
        'Milestone 3: 30 din baad progress review aur adjustment',
      ],
      explanation:
        'Deterministic Goal Gate helper (AI key configure hone par aur gahra personalized draft milega).',
    };
  }

  let suggestedType: InboxItemType = 'task';
  if (/roz|daily|har din|habit|routine|paani|walk|exercise/i.test(lower)) {
    suggestedType = 'habit_candidate';
  } else if (
    /lac|lakh|fund|ban(a|aa)na|seekhna|weight|career|promotion|6 month|year/i.test(
      lower
    )
  ) {
    suggestedType = 'goal_candidate';
  } else if (/wait|rakesh|bheja|reply|approval|expect/i.test(lower)) {
    suggestedType = 'waiting_for';
  } else if (/idea|experiment|shayad|kaisa rahega|\?/i.test(lower)) {
    suggestedType = 'idea';
  } else if (/someday|baad me kabhi|future/i.test(lower)) {
    suggestedType = 'goal_candidate';
  } else if (clean.includes('\n') || /setup|project|plan/i.test(lower)) {
    suggestedType = 'project';
  }

  const lines = clean
    .split('\n')
    .map((l) => l.trim())
    .filter(Boolean);

  return {
    suggestedType,
    refinedTitle: lines[0]?.slice(0, 100) || clean.slice(0, 100),
    nextAction:
      suggestedType === 'task'
        ? `15 min nikal kar "${lines[0]?.slice(0, 50)}" shuru karo`
        : `Clarify karke tay karein ki abhi active karna hai ya Someday me rakhna hai`,
    estMinutes: 20,
    subItems: lines.length > 1 ? lines : undefined,
    explanation:
      'Deterministic keyword analysis (AI Draft — aap apni marzi se category chunein).',
  };
}

export async function GET() {
  return NextResponse.json(
    { aiAvailable: isGeminiKeyConfigured() },
    { headers: { 'Cache-Control': 'no-store' } }
  );
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const mode = String(body.mode || 'inbox_clarify');
    const text = String(body.text || '').trim();

    if (!text) {
      return NextResponse.json(
        { error: 'Input text is required' },
        { status: 400, headers: { 'Cache-Control': 'no-store' } }
      );
    }

    if (!isGeminiKeyConfigured()) {
      const draft = buildDeterministicDraft(mode, text);
      return NextResponse.json(
        {
          aiAvailable: false,
          aiUsed: false,
          draft,
        },
        { headers: { 'Cache-Control': 'no-store' } }
      );
    }

    const ai = getAiClient();
    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: `Mode: ${mode}\nUser Input: ${text}\nContext: ${JSON.stringify(
        body.context || {}
      )}`,
      config: {
        systemInstruction:
          'You are an assistant inside Abhishek’s Personal Goal OS (V2). ' +
          'Follow strict rules: 1. Output JSON only matching the schema. ' +
          '2. Use natural Hinglish (Hindi in Roman script + English terms). ' +
          '3. Never claim authority over the user’s true motives or impose guilt. ' +
          '4. Keep time estimates realistic and conservative (15-45 mins). ' +
          '5. Classify into one of: task, goal_candidate, project, habit_candidate, reference, idea, concern, waiting_for, duplicate.',
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            suggestedType: {
              type: Type.STRING,
              description:
                'One of: task, goal_candidate, project, habit_candidate, reference, idea, concern, waiting_for, duplicate',
            },
            refinedTitle: {
              type: Type.STRING,
              description: 'Clean, concise title or desired outcome in Hinglish',
            },
            nextAction: {
              type: Type.STRING,
              description:
                'Concrete physical first action the user can start without extra planning',
            },
            estMinutes: {
              type: Type.INTEGER,
              description: 'Conservative estimate in minutes (10 to 60)',
            },
            purposeReason: {
              type: Type.STRING,
              description: 'Optional suggested personal reason reflection',
            },
            tradeoffs: {
              type: Type.STRING,
              description: 'Realistic time/energy trade-off to consider',
            },
            subItems: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description:
                '2 to 4 smaller steps (for task_split or multi-thought split or milestones)',
            },
            explanation: {
              type: Type.STRING,
              description: '1 short sentence in Hinglish explaining this suggestion',
            },
          },
        },
      },
    });

    const rawText = (response.text ?? '{}').trim();
    const parsed = JSON.parse(rawText) as AISuggestionDraft;

    return NextResponse.json(
      {
        aiAvailable: true,
        aiUsed: true,
        draft: parsed,
      },
      { headers: { 'Cache-Control': 'no-store' } }
    );
  } catch (error) {
    console.warn('Gemini suggestion fallback triggered:', error);
    const fallbackBody = await req.clone().json().catch(() => ({}));
    const draft = buildDeterministicDraft(
      String(fallbackBody.mode || 'inbox_clarify'),
      String(fallbackBody.text || '')
    );
    return NextResponse.json(
      {
        aiAvailable: isGeminiKeyConfigured(),
        aiUsed: false,
        draft,
      },
      { headers: { 'Cache-Control': 'no-store' } }
    );
  }
}
