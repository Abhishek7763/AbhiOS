'use client';

import React, { useMemo, useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import {
  Check,
  Pause,
  Plus,
  RotateCcw,
  Scissors,
  Sparkles,
  XCircle,
  Repeat,
  ShieldCheck,
  MoreHorizontal,
  Zap,
} from 'lucide-react';
import { useGoalOs } from '@/src/context/goal-os-context';
import { STRINGS } from '@/src/lib/strings';
import { addDays } from '@/src/lib/logic/dates';
import {
  DEFAULT_RECURRING_TEMPLATES,
  generateTwoMinuteStarter,
  RecurringTaskTemplate,
  suggestIfThenPlan,
} from '@/src/lib/logic/planner';
import { Task, TaskRecurrence } from '@/src/lib/types';
import {
  AnimatedCheckButton,
  playCompletionCelebrationSound,
} from '@/src/components/animated-check-button';

type TaskFilterTab = 'today' | 'upcoming' | 'nodate' | 'done';

export function TasksView() {
  const {
    state,
    today,
    createTask,
    completeTask,
    reopenTask,
    rescheduleTask,
    updateTask,
    splitTaskIntoSubtasks,
    requestAiSuggestion,
  } = useGoalOs();

  const [tab, setTab] = useState<TaskFilterTab>('today');
  const [showAddForm, setShowAddForm] = useState(false);
  const [showRecurringPanel, setShowRecurringPanel] = useState(false);
  const [celebratingTaskId, setCelebratingTaskId] = useState<string | null>(
    null
  );
  const [completingIds, setCompletingIds] = useState<Record<string, boolean>>(
    {}
  );
  const [celebrationBanner, setCelebrationBanner] = useState<string | null>(
    null
  );
  const [expandedMenuTaskId, setExpandedMenuTaskId] = useState<string | null>(
    null
  );

  const handleToggleTaskDone = (task: Task) => {
    if (task.status === 'done') {
      reopenTask(task.id);
      return;
    }
    if (completingIds[task.id]) return;

    playCompletionCelebrationSound();
    setCelebratingTaskId(task.id);
    setCompletingIds((prev) => ({ ...prev, [task.id]: true }));
    setCelebrationBanner(`✓ "${task.title}" pura ho gaya! Shabaash!`);
    setExpandedMenuTaskId(null);

    window.setTimeout(() => {
      setCelebratingTaskId((prev) => (prev === task.id ? null : prev));
    }, 950);

    window.setTimeout(() => {
      setCelebrationBanner((prev) =>
        prev?.includes(task.title) ? null : prev
      );
    }, 2800);

    window.setTimeout(() => {
      completeTask(task.id);
      setCompletingIds((prev) => {
        const next = { ...prev };
        delete next[task.id];
        return next;
      });
    }, 480);
  };

  // Add Task Form State
  const [title, setTitle] = useState('');
  const [nextAction, setNextAction] = useState('');
  const [goalId, setGoalId] = useState('');
  const [milestoneId, setMilestoneId] = useState('');
  const [projectId, setProjectId] = useState('');
  const [estMinutes, setEstMinutes] = useState(25);
  const [scheduledDate, setScheduledDate] = useState(today);
  const [dueDate, setDueDate] = useState('');
  const [recurrence, setRecurrence] = useState<TaskRecurrence>('none');

  // Split Drawer State
  const [splittingTask, setSplittingTask] = useState<Task | null>(null);
  const [splitLines, setSplitLines] = useState('');
  const [aiSplitting, setAiSplitting] = useState(false);

  const filteredTasks = useMemo(() => {
    const list = state.tasks.filter((t) => {
      if (tab === 'done') {
        return (
          t.status === 'done' ||
          t.status === 'cancelled' ||
          t.status === 'paused'
        );
      }
      if (tab === 'today') {
        const isToday =
          t.scheduledDate === today ||
          (t.dueDate && t.dueDate <= today) ||
          (t.status === 'done' && t.completedAt?.startsWith(today));
        return (
          isToday &&
          (t.status === 'todo' || t.status === 'doing' || t.status === 'done')
        );
      }
      if (t.status !== 'todo' && t.status !== 'doing') return false;

      if (tab === 'upcoming') {
        return (
          (t.scheduledDate && t.scheduledDate > today) ||
          (t.dueDate && t.dueDate > today && t.scheduledDate !== today)
        );
      }
      if (tab === 'nodate') {
        return !t.scheduledDate && !t.dueDate;
      }
      return true;
    });
    return list.sort((a, b) => {
      if (a.status === 'done' && b.status !== 'done') return 1;
      if (a.status !== 'done' && b.status === 'done') return -1;
      return 0;
    });
  }, [state.tasks, tab, today]);

  const handleCreateTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;
    createTask({
      title: title.trim(),
      nextAction: nextAction.trim() || title.trim(),
      goalId: goalId || null,
      milestoneId: milestoneId || null,
      projectId: projectId || null,
      estMinutes,
      scheduledDate: scheduledDate || null,
      dueDate: dueDate || null,
      recurrence,
    });
    setTitle('');
    setNextAction('');
    setRecurrence('none');
    setShowAddForm(false);
  };

  const handleSpawnRecurringTemplate = (tpl: RecurringTaskTemplate) => {
    createTask({
      title: tpl.title,
      nextAction: `${tpl.nextAction} · (${tpl.ifThenPlan})`,
      estMinutes: tpl.estMinutes,
      scheduledDate: today,
      dueDate: today,
    });
    setTab('today');
  };

  const handleAiSplit = async (task: Task) => {
    setAiSplitting(true);
    try {
      const { draft } = await requestAiSuggestion('task_split', task.title);
      if (draft.subItems && draft.subItems.length > 0) {
        setSplitLines(draft.subItems.join('\n'));
      }
    } finally {
      setAiSplitting(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header & Add Task Toggle */}
      <section className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 dark:text-slate-100">
            Next Actions & Tasks
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Har task standalone bhi ho sakta hai ya kisi Active Goal / Project se juda.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={() => setShowRecurringPanel((v) => !v)}
            className="min-h-[44px] px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 hover:bg-slate-100 text-slate-700 dark:text-slate-200 text-xs font-semibold flex items-center gap-1.5 whitespace-nowrap shrink-0"
          >
            <Repeat className="w-3.5 h-3.5 text-teal-600" />
            Recurring Templates ({DEFAULT_RECURRING_TEMPLATES.length})
          </button>
          <button
            type="button"
            onClick={() => setShowAddForm((v) => !v)}
            className="min-h-[44px] px-4 py-2.5 rounded-xl bg-teal-700 hover:bg-teal-600 text-white text-xs font-semibold flex items-center gap-2 whitespace-nowrap shrink-0"
          >
            <Plus className="w-4 h-4" />
            {showAddForm ? 'Form Band Karo' : 'Naya Task Jodo'}
          </button>
        </div>
      </section>

      {/* Recurring Task Templates Panel */}
      {showRecurringPanel && (
        <section className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 space-y-3">
          <div className="flex items-center justify-between gap-2">
            <div>
              <h2 className="text-base font-bold text-slate-900 dark:text-slate-100">
                Bar-Bar Aane Wale Kaam (Recurring Task Templates)
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Mahine ke bills, bike maintenance, ya weekly reset ko 1 tap me Aaj ke plan me jodein.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {DEFAULT_RECURRING_TEMPLATES.map((tpl) => (
              <div
                key={tpl.id}
                className="rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-950/60 p-3.5 flex flex-col justify-between gap-3"
              >
                <div className="space-y-1">
                  <div className="flex items-center justify-between gap-2">
                    <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
                      {tpl.title}
                    </h3>
                    <span className="text-xs font-mono text-slate-500 whitespace-nowrap shrink-0">
                      {tpl.estMinutes} min
                    </span>
                  </div>
                  <p className="text-xs text-slate-600 dark:text-slate-400">
                    → {tpl.nextAction}
                  </p>
                  <p className="text-[11px] text-teal-700 dark:text-teal-400 font-mono">
                    {tpl.cadenceLabel}
                  </p>
                </div>
                <div className="flex items-center justify-end">
                  <button
                    type="button"
                    onClick={() => handleSpawnRecurringTemplate(tpl)}
                    className="min-h-[38px] px-3 py-1.5 rounded-lg bg-teal-700 hover:bg-teal-600 text-white text-xs font-semibold flex items-center gap-1.5 whitespace-nowrap"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    Aaj Jodo
                  </button>
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Add Task Form */}
      {showAddForm && (
        <form
          onSubmit={handleCreateTask}
          className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 space-y-4"
        >
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="sm:col-span-2">
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Task Title *
              </label>
              <input
                type="text"
                required
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Kya kaam karna hai?"
                className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3.5 py-2.5 text-base"
              />
            </div>

            <div className="sm:col-span-2">
              <div className="flex items-center justify-between gap-2 mb-1">
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
                  Concrete Next Action + &quot;Agar–To&quot; Obstacle Shield
                </label>
                <button
                  type="button"
                  onClick={() =>
                    setNextAction(suggestIfThenPlan(title || 'is kaam', nextAction))
                  }
                  className="text-xs font-semibold text-teal-700 dark:text-teal-400 hover:underline flex items-center gap-1"
                >
                  <ShieldCheck className="w-3.5 h-3.5" />
                  + &quot;Agar–To&quot; Shield Jodo
                </button>
              </div>
              <input
                type="text"
                value={nextAction}
                onChange={(e) => setNextAction(e.target.value)}
                placeholder="Sabse pehla physical step..."
                className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3.5 py-2.5 text-base"
              />
              <p className="text-[11px] text-teal-700 dark:text-teal-400 mt-1">
                Hint: {STRINGS.today.taskQualityHint}
              </p>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Link to Active Goal (Optional)
              </label>
              <select
                value={goalId}
                onChange={(e) => {
                  setGoalId(e.target.value);
                  setMilestoneId('');
                }}
                className="w-full min-h-[44px] rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-3 py-2 text-sm"
              >
                <option value="">Standalone Task</option>
                {state.goals
                  .filter((g) => g.status === 'active')
                  .map((g) => (
                    <option key={g.id} value={g.id}>
                      {g.title}
                    </option>
                  ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Link to Milestone / Project (Optional)
              </label>
              <select
                value={milestoneId || projectId}
                onChange={(e) => {
                  const val = e.target.value;
                  if (val.startsWith('ms:')) {
                    setMilestoneId(val.replace('ms:', ''));
                    setProjectId('');
                  } else if (val.startsWith('proj:')) {
                    setProjectId(val.replace('proj:', ''));
                    setMilestoneId('');
                  } else {
                    setMilestoneId('');
                    setProjectId('');
                  }
                }}
                className="w-full min-h-[44px] rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-3 py-2 text-sm"
              >
                <option value="">None</option>
                {state.milestones
                  .filter((m) => !goalId || m.goalId === goalId)
                  .map((m) => (
                    <option key={m.id} value={`ms:${m.id}`}>
                      Milestone: {m.title}
                    </option>
                  ))}
                {state.projects
                  .filter((p) => p.status === 'active')
                  .map((p) => (
                    <option key={p.id} value={`proj:${p.id}`}>
                      Project: {p.title}
                    </option>
                  ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Scheduled Date
              </label>
              <input
                type="date"
                value={scheduledDate}
                onChange={(e) => setScheduledDate(e.target.value)}
                className="w-full min-h-[44px] rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-3 py-2 text-base font-mono tabular-nums"
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Due Date
                </label>
                <input
                  type="date"
                  value={dueDate}
                  onChange={(e) => setDueDate(e.target.value)}
                  className="w-full min-h-[44px] rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-2.5 py-2 text-sm font-mono tabular-nums"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Est (Min)
                </label>
                <input
                  type="number"
                  min={5}
                  max={480}
                  value={estMinutes}
                  onChange={(e) => setEstMinutes(Number(e.target.value))}
                  className="w-full min-h-[44px] rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-3 py-2 text-base font-mono tabular-nums"
                />
              </div>
            </div>

            <div className="sm:col-span-2">
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Repeat / Recurrence (Complete hone par agli baar apne-aap banega)
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {(
                  [
                    { key: 'none', label: 'One-Time' },
                    { key: 'daily', label: '↻ Daily' },
                    { key: 'weekly', label: '↻ Weekly' },
                    { key: 'monthly', label: '↻ Monthly' },
                  ] as Array<{ key: TaskRecurrence; label: string }>
                ).map((opt) => (
                  <button
                    key={opt.key}
                    type="button"
                    onClick={() => setRecurrence(opt.key)}
                    className={`min-h-[38px] px-3 py-1.5 rounded-xl text-xs font-semibold border transition-colors ${
                      recurrence === opt.key
                        ? 'bg-teal-700 text-white border-teal-700'
                        : 'bg-slate-50 dark:bg-slate-950 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-800'
                    }`}
                  >
                    {opt.label}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="flex justify-end gap-2">
            <button
              type="button"
              onClick={() => setShowAddForm(false)}
              className="min-h-[44px] px-4 py-2 rounded-xl text-xs font-medium text-slate-600"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="min-h-[44px] px-5 py-2 rounded-xl bg-teal-700 text-white text-xs font-semibold"
            >
              Save Task
            </button>
          </div>
        </form>
      )}

      {/* Filter Tabs: Aaj | Aane Wale | Bina Date | Done */}
      <div className="flex flex-wrap items-center gap-1.5 p-1.5 bg-slate-100 dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800">
        {(
          [
            { key: 'today', label: 'Aaj (Scheduled / Due)' },
            { key: 'upcoming', label: 'Aane Wale (Upcoming)' },
            { key: 'nodate', label: 'Bina Date (Backlog)' },
            { key: 'done', label: 'Done / Paused / Cancelled' },
          ] as Array<{ key: TaskFilterTab; label: string }>
        ).map((t) => (
          <button
            key={t.key}
            type="button"
            onClick={() => setTab(t.key)}
            className={`min-h-[40px] px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
              tab === t.key
                ? 'bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* Celebration Toast Banner */}
      <AnimatePresence>
        {celebrationBanner && (
          <motion.div
            initial={{ opacity: 0, y: -8, scale: 0.96 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -6, scale: 0.96 }}
            transition={{ type: 'spring', stiffness: 360, damping: 22 }}
            className="rounded-xl bg-emerald-600 text-white px-4 py-2.5 text-xs font-bold flex items-center justify-between shadow-lg shadow-emerald-600/25"
          >
            <span className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 shrink-0" />
              {celebrationBanner}
            </span>
            <span className="font-mono text-[11px] bg-white/20 px-2 py-0.5 rounded-md">
              ✓ Done
            </span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Tasks List */}
      <section className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 divide-y divide-slate-100 dark:divide-slate-800">
        {filteredTasks.length === 0 ? (
          <div className="p-8 text-center text-sm text-slate-500">
            Is section me koi task nahi hai.
          </div>
        ) : (
          filteredTasks.map((task) => {
            const linkedGoal = state.goals.find((g) => g.id === task.goalId);
            const linkedProj = state.projects.find(
              (p) => p.id === task.projectId
            );
            const isCompleting = Boolean(completingIds[task.id]);
            const isDone = task.status === 'done' || isCompleting;
            const isCelebrating =
              celebratingTaskId === task.id || isCompleting;
            const isMenuOpen = expandedMenuTaskId === task.id;

            return (
              <motion.div
                key={task.id}
                layout
                animate={
                  isCelebrating
                    ? {
                        backgroundColor: [
                          'rgba(16, 185, 129, 0.18)',
                          'rgba(16, 185, 129, 0.04)',
                        ],
                        scale: [1, 1.008, 1],
                      }
                    : {}
                }
                transition={{ duration: 0.45 }}
                className={`p-4 sm:p-5 flex flex-col gap-3 transition-colors ${
                  isDone ? 'bg-emerald-50/40 dark:bg-emerald-950/20' : ''
                }`}
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="flex items-start gap-3 min-w-0">
                    {task.status === 'todo' ||
                    task.status === 'doing' ||
                    task.status === 'done' ? (
                      <AnimatedCheckButton
                        checked={isDone}
                        celebrating={isCelebrating}
                        onToggle={() => handleToggleTaskDone(task)}
                        ariaLabel={
                          isDone
                            ? `Reopen ${task.title}`
                            : `Complete ${task.title}`
                        }
                      />
                    ) : (
                      <Check className="w-4 h-4 text-slate-400 shrink-0 mt-1" />
                    )}

                    <div className="space-y-1 min-w-0">
                      <div className="flex flex-wrap items-center gap-2">
                        <h3
                          className={`text-sm sm:text-base font-semibold transition-all duration-300 ${
                            isDone || task.status === 'cancelled'
                              ? 'line-through text-slate-400 dark:text-slate-500'
                              : 'text-slate-900 dark:text-slate-100'
                          }`}
                        >
                          {task.title}
                        </h3>
                        {isDone && (
                          <motion.span
                            initial={{ scale: 0.7, opacity: 0 }}
                            animate={{ scale: 1, opacity: 1 }}
                            className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-emerald-100 dark:bg-emerald-950/70 text-emerald-800 dark:text-emerald-300 text-[11px] font-bold"
                          >
                            ✓ Pura Hua
                          </motion.span>
                        )}
                      </div>

                      {task.nextAction && !isDone && (
                        <p className="text-xs text-slate-600 dark:text-slate-400">
                          Next Action: {task.nextAction}
                        </p>
                      )}

                      {/* Unboxed Metadata with · separators */}
                      <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500 font-mono tabular-nums">
                        <span>{task.estMinutes ?? 20} min</span>
                        {task.scheduledDate && (
                          <>
                            <span>·</span>
                            <span>Scheduled: {task.scheduledDate}</span>
                          </>
                        )}
                        {task.dueDate && (
                          <>
                            <span>·</span>
                            <span>Due: {task.dueDate}</span>
                          </>
                        )}
                        {linkedGoal && (
                          <>
                            <span>·</span>
                            <span className="font-sans">
                              Goal: {linkedGoal.title}
                            </span>
                          </>
                        )}
                        {linkedProj && (
                          <>
                            <span>·</span>
                            <span className="font-sans">
                              Project: {linkedProj.title}
                            </span>
                          </>
                        )}
                        {task.recurrence && task.recurrence !== 'none' && (
                          <>
                            <span>·</span>
                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-teal-50 dark:bg-teal-950/60 text-teal-800 dark:text-teal-300 text-[11px] font-semibold font-sans">
                              ↻ {task.recurrence}
                            </span>
                          </>
                        )}
                        {task.rescheduleCount >= 3 && !isDone && (
                          <>
                            <span>·</span>
                            <span className="text-amber-700 dark:text-amber-400 font-sans">
                              {STRINGS.today.rescheduleWarning}
                            </span>
                          </>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Clean Primary Action + Progressive Disclosure Menu */}
                  <div className="flex items-center gap-1.5 self-end sm:self-center shrink-0">
                    {(task.status === 'todo' || task.status === 'doing') &&
                    !isCompleting ? (
                      <>
                        {task.scheduledDate !== today ? (
                          <button
                            type="button"
                            onClick={() => rescheduleTask(task.id, today)}
                            className="min-h-[38px] px-3 py-1.5 rounded-lg bg-teal-50 dark:bg-teal-950/60 text-teal-800 dark:text-teal-300 text-xs font-semibold whitespace-nowrap"
                          >
                            Aaj Karo
                          </button>
                        ) : (
                          <button
                            type="button"
                            onClick={() =>
                              rescheduleTask(task.id, addDays(today, 1))
                            }
                            className="min-h-[38px] px-3 py-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-xs font-medium whitespace-nowrap"
                          >
                            Kal Karo
                          </button>
                        )}
                        <button
                          type="button"
                          onClick={() =>
                            setExpandedMenuTaskId(
                              isMenuOpen ? null : task.id
                            )
                          }
                          aria-label={`More actions for ${task.title}`}
                          className={`min-h-[38px] min-w-[38px] flex items-center justify-center rounded-lg transition-colors ${
                            isMenuOpen
                              ? 'bg-slate-200 dark:bg-slate-800 text-slate-900 dark:text-slate-100'
                              : 'text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800'
                          }`}
                        >
                          <MoreHorizontal className="w-4 h-4" />
                        </button>
                      </>
                    ) : (
                      <button
                        type="button"
                        onClick={() => reopenTask(task.id)}
                        className="min-h-[38px] px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-semibold flex items-center gap-1.5"
                      >
                        <RotateCcw className="w-3.5 h-3.5" />
                        Reopen
                      </button>
                    )}
                  </div>
                </div>

                {/* Secondary Actions Drawer (Only when ⋯ is clicked) */}
                {isMenuOpen && !isDone && (
                  <div className="flex flex-wrap items-center gap-2 pl-9 pt-1 border-t border-slate-100 dark:border-slate-800/70">
                    {task.scheduledDate !== today && (
                      <button
                        type="button"
                        onClick={() => {
                          rescheduleTask(task.id, addDays(today, 1));
                          setExpandedMenuTaskId(null);
                        }}
                        className="min-h-[34px] px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-xs font-medium"
                      >
                        Kal Karo
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={() => {
                        splitTaskIntoSubtasks(
                          task.id,
                          generateTwoMinuteStarter(task.title, task.nextAction)
                        );
                        setExpandedMenuTaskId(null);
                      }}
                      className="min-h-[34px] px-2.5 py-1 rounded-lg bg-teal-50 dark:bg-teal-950/60 text-teal-800 dark:text-teal-300 text-xs font-semibold flex items-center gap-1"
                    >
                      <Zap className="w-3.5 h-3.5 text-teal-600" />
                      2-Min Starter Split
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setExpandedMenuTaskId(null);
                        setSplittingTask(task);
                        setSplitLines(
                          `${task.title} - Step 1\n${task.title} - Step 2`
                        );
                      }}
                      className="min-h-[34px] px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-xs font-medium flex items-center gap-1"
                    >
                      <Scissors className="w-3.5 h-3.5" />
                      Chhota Karo (Split)
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        updateTask(task.id, { status: 'paused' });
                        setExpandedMenuTaskId(null);
                      }}
                      className="min-h-[34px] px-2.5 py-1 rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs flex items-center gap-1"
                    >
                      <Pause className="w-3.5 h-3.5" />
                      Pause
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        updateTask(task.id, { status: 'cancelled' });
                        setExpandedMenuTaskId(null);
                      }}
                      className="min-h-[34px] px-2.5 py-1 rounded-lg text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 text-xs flex items-center gap-1"
                    >
                      <XCircle className="w-3.5 h-3.5" />
                      Cancel
                    </button>
                  </div>
                )}
              </motion.div>
            );
          })
        )}
      </section>

      {/* Split Modal with Optional AI Assist */}
      {splittingTask && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4"
          role="dialog"
          aria-modal="true"
        >
          <div className="w-full max-w-lg rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 space-y-4">
            <div className="flex items-center justify-between gap-2">
              <h3 className="text-base font-bold text-slate-900 dark:text-slate-100">
                Split Task: {splittingTask.title}
              </h3>
              <button
                type="button"
                onClick={() => handleAiSplit(splittingTask)}
                disabled={aiSplitting}
                className="min-h-[38px] px-3 py-1.5 rounded-xl bg-teal-50 dark:bg-teal-950/60 text-teal-800 dark:text-teal-300 text-xs font-semibold flex items-center gap-1"
              >
                <Sparkles className="w-3.5 h-3.5" />
                {aiSplitting ? 'Splitting...' : 'AI Se Steps Banwao'}
              </button>
            </div>
            <textarea
              rows={4}
              value={splitLines}
              onChange={(e) => setSplitLines(e.target.value)}
              className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 p-3 text-base"
            />
            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setSplittingTask(null)}
                className="min-h-[44px] px-4 py-2 rounded-xl text-xs font-medium text-slate-600"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  splitTaskIntoSubtasks(
                    splittingTask.id,
                    splitLines.split('\n')
                  );
                  setSplittingTask(null);
                }}
                className="min-h-[44px] px-5 py-2 rounded-xl bg-teal-700 text-white text-xs font-semibold"
              >
                Create Subtasks
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
