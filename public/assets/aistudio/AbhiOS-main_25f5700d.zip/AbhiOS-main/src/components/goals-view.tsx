'use client';

import React, { useMemo, useState } from 'react';
import {
  ArrowDown,
  ArrowUp,
  Check,
  Edit3,
  Infinity as InfinityIcon,
  Pause,
  Play,
  Plus,
  Sparkles,
  Target,
  X,
  ArrowRight,
  ChevronDown,
  ChevronUp,
  CheckSquare,
  Layers,
  Scale,
  Calendar,
} from 'lucide-react';
import { useGoalOs } from '@/src/context/goal-os-context';
import { STRINGS } from '@/src/lib/strings';
import {
  computeGoalProgressAndNextStep,
  computeLifeBalanceSnapshot,
  normalizeGoalTags,
  PRESET_GOAL_TAGS,
} from '@/src/lib/logic/planner';
import { Goal, GoalStatus, GoalType } from '@/src/lib/types';
import {
  AnimatedCheckButton,
  playCompletionCelebrationSound,
} from '@/src/components/animated-check-button';

type TopGoalViewMode = 'categories' | 'ongoing';
type GoalDetailStep = 'edit' | 'plan' | 'process';

const formatTagLabel = (tag: string) =>
  tag.startsWith('#') ? tag : `#${tag}`;

export function GoalsView() {
  const {
    state,
    today,
    createDirectGoal,
    updateGoal,
    createMilestone,
    updateMilestone,
    reorderMilestone,
    createTask,
    completeTask,
    reopenTask,
    rescheduleTask,
    createLifeArea,
    updateLifeArea,
    requestAiSuggestion,
    setActiveTab,
  } = useGoalOs();

  const [showBalanceSnapshot, setShowBalanceSnapshot] = useState(false);

  // Top mode matching Sketch 2: "Goals" (Categories) vs "Ongoing Goals"
  const [viewMode, setViewMode] = useState<TopGoalViewMode>('categories');

  // Selected Category (Department) — defaults to first category (Health) so the ↓ Goals section below is immediately visible
  const [selectedAreaId, setSelectedAreaId] = useState<string>('area-health');

  // Active Goal opened in the Full "Edit -> Plan -> Aage ka Process" Workspace Modal
  const [activeGoalId, setActiveGoalId] = useState<string | null>(null);
  const [detailStep, setDetailStep] = useState<GoalDetailStep>('edit');

  // Edit Fields inside Goal Workspace
  const [editTitle, setEditTitle] = useState('');
  const [editAreaId, setEditAreaId] = useState('');
  const [editGoalType, setEditGoalType] = useState<GoalType>('outcome');
  const [editStatus, setEditStatus] = useState<GoalStatus>('active');
  const [editOutcome, setEditOutcome] = useState('');
  const [editReason, setEditReason] = useState('');
  const [editTradeoffs, setEditTradeoffs] = useState('');
  const [editTargetDate, setEditTargetDate] = useState('');
  const [editTags, setEditTags] = useState<string[]>([]);
  const [editCustomTag, setEditCustomTag] = useState('');

  // Plan (Milestones) & Process (Tasks) state inside Goal Workspace
  const [newMilestoneTitle, setNewMilestoneTitle] = useState('');
  const [aiBreakdownLoading, setAiBreakdownLoading] = useState(false);
  const [aiSuggestedMilestones, setAiSuggestedMilestones] = useState<string[]>(
    []
  );
  const [newTaskTitle, setNewTaskTitle] = useState('');
  const [newTaskEstMinutes, setNewTaskEstMinutes] = useState(25);
  const [newTaskDate, setNewTaskDate] = useState(today);
  const [completingTaskIds, setCompletingTaskIds] = useState<string[]>([]);

  // Bottom "[ add new ]" and "[ edit ]" controls matching Sketch 2
  const [showAddMenu, setShowAddMenu] = useState(false);
  const [addMode, setAddMode] = useState<'goal' | 'category'>('goal');
  const [newCategoryName, setNewCategoryName] = useState('');
  const [newCategoryDesc, setNewCategoryDesc] = useState('');

  const [newGoalTitle, setNewGoalTitle] = useState('');
  const [newGoalAreaId, setNewGoalAreaId] = useState('area-health');
  const [newGoalType, setNewGoalType] = useState<GoalType>('outcome');
  const [newGoalOutcome, setNewGoalOutcome] = useState('');
  const [newGoalReason, setNewGoalReason] = useState('');

  // Edit Categories Mode
  const [editingCategoriesMode, setEditingCategoriesMode] = useState(false);
  const [renamingAreaId, setRenamingAreaId] = useState<string | null>(null);
  const [renamingAreaText, setRenamingAreaText] = useState('');

  const activeLifeAreas = useMemo(
    () => state.lifeAreas.filter((a) => a.status === 'active'),
    [state.lifeAreas]
  );

  // All non-archived goals (active + candidate)
  const visibleGoals = useMemo(
    () =>
      state.goals.filter(
        (g) => g.status === 'active' || g.status === 'candidate'
      ),
    [state.goals]
  );

  const lifeBalance = useMemo(
    () =>
      computeLifeBalanceSnapshot(
        activeLifeAreas,
        state.goals,
        state.tasks
      ),
    [activeLifeAreas, state.goals, state.tasks]
  );

  const ongoingGoals = useMemo(
    () =>
      visibleGoals.filter((g) => g.goalType === 'ongoing_direction'),
    [visibleGoals]
  );

  const selectedArea = useMemo(
    () =>
      activeLifeAreas.find((a) => a.id === selectedAreaId) ||
      activeLifeAreas[0] ||
      null,
    [activeLifeAreas, selectedAreaId]
  );

  const selectedCategoryGoals = useMemo(() => {
    if (!selectedArea) return visibleGoals;
    return visibleGoals.filter((g) => g.lifeAreaId === selectedArea.id);
  }, [visibleGoals, selectedArea]);

  const activeGoal = useMemo(
    () => state.goals.find((g) => g.id === activeGoalId) || null,
    [state.goals, activeGoalId]
  );

  const openGoalWorkspace = (
    goal: Goal,
    initialStep: GoalDetailStep = 'edit'
  ) => {
    setActiveGoalId(goal.id);
    setDetailStep(initialStep);
    setEditTitle(goal.title);
    setEditAreaId(goal.lifeAreaId);
    setEditGoalType(goal.goalType);
    setEditStatus(goal.status);
    setEditOutcome(goal.desiredOutcome || '');
    setEditReason(goal.purposeReason || '');
    setEditTradeoffs(goal.tradeoffs || '');
    setEditTargetDate(goal.targetDate || '');
    setEditTags(normalizeGoalTags(goal.tags || []));
    setEditCustomTag('');
    setAiSuggestedMilestones([]);
    setNewMilestoneTitle('');
    setNewTaskTitle('');
    setNewTaskDate(today);
  };

  const handleSaveGoalEdits = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeGoal || !editTitle.trim()) return;
    updateGoal(activeGoal.id, {
      title: editTitle.trim(),
      lifeAreaId: editAreaId,
      goalType: editGoalType,
      status: editStatus === 'candidate' ? 'active' : editStatus,
      desiredOutcome: editOutcome.trim(),
      purposeReason: editReason.trim(),
      tradeoffs: editTradeoffs.trim(),
      targetDate:
        editGoalType === 'ongoing_direction' ? null : editTargetDate || null,
      tags: normalizeGoalTags(editTags),
    });
    // Move smoothly to Step 2: Plan
    setDetailStep('plan');
  };

  const handleAiSuggestMilestones = async (goal: Goal) => {
    setAiBreakdownLoading(true);
    try {
      const { draft } = await requestAiSuggestion(
        'goal_gate_assist',
        goal.title
      );
      if (draft.subItems && draft.subItems.length > 0) {
        setAiSuggestedMilestones(draft.subItems);
      }
    } finally {
      setAiBreakdownLoading(false);
    }
  };

  const handleCreateGoalOrCategory = (e: React.FormEvent) => {
    e.preventDefault();
    if (addMode === 'category') {
      if (!newCategoryName.trim()) return;
      const created = createLifeArea(
        newCategoryName.trim(),
        newCategoryDesc.trim()
      );
      if (created) {
        setSelectedAreaId(created.id);
      }
      setNewCategoryName('');
      setNewCategoryDesc('');
      setShowAddMenu(false);
      return;
    }

    if (!newGoalTitle.trim()) return;
    const targetArea =
      newGoalAreaId || selectedArea?.id || activeLifeAreas[0]?.id || 'area-health';
    const createdGoal = createDirectGoal({
      title: newGoalTitle.trim(),
      lifeAreaId: targetArea,
      goalType: newGoalType,
      desiredOutcome: newGoalOutcome.trim() || newGoalTitle.trim(),
      purposeReason:
        newGoalReason.trim() || 'Meri life direction aur sukoon ke liye',
      status: 'active',
    });
    setSelectedAreaId(targetArea);
    setNewGoalTitle('');
    setNewGoalOutcome('');
    setNewGoalReason('');
    setShowAddMenu(false);
    openGoalWorkspace(createdGoal, 'plan');
  };

  const handleToggleGoalTask = (taskId: string, isDone: boolean) => {
    if (isDone) {
      reopenTask(taskId);
      return;
    }
    if (completingTaskIds.includes(taskId)) return;
    playCompletionCelebrationSound();
    setCompletingTaskIds((prev) => [...prev, taskId]);
    setTimeout(() => {
      completeTask(taskId);
      setCompletingTaskIds((prev) => prev.filter((id) => id !== taskId));
    }, 450);
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      {/* 1. CLEAN HEADER + TOP SWITCH: "Goals" vs "Ongoing Goals" (Matches User Sketch 2) */}
      <section className="rounded-3xl bg-white dark:bg-slate-900 border-2 border-slate-200 dark:border-slate-800 p-6 shadow-xs space-y-5">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900 dark:text-slate-100">
              Goals
            </h1>
            <p className="text-xs font-medium text-slate-500 dark:text-slate-400 mt-0.5">
              Category chunein → Goal kholein → Edit, Plan aur Aage ka Process
            </p>
          </div>
          <button
            type="button"
            onClick={() => setShowBalanceSnapshot((v) => !v)}
            data-testid="toggle-department-balance"
            className={`min-h-[38px] px-3.5 py-1.5 rounded-xl text-xs font-semibold border transition-colors flex items-center gap-1.5 shrink-0 ${
              showBalanceSnapshot
                ? 'bg-teal-50 dark:bg-teal-950/60 border-teal-600/50 text-teal-800 dark:text-teal-300'
                : 'bg-slate-50 dark:bg-slate-800/80 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100'
            }`}
          >
            <Scale className="w-3.5 h-3.5 text-teal-600" />
            <span>Department Balance</span>
            {showBalanceSnapshot ? (
              <ChevronUp className="w-3.5 h-3.5" />
            ) : (
              <ChevronDown className="w-3.5 h-3.5" />
            )}
          </button>
        </div>

        {/* Collapsible Calm Department Balance Snapshot (No Guilt, No Score) */}
        {showBalanceSnapshot && (
          <div
            data-testid="department-balance-snapshot"
            className="rounded-2xl bg-slate-50/90 dark:bg-slate-950/80 border border-slate-200/80 dark:border-slate-800 p-4 space-y-3"
          >
            <div className="flex items-center justify-between gap-2">
              <span className="text-xs font-bold uppercase tracking-wider text-teal-800 dark:text-teal-300 flex items-center gap-1.5">
                <Scale className="w-3.5 h-3.5" />
                Calm Life Balance Overview (Zero Guilt)
              </span>
              <span className="text-[11px] text-slate-500 font-mono">
                {
                  lifeBalance.items.filter(
                    (i) => i.activeGoalsCount > 0 || i.completedTasksCount > 0
                  ).length
                }
                /{lifeBalance.items.length} Active Fields
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {lifeBalance.items.map((row) => (
                <button
                  key={row.areaId}
                  type="button"
                  onClick={() => {
                    setViewMode('categories');
                    setSelectedAreaId(row.areaId);
                  }}
                  className="text-left rounded-xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 px-3.5 py-2.5 flex items-center justify-between gap-2 hover:border-teal-500 transition-colors"
                >
                  <div className="min-w-0">
                    <p className="text-xs font-bold text-slate-900 dark:text-slate-100 truncate">
                      {row.name}
                    </p>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400 font-mono">
                      {row.activeGoalsCount} Goals · {row.completedTasksCount} Done · {row.statusLabel}
                    </p>
                  </div>
                  <span
                    className={`w-2.5 h-2.5 rounded-full shrink-0 ${
                      row.activeGoalsCount > 0 || row.completedTasksCount > 0
                        ? 'bg-emerald-500'
                        : 'bg-slate-300 dark:bg-slate-700'
                    }`}
                  />
                </button>
              ))}
            </div>

            <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
              💡 {lifeBalance.calmInsight}
            </p>
          </div>
        )}

        {/* Two Top Tabs exactly as drawn in Sketch 2: "Goals" and "Ongoing Goals" */}
        <div className="grid grid-cols-2 gap-3">
          <button
            type="button"
            onClick={() => setViewMode('categories')}
            className={`min-h-[52px] px-4 py-3 rounded-2xl border-2 text-left transition-all flex items-center justify-between ${
              viewMode === 'categories'
                ? 'border-teal-700 bg-teal-700 text-white shadow-xs'
                : 'border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-slate-800 dark:text-slate-200 hover:border-slate-300'
            }`}
          >
            <div className="flex items-center gap-2.5">
              <Layers className="w-5 h-5 shrink-0" />
              <div>
                <p className="text-sm sm:text-base font-bold leading-tight">
                  Goals
                </p>
                <p
                  className={`text-[11px] ${
                    viewMode === 'categories'
                      ? 'text-teal-100'
                      : 'text-slate-500'
                  }`}
                >
                  Categories ({activeLifeAreas.length})
                </p>
              </div>
            </div>
            <ChevronDown className="w-4 h-4 shrink-0" />
          </button>

          <button
            type="button"
            onClick={() => setViewMode('ongoing')}
            className={`min-h-[52px] px-4 py-3 rounded-2xl border-2 text-left transition-all flex items-center justify-between ${
              viewMode === 'ongoing'
                ? 'border-teal-700 bg-teal-700 text-white shadow-xs'
                : 'border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-slate-800 dark:text-slate-200 hover:border-slate-300'
            }`}
          >
            <div className="flex items-center gap-2.5">
              <InfinityIcon className="w-5 h-5 shrink-0" />
              <div>
                <p className="text-sm sm:text-base font-bold leading-tight">
                  Ongoing Goals
                </p>
                <p
                  className={`text-[11px] ${
                    viewMode === 'ongoing' ? 'text-teal-100' : 'text-slate-500'
                  }`}
                >
                  Hamesha Chalne Wale ({ongoingGoals.length})
                </p>
              </div>
            </div>
            <ChevronDown className="w-4 h-4 shrink-0" />
          </button>
        </div>

        {/* MODE A: CATEGORY STACK (Health 2, Finance 1, Relationship 2, etc.) */}
        {viewMode === 'categories' && (
          <div className="space-y-3 pt-1">
            <div className="space-y-2.5" role="list" aria-label="Goal Categories">
              {activeLifeAreas.map((area) => {
                const count = visibleGoals.filter(
                  (g) => g.lifeAreaId === area.id
                ).length;
                const isSelected = selectedArea?.id === area.id;
                const isRenaming = renamingAreaId === area.id;

                return (
                  <div key={area.id} role="listitem">
                    {isRenaming ? (
                      <div className="flex items-center gap-2 rounded-2xl border-2 border-teal-600 bg-slate-50 dark:bg-slate-950 px-4 py-2.5">
                        <input
                          type="text"
                          value={renamingAreaText}
                          onChange={(e) => setRenamingAreaText(e.target.value)}
                          className="flex-1 bg-transparent text-base font-bold text-slate-900 dark:text-slate-100 focus:outline-none"
                          autoFocus
                        />
                        <button
                          type="button"
                          onClick={() => {
                            if (renamingAreaText.trim()) {
                              updateLifeArea(area.id, {
                                name: renamingAreaText.trim(),
                              });
                            }
                            setRenamingAreaId(null);
                          }}
                          className="min-h-[36px] px-3 py-1 rounded-xl bg-teal-700 text-white text-xs font-semibold"
                        >
                          Save
                        </button>
                        <button
                          type="button"
                          onClick={() => setRenamingAreaId(null)}
                          className="min-h-[36px] px-2.5 py-1 text-xs text-slate-500"
                        >
                          Cancel
                        </button>
                      </div>
                    ) : (
                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => setSelectedAreaId(area.id)}
                          className={`w-full min-h-[54px] px-5 py-3.5 rounded-2xl border-2 transition-all flex items-center justify-between ${
                            isSelected
                              ? 'border-teal-700 bg-teal-50/70 dark:bg-teal-950/50 text-slate-900 dark:text-slate-100 shadow-2xs'
                              : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 hover:border-slate-300 dark:hover:border-slate-700 text-slate-800 dark:text-slate-200'
                          }`}
                        >
                          <span className="text-base sm:text-lg font-bold tracking-tight">
                            {area.name}
                          </span>
                          <span
                            className={`text-base sm:text-lg font-mono font-bold tabular-nums px-3 py-0.5 rounded-xl ${
                              isSelected
                                ? 'bg-teal-700 text-white'
                                : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
                            }`}
                          >
                            {count}
                          </span>
                        </button>

                        {editingCategoriesMode && (
                          <button
                            type="button"
                            onClick={() => {
                              setRenamingAreaId(area.id);
                              setRenamingAreaText(area.name);
                            }}
                            className="min-h-[54px] px-3.5 rounded-2xl border-2 border-slate-200 dark:border-slate-800 text-xs font-semibold text-teal-700 dark:text-teal-400 hover:bg-slate-50 shrink-0"
                          >
                            Rename
                          </button>
                        )}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* MODE B: ONGOING GOALS DIRECT LIST */}
        {viewMode === 'ongoing' && (
          <div className="space-y-3 pt-1">
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Ongoing Goals ek baar set hone par hamesha chalte rehte hain. Kisi bhi goal par tap karke Edit ya Plan badlein:
            </p>
            <div className="space-y-2.5">
              {ongoingGoals.map((goal, idx) => {
                const areaName =
                  state.lifeAreas.find((a) => a.id === goal.lifeAreaId)?.name ||
                  'General';
                return (
                  <div
                    key={goal.id}
                    className="flex items-center justify-between gap-3 rounded-2xl border-2 border-teal-300/80 dark:border-teal-800/80 bg-teal-50/30 dark:bg-teal-950/20 px-4 py-3.5"
                  >
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2 text-xs text-teal-800 dark:text-teal-300 font-semibold">
                        <span>#{idx + 1}</span>
                        <span>·</span>
                        <span>{areaName}</span>
                        <span>·</span>
                        <span>♾️ Ongoing</span>
                      </div>
                      <h3 className="text-base font-bold text-slate-900 dark:text-slate-100 mt-0.5 truncate">
                        {goal.title}
                      </h3>
                    </div>
                    <button
                      type="button"
                      onClick={() => openGoalWorkspace(goal, 'edit')}
                      className="min-h-[42px] px-4 py-2 rounded-xl bg-teal-700 hover:bg-teal-600 text-white text-xs font-semibold flex items-center gap-1.5 shrink-0"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                      <span>Edit & Plan</span>
                    </button>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </section>

      {/* 2. ARROW DOWN ↓ TO GOALS LIST INSIDE SELECTED CATEGORY (Matches Sketch 2 bottom half) */}
      {viewMode === 'categories' && selectedArea && (
        <section className="space-y-3">
          {/* Visual Arrow Indicator matching the ↓ arrow in User Sketch 2 */}
          <div className="flex flex-col items-center justify-center text-slate-400 dark:text-slate-500 py-0.5">
            <ArrowDown className="w-5 h-5 text-teal-600 dark:text-teal-400" />
            <span className="text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-300 mt-0.5">
              {selectedArea.name} Goals ({selectedCategoryGoals.length})
            </span>
          </div>

          <div className="rounded-3xl bg-white dark:bg-slate-900 border-2 border-slate-200 dark:border-slate-800 p-5 sm:p-6 shadow-xs space-y-4">
            <div className="flex items-center justify-between gap-2">
              <div>
                <h2 className="text-lg font-bold text-slate-900 dark:text-slate-100">
                  {selectedArea.name} — Goals List
                </h2>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Goal par click karke pura Edit karein, Plan (Steps) banayein aur Daily Tasks jodein.
                </p>
              </div>
              <button
                type="button"
                onClick={() => {
                  setAddMode('goal');
                  setNewGoalAreaId(selectedArea.id);
                  setShowAddMenu(true);
                }}
                className="min-h-[40px] px-3.5 py-1.5 rounded-xl bg-teal-50 dark:bg-teal-950/60 text-teal-800 dark:text-teal-300 border border-teal-200 dark:border-teal-800 text-xs font-bold flex items-center gap-1.5 shrink-0"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>+ Add in {selectedArea.name}</span>
              </button>
            </div>

            {selectedCategoryGoals.length === 0 ? (
              <div className="rounded-2xl border border-dashed border-slate-300 dark:border-slate-700 p-6 text-center space-y-2">
                <p className="text-sm font-semibold text-slate-700 dark:text-slate-300">
                  {selectedArea.name} me abhi koi Goal nahi hai (0).
                </p>
                <p className="text-xs text-slate-500">
                  Brain Dump se filter karke yahan bhejein ya niche &ldquo;+ Add New&rdquo; button dabayein.
                </p>
              </div>
            ) : (
              <div className="space-y-2.5">
                {selectedCategoryGoals.map((goal, idx) => {
                  const isOngoing = goal.goalType === 'ongoing_direction';
                  const progress = computeGoalProgressAndNextStep(
                    goal.id,
                    state.milestones,
                    state.tasks
                  );

                  return (
                    <div
                      key={goal.id}
                      onClick={() => openGoalWorkspace(goal, 'edit')}
                      role="button"
                      tabIndex={0}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter' || e.key === ' ') {
                          e.preventDefault();
                          openGoalWorkspace(goal, 'edit');
                        }
                      }}
                      className="group cursor-pointer rounded-2xl border-2 border-slate-200 dark:border-slate-800 hover:border-teal-600 dark:hover:border-teal-500 bg-[#FAF8F5]/60 dark:bg-slate-950 px-4 py-3.5 transition-all flex flex-col gap-3"
                    >
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                        <div className="flex items-start gap-3 min-w-0 flex-1">
                          <span className="w-7 h-7 rounded-full bg-slate-200/80 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-mono text-xs font-bold flex items-center justify-center shrink-0 mt-0.5">
                            {idx + 1}
                          </span>
                          <div className="min-w-0 flex-1 space-y-1.5">
                            <div className="flex flex-wrap items-center gap-2">
                              <h3 className="text-base font-bold text-slate-900 dark:text-slate-100 group-hover:text-teal-700 dark:group-hover:text-teal-400 transition-colors">
                                {goal.title}
                              </h3>
                              {isOngoing && (
                                <span className="text-[11px] font-semibold text-teal-700 dark:text-teal-400 bg-teal-50 dark:bg-teal-950/60 px-2 py-0.5 rounded-md border border-teal-200 dark:border-teal-800">
                                  ♾️ Ongoing
                                </span>
                              )}
                            </div>

                            {/* Visual Progress Bar + Step Counter */}
                            <div className="space-y-1 max-w-md">
                              <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 font-mono">
                                <span>
                                  Progress: {progress.completedSteps}/
                                  {progress.totalSteps} Steps ({progress.percent}
                                  %)
                                </span>
                                {(goal.tags || []).length > 0 && (
                                  <span>
                                    {(goal.tags || [])
                                      .slice(0, 2)
                                      .map(formatTagLabel)
                                      .join(' ')}
                                  </span>
                                )}
                              </div>
                              <div className="w-full h-1.5 rounded-full bg-slate-200/80 dark:bg-slate-800 overflow-hidden">
                                <div
                                  className="h-full bg-teal-600 dark:bg-teal-500 rounded-full transition-all duration-300"
                                  style={{ width: `${progress.percent}%` }}
                                />
                              </div>
                            </div>

                            {/* Next Up Step Indicator */}
                            {(progress.nextUpTask ||
                              progress.nextUpMilestone) && (
                              <div className="flex flex-wrap items-center gap-2 pt-0.5">
                                <span className="text-xs text-teal-800 dark:text-teal-300 font-medium truncate max-w-xs sm:max-w-md">
                                  → Next Up:{' '}
                                  {progress.nextUpTask?.title ||
                                    progress.nextUpMilestone?.title}
                                </span>
                                {progress.nextUpTask &&
                                  progress.nextUpTask.scheduledDate !== today && (
                                    <button
                                      type="button"
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        rescheduleTask(
                                          progress.nextUpTask!.id,
                                          today
                                        );
                                      }}
                                      className="px-2 py-0.5 rounded-md bg-teal-100/90 dark:bg-teal-950 text-teal-800 dark:text-teal-300 text-[11px] font-semibold hover:bg-teal-200 flex items-center gap-1"
                                    >
                                      <Calendar className="w-3 h-3" />
                                      <span>Aaj Schedule Karo</span>
                                    </button>
                                  )}
                              </div>
                            )}
                          </div>
                        </div>

                        <div className="flex items-center gap-2 shrink-0 self-end sm:self-center">
                          <span className="min-h-[38px] px-3.5 py-1.5 rounded-xl bg-teal-700 group-hover:bg-teal-600 text-white text-xs font-semibold flex items-center gap-1.5 whitespace-nowrap">
                            <Edit3 className="w-3.5 h-3.5" />
                            <span>Edit → Plan → Process</span>
                          </span>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}

            {/* Bottom Action Bar matching Sketch 2: [ add new ]  [ edit ] */}
            <div className="grid grid-cols-2 gap-3 pt-3 border-t border-slate-100 dark:border-slate-800">
              <button
                type="button"
                onClick={() => {
                  setAddMode('goal');
                  setNewGoalAreaId(selectedArea.id);
                  setShowAddMenu((v) => !v);
                }}
                className="min-h-[46px] px-4 py-2.5 rounded-2xl bg-slate-900 dark:bg-slate-100 hover:bg-slate-800 text-white dark:text-slate-900 text-sm font-bold flex items-center justify-center gap-2 transition-colors"
              >
                <Plus className="w-4 h-4" />
                <span>Add New (Goal / Category)</span>
              </button>

              <button
                type="button"
                onClick={() => setEditingCategoriesMode((v) => !v)}
                className={`min-h-[46px] px-4 py-2.5 rounded-2xl border-2 text-sm font-bold flex items-center justify-center gap-2 transition-colors ${
                  editingCategoriesMode
                    ? 'border-teal-600 bg-teal-50 dark:bg-teal-950/50 text-teal-800 dark:text-teal-300'
                    : 'border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800'
                }`}
              >
                <Edit3 className="w-4 h-4" />
                <span>
                  {editingCategoriesMode
                    ? 'Done Editing Categories'
                    : 'Edit Categories'}
                </span>
              </button>
            </div>
          </div>
        </section>
      )}

      {/* 3. INLINE "ADD NEW" DRAWER (Goal or Category) */}
      {showAddMenu && (
        <form
          onSubmit={handleCreateGoalOrCategory}
          className="rounded-3xl bg-white dark:bg-slate-900 border-2 border-teal-600 p-5 sm:p-6 shadow-lg space-y-4"
        >
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setAddMode('goal')}
                className={`min-h-[38px] px-3.5 py-1.5 rounded-xl text-xs font-bold ${
                  addMode === 'goal'
                    ? 'bg-teal-700 text-white'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
                }`}
              >
                + Naya Goal Jodo
              </button>
              <button
                type="button"
                onClick={() => setAddMode('category')}
                className={`min-h-[38px] px-3.5 py-1.5 rounded-xl text-xs font-bold ${
                  addMode === 'category'
                    ? 'bg-teal-700 text-white'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
                }`}
              >
                + Nayi Category (e.g. Health, Finance)
              </button>
            </div>
            <button
              type="button"
              onClick={() => setShowAddMenu(false)}
              className="text-xs text-slate-500 hover:text-slate-800"
            >
              Close
            </button>
          </div>

          {addMode === 'category' ? (
            <div className="space-y-3">
              <input
                type="text"
                required
                value={newCategoryName}
                onChange={(e) => setNewCategoryName(e.target.value)}
                placeholder="Category Naam (e.g. Spiritual, Fitness, Side Business)..."
                className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3.5 py-2.5 text-base"
              />
              <input
                type="text"
                value={newCategoryDesc}
                onChange={(e) => setNewCategoryDesc(e.target.value)}
                placeholder="Short description (optional)..."
                className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3.5 py-2 text-sm"
              />
              <div className="flex justify-end">
                <button
                  type="submit"
                  className="min-h-[42px] px-5 py-2 rounded-xl bg-teal-700 text-white text-xs font-bold"
                >
                  Category Save Karo
                </button>
              </div>
            </div>
          ) : (
            <div className="space-y-3">
              <input
                type="text"
                required
                value={newGoalTitle}
                onChange={(e) => setNewGoalTitle(e.target.value)}
                placeholder="Goal ka naam likhein..."
                className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3.5 py-2.5 text-base"
              />
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <select
                  value={newGoalAreaId}
                  onChange={(e) => setNewGoalAreaId(e.target.value)}
                  className="min-h-[44px] rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-3 py-2 text-sm font-medium"
                >
                  {activeLifeAreas.map((a) => (
                    <option key={a.id} value={a.id}>
                      Category: {a.name}
                    </option>
                  ))}
                </select>
                <div className="grid grid-cols-2 gap-1.5">
                  <button
                    type="button"
                    onClick={() => setNewGoalType('outcome')}
                    className={`min-h-[44px] rounded-xl text-xs font-bold border ${
                      newGoalType === 'outcome'
                        ? 'bg-teal-700 text-white border-teal-700'
                        : 'border-slate-300 dark:border-slate-700 text-slate-600'
                    }`}
                  >
                    🎯 Goal
                  </button>
                  <button
                    type="button"
                    onClick={() => setNewGoalType('ongoing_direction')}
                    className={`min-h-[44px] rounded-xl text-xs font-bold border ${
                      newGoalType === 'ongoing_direction'
                        ? 'bg-teal-700 text-white border-teal-700'
                        : 'border-slate-300 dark:border-slate-700 text-slate-600'
                    }`}
                  >
                    ♾️ Ongoing Goal
                  </button>
                </div>
              </div>
              <div className="flex justify-end">
                <button
                  type="submit"
                  className="min-h-[44px] px-5 py-2 rounded-xl bg-teal-700 text-white text-xs font-bold"
                >
                  Goal Add Karo & Plan Kholo →
                </button>
              </div>
            </div>
          )}
        </form>
      )}

      {/* 4. FULL GOAL WORKSPACE MODAL: STEP 1 (EDIT) -> STEP 2 (PLAN) -> STEP 3 (AAGE KA PROCESS / DAILY TASKS) */}
      {activeGoal && (
        <div
          className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 backdrop-blur-xs p-0 sm:p-4 overflow-y-auto"
          role="dialog"
          aria-modal="true"
          aria-labelledby="goal-workspace-title"
        >
          <div className="w-full max-w-2xl max-h-[92vh] overflow-y-auto rounded-t-3xl sm:rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 sm:p-6 shadow-2xl space-y-5">
            {/* Modal Top Header */}
            <div className="flex items-start justify-between gap-3 border-b border-slate-100 dark:border-slate-800 pb-3.5">
              <div>
                <p className="text-xs font-bold uppercase tracking-wider text-teal-700 dark:text-teal-400">
                  {state.lifeAreas.find((a) => a.id === activeGoal.lifeAreaId)
                    ?.name || 'Goal'}{' '}
                  ·{' '}
                  {activeGoal.goalType === 'ongoing_direction'
                    ? '♾️ Ongoing Goal'
                    : '🎯 Goal'}
                </p>
                <h2
                  id="goal-workspace-title"
                  className="text-lg sm:text-xl font-bold text-slate-900 dark:text-slate-100 mt-0.5"
                >
                  {activeGoal.title}
                </h2>
              </div>
              <button
                type="button"
                onClick={() => setActiveGoalId(null)}
                aria-label="Close Goal Workspace"
                className="min-h-[40px] min-w-[40px] rounded-xl flex items-center justify-center text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* 3-Step Pipeline Bar: 1. Edit Goal -> 2. Plan (Steps) -> 3. Aage ka Process (Tasks) */}
            <div className="grid grid-cols-3 gap-2 p-1.5 rounded-2xl bg-slate-100 dark:bg-slate-950 border border-slate-200 dark:border-slate-800">
              <button
                type="button"
                onClick={() => setDetailStep('edit')}
                className={`min-h-[42px] px-3 py-2 rounded-xl text-xs font-bold transition-all ${
                  detailStep === 'edit'
                    ? 'bg-teal-700 text-white shadow-2xs'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                }`}
              >
                1. Pura Edit Karo
              </button>
              <button
                type="button"
                onClick={() => setDetailStep('plan')}
                className={`min-h-[42px] px-3 py-2 rounded-xl text-xs font-bold transition-all ${
                  detailStep === 'plan'
                    ? 'bg-teal-700 text-white shadow-2xs'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                }`}
              >
                2. Plan (Steps)
              </button>
              <button
                type="button"
                onClick={() => setDetailStep('process')}
                className={`min-h-[42px] px-3 py-2 rounded-xl text-xs font-bold transition-all ${
                  detailStep === 'process'
                    ? 'bg-teal-700 text-white shadow-2xs'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                }`}
              >
                3. Aage Ka Process
              </button>
            </div>

            {/* STEP 1: PURA EDIT KARO */}
            {detailStep === 'edit' && (
              <form onSubmit={handleSaveGoalEdits} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Goal Title *
                  </label>
                  <input
                    type="text"
                    required
                    value={editTitle}
                    onChange={(e) => setEditTitle(e.target.value)}
                    className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3.5 py-2.5 text-base font-medium"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      Category (Health, Finance, Relationship...)
                    </label>
                    <select
                      value={editAreaId}
                      onChange={(e) => setEditAreaId(e.target.value)}
                      className="w-full min-h-[44px] rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-3 py-2 text-sm font-medium"
                    >
                      {activeLifeAreas.map((area) => (
                        <option key={area.id} value={area.id}>
                          {area.name}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      Goal Type
                    </label>
                    <div className="grid grid-cols-2 gap-1.5">
                      <button
                        type="button"
                        onClick={() => setEditGoalType('outcome')}
                        className={`min-h-[44px] px-2.5 py-1.5 rounded-xl text-xs font-bold border ${
                          editGoalType === 'outcome'
                            ? 'bg-teal-700 text-white border-teal-700'
                            : 'border-slate-300 dark:border-slate-700 text-slate-600'
                        }`}
                      >
                        🎯 Goal
                      </button>
                      <button
                        type="button"
                        onClick={() => setEditGoalType('ongoing_direction')}
                        className={`min-h-[44px] px-2.5 py-1.5 rounded-xl text-xs font-bold border ${
                          editGoalType === 'ongoing_direction'
                            ? 'bg-teal-700 text-white border-teal-700'
                            : 'border-slate-300 dark:border-slate-700 text-slate-600'
                        }`}
                      >
                        ♾️ Ongoing Goal
                      </button>
                    </div>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Desired Outcome / System Standard (Kya chahiye?)
                  </label>
                  <input
                    type="text"
                    value={editOutcome}
                    onChange={(e) => setEditOutcome(e.target.value)}
                    placeholder="Apne shabdon me likhein..."
                    className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3.5 py-2 text-sm"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Personal Reason (Mere liye kyun zaruri hai?)
                  </label>
                  <input
                    type="text"
                    value={editReason}
                    onChange={(e) => setEditReason(e.target.value)}
                    placeholder="Kyun zaruri hai..."
                    className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3.5 py-2 text-sm"
                  />
                </div>

                {/* Tags */}
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    #Tags (Optional)
                  </label>
                  <div className="flex flex-wrap gap-1.5 mb-2">
                    {PRESET_GOAL_TAGS.map((tag) => {
                      const active = editTags.includes(tag);
                      return (
                        <button
                          key={tag}
                          type="button"
                          onClick={() =>
                            setEditTags((prev) =>
                              prev.includes(tag)
                                ? prev.filter((t) => t !== tag)
                                : [...prev, tag]
                            )
                          }
                          className={`min-h-[28px] px-2.5 py-0.5 rounded-lg text-xs font-mono border ${
                            active
                              ? 'bg-teal-700 text-white border-teal-700 font-semibold'
                              : 'bg-slate-50 dark:bg-slate-950 text-slate-600 dark:text-slate-400 border-slate-300 dark:border-slate-700'
                          }`}
                        >
                          {formatTagLabel(tag)}
                        </button>
                      );
                    })}
                  </div>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={editCustomTag}
                      onChange={(e) => setEditCustomTag(e.target.value)}
                      placeholder="Custom #tag..."
                      className="flex-1 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 py-1.5 text-xs"
                    />
                    <button
                      type="button"
                      onClick={() => {
                        const clean = normalizeGoalTags([editCustomTag]);
                        if (clean.length > 0) {
                          setEditTags((prev) =>
                            normalizeGoalTags([...prev, ...clean])
                          );
                          setEditCustomTag('');
                        }
                      }}
                      className="min-h-[34px] px-3 py-1 rounded-lg bg-slate-200 dark:bg-slate-800 text-xs font-semibold"
                    >
                      + Tag
                    </button>
                  </div>
                </div>

                <div className="flex items-center justify-between gap-2 pt-3 border-t border-slate-100 dark:border-slate-800">
                  <button
                    type="button"
                    onClick={() => {
                      updateGoal(activeGoal.id, {
                        status:
                          activeGoal.status === 'paused' ? 'active' : 'paused',
                      });
                      setActiveGoalId(null);
                    }}
                    className="min-h-[42px] px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-600 dark:text-slate-300 flex items-center gap-1.5"
                  >
                    {activeGoal.status === 'paused' ? (
                      <>
                        <Play className="w-3.5 h-3.5" />
                        <span>Resume Goal</span>
                      </>
                    ) : (
                      <>
                        <Pause className="w-3.5 h-3.5" />
                        <span>Pause Goal</span>
                      </>
                    )}
                  </button>

                  <button
                    type="submit"
                    className="min-h-[44px] px-6 py-2.5 rounded-xl bg-teal-700 hover:bg-teal-600 text-white text-xs sm:text-sm font-bold flex items-center gap-2"
                  >
                    <span>Save Edit & Aage Plan Karo</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </form>
            )}

            {/* STEP 2: PLAN BANAYEIN (MILESTONES / STEPS) */}
            {detailStep === 'plan' && (
              <div className="space-y-4">
                <div className="flex items-center justify-between gap-2">
                  <div>
                    <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
                      Step-by-Step Plan (Milestones)
                    </h3>
                    <p className="text-xs text-slate-500">
                      Is goal ko poora karne ke mukhya padav (checkpoints) yahan banayein.
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => handleAiSuggestMilestones(activeGoal)}
                    disabled={aiBreakdownLoading}
                    className="min-h-[36px] px-3 py-1.5 rounded-xl bg-teal-50 dark:bg-teal-950/60 text-teal-800 dark:text-teal-300 text-xs font-semibold flex items-center gap-1.5 shrink-0"
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>
                      {aiBreakdownLoading
                        ? 'Drafting...'
                        : 'AI Se Plan Suggest Karo'}
                    </span>
                  </button>
                </div>

                {aiSuggestedMilestones.length > 0 && (
                  <div className="rounded-xl border border-teal-200 dark:border-teal-900 bg-teal-50/50 dark:bg-teal-950/30 p-3 space-y-2">
                    <p className="text-xs font-semibold text-teal-900 dark:text-teal-200">
                      AI Suggested Steps (Tap karke Plan me jodein):
                    </p>
                    <div className="flex flex-wrap gap-2">
                      {aiSuggestedMilestones.map((msText, i) => (
                        <button
                          key={i}
                          type="button"
                          onClick={() => {
                            createMilestone({
                              goalId: activeGoal.id,
                              title: msText,
                            });
                            setAiSuggestedMilestones((prev) =>
                              prev.filter((_, idx) => idx !== i)
                            );
                          }}
                          className="min-h-[34px] px-3 py-1 rounded-lg bg-white dark:bg-slate-900 border border-teal-300 dark:border-teal-800 text-xs text-slate-800 dark:text-slate-200"
                        >
                          + {msText}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {(() => {
                  const goalMilestones = state.milestones
                    .filter((m) => m.goalId === activeGoal.id)
                    .sort((a, b) => a.seq - b.seq);

                  return (
                    <div className="space-y-2">
                      {goalMilestones.length === 0 ? (
                        <div className="rounded-xl border border-dashed border-slate-300 dark:border-slate-700 p-5 text-center text-xs text-slate-500">
                          Abhi koi milestone step nahi joda gaya hai. Niche likh kar pehla step jodein.
                        </div>
                      ) : (
                        <div className="divide-y divide-slate-100 dark:divide-slate-800 border border-slate-200 dark:border-slate-800 rounded-xl">
                          {goalMilestones.map((ms, idx) => (
                            <div
                              key={ms.id}
                              className="p-3 flex items-center justify-between gap-3"
                            >
                              <button
                                type="button"
                                onClick={() =>
                                  updateMilestone(ms.id, {
                                    status:
                                      ms.status === 'done' ? 'todo' : 'done',
                                  })
                                }
                                className="flex items-center gap-2.5 text-left"
                              >
                                <span
                                  className={`w-5 h-5 rounded-md border flex items-center justify-center ${
                                    ms.status === 'done'
                                      ? 'bg-emerald-600 border-emerald-600 text-white'
                                      : 'border-slate-400'
                                  }`}
                                >
                                  {ms.status === 'done' && (
                                    <Check className="w-3.5 h-3.5" />
                                  )}
                                </span>
                                <span
                                  className={`text-sm font-medium ${
                                    ms.status === 'done'
                                      ? 'line-through text-slate-400'
                                      : 'text-slate-800 dark:text-slate-200'
                                  }`}
                                >
                                  {idx + 1}. {ms.title}
                                </span>
                              </button>

                              <div className="flex items-center gap-1">
                                <button
                                  type="button"
                                  disabled={idx === 0}
                                  onClick={() => reorderMilestone(ms.id, 'up')}
                                  className="min-h-[34px] min-w-[34px] flex items-center justify-center rounded-lg text-slate-500 disabled:opacity-30 hover:bg-slate-100 dark:hover:bg-slate-800"
                                >
                                  <ArrowUp className="w-3.5 h-3.5" />
                                </button>
                                <button
                                  type="button"
                                  disabled={idx === goalMilestones.length - 1}
                                  onClick={() =>
                                    reorderMilestone(ms.id, 'down')
                                  }
                                  className="min-h-[34px] min-w-[34px] flex items-center justify-center rounded-lg text-slate-500 disabled:opacity-30 hover:bg-slate-100 dark:hover:bg-slate-800"
                                >
                                  <ArrowDown className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}

                      <div className="flex gap-2 pt-1">
                        <input
                          type="text"
                          value={newMilestoneTitle}
                          onChange={(e) => setNewMilestoneTitle(e.target.value)}
                          placeholder="Naya plan step / milestone likhein..."
                          className="flex-1 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3.5 py-2.5 text-sm"
                        />
                        <button
                          type="button"
                          onClick={() => {
                            if (!newMilestoneTitle.trim()) return;
                            createMilestone({
                              goalId: activeGoal.id,
                              title: newMilestoneTitle.trim(),
                            });
                            setNewMilestoneTitle('');
                          }}
                          className="min-h-[42px] px-4 py-2 rounded-xl bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 text-xs font-bold whitespace-nowrap"
                        >
                          + Step Jodo
                        </button>
                      </div>
                    </div>
                  );
                })()}

                <div className="flex items-center justify-between pt-3 border-t border-slate-100 dark:border-slate-800">
                  <button
                    type="button"
                    onClick={() => setDetailStep('edit')}
                    className="min-h-[42px] px-4 py-2 rounded-xl text-xs font-semibold text-slate-600"
                  >
                    ← Back to Edit
                  </button>
                  <button
                    type="button"
                    onClick={() => setDetailStep('process')}
                    className="min-h-[44px] px-6 py-2.5 rounded-xl bg-teal-700 hover:bg-teal-600 text-white text-xs sm:text-sm font-bold flex items-center gap-2"
                  >
                    <span>Aage Ka Process (Daily Tasks)</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            )}

            {/* STEP 3: AAGE KA PROCESS (DAILY TASKS / EXECUTION) */}
            {detailStep === 'process' && (
              <div className="space-y-4">
                <div>
                  <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
                    Aage Ka Process — Daily Tasks & Next Actions
                  </h3>
                  <p className="text-xs text-slate-500">
                    Is goal ko rozana aage badhane ke liye tasks jodein ya yahin se tick karein.
                  </p>
                </div>

                {/* Add New Task Linked to this Goal */}
                <div className="rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 p-3.5 space-y-3">
                  <input
                    type="text"
                    value={newTaskTitle}
                    onChange={(e) => setNewTaskTitle(e.target.value)}
                    placeholder={`Agla physical action kya hai? (${STRINGS.today.taskQualityHint})`}
                    className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-3.5 py-2.5 text-sm"
                  />
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <input
                        type="date"
                        value={newTaskDate}
                        onChange={(e) => setNewTaskDate(e.target.value)}
                        className="min-h-[38px] rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-2.5 py-1 text-xs font-mono"
                      />
                      <input
                        type="number"
                        min={5}
                        max={240}
                        value={newTaskEstMinutes}
                        onChange={(e) =>
                          setNewTaskEstMinutes(Number(e.target.value))
                        }
                        className="w-20 min-h-[38px] rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-2.5 py-1 text-xs font-mono"
                      />
                      <span className="text-xs text-slate-500">min</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        if (!newTaskTitle.trim()) return;
                        createTask({
                          goalId: activeGoal.id,
                          title: newTaskTitle.trim(),
                          nextAction: newTaskTitle.trim(),
                          scheduledDate: newTaskDate || today,
                          estMinutes: newTaskEstMinutes,
                        });
                        setNewTaskTitle('');
                      }}
                      className="min-h-[40px] px-4 py-2 rounded-xl bg-teal-700 hover:bg-teal-600 text-white text-xs font-bold"
                    >
                      + Daily Task Jodo
                    </button>
                  </div>
                </div>

                {/* Linked Tasks List with AnimatedCheckButton */}
                {(() => {
                  const goalTasks = state.tasks.filter(
                    (t) =>
                      t.goalId === activeGoal.id && t.status !== 'cancelled'
                  );

                  if (goalTasks.length === 0) {
                    return (
                      <div className="rounded-xl border border-dashed border-slate-300 dark:border-slate-700 p-5 text-center text-xs text-slate-500">
                        Is goal me abhi koi Daily Task nahi hai. Upar se pehla action jodein.
                      </div>
                    );
                  }

                  return (
                    <div className="space-y-2">
                      {goalTasks.map((task) => {
                        const isDone =
                          task.status === 'done' ||
                          completingTaskIds.includes(task.id);
                        return (
                          <div
                            key={task.id}
                            className={`p-3 rounded-xl border flex items-center justify-between gap-3 transition-colors ${
                              isDone
                                ? 'bg-emerald-50/70 dark:bg-emerald-950/30 border-emerald-300 dark:border-emerald-800'
                                : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800'
                            }`}
                          >
                            <div className="flex items-center gap-3 min-w-0">
                              <AnimatedCheckButton
                                checked={isDone}
                                celebrating={completingTaskIds.includes(task.id)}
                                onToggle={() =>
                                  handleToggleGoalTask(
                                    task.id,
                                    task.status === 'done'
                                  )
                                }
                                ariaLabel={`Complete task ${task.title}`}
                              />
                              <div className="min-w-0">
                                <p
                                  className={`text-sm font-medium ${
                                    isDone
                                      ? 'line-through text-emerald-800 dark:text-emerald-300'
                                      : 'text-slate-900 dark:text-slate-100'
                                  }`}
                                >
                                  {task.title}
                                </p>
                                <p className="text-[11px] font-mono text-slate-500">
                                  {task.scheduledDate || 'No date'} ·{' '}
                                  {task.estMinutes || 20} min
                                </p>
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  );
                })()}

                <div className="flex items-center justify-between pt-3 border-t border-slate-100 dark:border-slate-800">
                  <button
                    type="button"
                    onClick={() => setDetailStep('plan')}
                    className="min-h-[42px] px-4 py-2 rounded-xl text-xs font-semibold text-slate-600"
                  >
                    ← Back to Plan
                  </button>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        setActiveGoalId(null);
                        setActiveTab('today');
                      }}
                      className="min-h-[42px] px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5"
                    >
                      <CheckSquare className="w-3.5 h-3.5 text-teal-600" />
                      <span>Aaj Screen Par Dekho</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setActiveGoalId(null)}
                      className="min-h-[42px] px-5 py-2 rounded-xl bg-teal-700 text-white text-xs font-bold"
                    >
                      Done ✓
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
