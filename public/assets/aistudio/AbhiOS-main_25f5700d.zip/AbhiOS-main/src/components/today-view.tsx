'use client';

import React, { useEffect, useMemo, useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import {
  AlertTriangle,
  Check,
  Clock,
  Droplets,
  RotateCcw,
  Sparkles,
  Sun,
  Briefcase,
  Moon,
  Scissors,
  Calendar,
  ChevronRight,
  SkipForward,
  Play,
  Pause,
  Square,
  Timer,
  MoreHorizontal,
  ChevronDown,
  Eye,
  Zap,
} from 'lucide-react';
import { useGoalOs } from '@/src/context/goal-os-context';
import { STRINGS } from '@/src/lib/strings';
import {
  addDays,
  computeRoutineDueMinutes,
  formatMinutesToTime,
  weekStartMonday,
} from '@/src/lib/logic/dates';
import {
  computeFocusProgress,
  computeTodayMomentum,
  DUTY_SHIFT_PRESETS,
  filterRoutinesForToday,
  formatFocusSeconds,
  generateTwoMinuteStarter,
  suggestDayTasks,
  suggestIfThenPlan,
  suggestMainPriority,
} from '@/src/lib/logic/planner';
import {
  computeNeedsAttention,
  shouldShowReEntry,
} from '@/src/lib/logic/attention';
import { RoutineBlock, Task } from '@/src/lib/types';
import {
  AnimatedCheckButton,
  playCompletionCelebrationSound,
} from '@/src/components/animated-check-button';

export function TodayView() {
  const {
    state,
    today,
    todayPlan,
    upsertTodayPlan,
    toggleRoutineDone,
    skipRoutineToday,
    addWater,
    completeTask,
    reopenTask,
    rescheduleTask,
    splitTaskIntoSubtasks,
    updateTask,
    saveDailyReview,
    saveWeeklyReview,
    performFreshStartCleanup,
    setActiveTab,
    setActiveQualityGateGoalId,
  } = useGoalOs();

  const [showAttentionSheet, setShowAttentionSheet] = useState(false);
  const [showDailyReview, setShowDailyReview] = useState(false);
  const [showWeeklyReview, setShowWeeklyReview] = useState(false);
  const [splittingTaskId, setSplittingTaskId] = useState<string | null>(null);
  const [splitLinesText, setSplitLinesText] = useState('');
  const [showShiftPresets, setShowShiftPresets] = useState(false);
  const [expandedTaskMenuId, setExpandedTaskMenuId] = useState<string | null>(
    null
  );
  const [showCompletedToday, setShowCompletedToday] = useState(true);
  const [zenMode, setZenMode] = useState(false);
  const [collapsedBlocks, setCollapsedBlocks] = useState<
    Record<string, boolean>
  >({});

  // Satisfying Task & Routine Tick Celebration State
  const [celebratingId, setCelebratingId] = useState<string | null>(null);
  const [completingIds, setCompletingIds] = useState<Record<string, boolean>>(
    {}
  );
  const [celebrationBanner, setCelebrationBanner] = useState<string | null>(
    null
  );

  const triggerTickCelebration = (id: string, title: string) => {
    playCompletionCelebrationSound();
    setCelebratingId(id);
    setCelebrationBanner(`✓ "${title}" pura ho gaya! Shabaash!`);
    window.setTimeout(() => {
      setCelebratingId((prev) => (prev === id ? null : prev));
    }, 950);
    window.setTimeout(() => {
      setCelebrationBanner((prev) =>
        prev?.includes(title) ? null : prev
      );
    }, 2800);
  };

  const handleTickTaskWithDelight = (task: Task) => {
    if (task.status === 'done') {
      reopenTask(task.id);
      return;
    }
    if (completingIds[task.id]) return;

    triggerTickCelebration(task.id, task.title);
    setCompletingIds((prev) => ({ ...prev, [task.id]: true }));
    setExpandedTaskMenuId(null);

    // Stage the state transition slightly so the user clearly sees the spring check draw,
    // particle burst, and strikethrough sweep before the card moves to Completed!
    window.setTimeout(() => {
      completeTask(task.id);
      setCompletingIds((prev) => {
        const next = { ...prev };
        delete next[task.id];
        return next;
      });
    }, 460);
  };

  const handleTickRoutineWithDelight = (
    routineId: string,
    routineTitle: string,
    currentlyDone: boolean
  ) => {
    if (!currentlyDone) {
      triggerTickCelebration(routineId, routineTitle);
    }
    toggleRoutineDone(routineId);
  };

  // Flexible Focus Timer state
  const [focusTaskId, setFocusTaskId] = useState<string | null>(null);
  const [focusTotalSec, setFocusTotalSec] = useState<number>(25 * 60);
  const [focusRemainingSec, setFocusRemainingSec] = useState<number>(25 * 60);
  const [focusRunning, setFocusRunning] = useState<boolean>(false);

  useEffect(() => {
    if (!focusRunning) return;
    const interval = window.setInterval(() => {
      setFocusRemainingSec((prev) => {
        if (prev <= 1) {
          setFocusRunning(false);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => window.clearInterval(interval);
  }, [focusRunning]);

  const startFocusOnTask = (task: Task, customMinutes?: number) => {
    const mins = customMinutes ?? (task.estMinutes || 25);
    const secs = Math.max(60, mins * 60);
    setFocusTaskId(task.id);
    setFocusTotalSec(secs);
    setFocusRemainingSec(secs);
    setFocusRunning(true);
  };

  // Daily Review form state
  const [surpriseText, setSurpriseText] = useState('');
  const [changeTomorrow, setChangeTomorrow] = useState('');

  // Weekly Review form state
  const [weeklyAccomplishments, setWeeklyAccomplishments] = useState('');
  const [weeklyChallenges, setWeeklyChallenges] = useState('');
  const [weeklyDecisions, setWeeklyDecisions] = useState('');
  const [weeklyNextPriorities, setWeeklyNextPriorities] = useState('');

  const activeGoalIds = useMemo(
    () =>
      new Set(
        state.goals.filter((g) => g.status === 'active').map((g) => g.id)
      ),
    [state.goals]
  );

  const attention = useMemo(
    () =>
      computeNeedsAttention({
        tasks: state.tasks,
        inboxItems: state.inboxItems,
        goals: state.goals,
        today,
      }),
    [state.tasks, state.inboxItems, state.goals, today]
  );

  const showReEntryBanner = useMemo(
    () => shouldShowReEntry(state.settings.lastActiveDate, today),
    [state.settings.lastActiveDate, today]
  );

  const dayPlanRecommendations = useMemo(
    () =>
      suggestDayTasks(
        state.tasks,
        state.settings.dailyWorkloadMinutes || 120,
        today,
        activeGoalIds,
        todayPlan.mainTaskId
      ),
    [
      state.tasks,
      state.settings.dailyWorkloadMinutes,
      today,
      activeGoalIds,
      todayPlan.mainTaskId,
    ]
  );

  const mainPriorityTask = dayPlanRecommendations.mainTask;

  const todayTasks = useMemo(() => {
    const allDueOrScheduled = state.tasks.filter(
      (t) =>
        (t.status === 'todo' || t.status === 'doing') &&
        (t.scheduledDate === today || (t.dueDate && t.dueDate <= today))
    );
    if (todayPlan.minimumDay) {
      // Minimum Viable Day: Main priority + max 1 extra task
      const list: Task[] = [];
      if (mainPriorityTask) list.push(mainPriorityTask);
      const second = allDueOrScheduled.find(
        (t) => t.id !== mainPriorityTask?.id
      );
      if (second) list.push(second);
      return list;
    }
    return allDueOrScheduled;
  }, [state.tasks, today, todayPlan.minimumDay, mainPriorityTask]);

  const completedTodayTasks = useMemo(
    () =>
      state.tasks.filter(
        (t) =>
          t.status === 'done' &&
          (t.scheduledDate === today ||
            t.dueDate === today ||
            (t.completedAt && t.completedAt.startsWith(today)))
      ),
    [state.tasks, today]
  );

  const todayRoutines = useMemo(
    () => filterRoutinesForToday(state.routines, today, todayPlan),
    [state.routines, today, todayPlan]
  );

  const waterRoutine = useMemo(
    () =>
      todayRoutines.find((r) => (r.targetValue ?? 0) > 0 && r.unit === 'ml') ||
      state.routines.find((r) => (r.targetValue ?? 0) > 0 && r.unit === 'ml'),
    [todayRoutines, state.routines]
  );

  const booleanRoutines = useMemo(
    () => todayRoutines.filter((r) => r.id !== waterRoutine?.id),
    [todayRoutines, waterRoutine]
  );

  const logByRoutineId = useMemo(() => {
    const map = new Map<string, (typeof state.routineLogs)[number]>();
    for (const l of state.routineLogs) {
      if (l.logDate === today) {
        map.set(l.routineId, l);
      }
    }
    return map;
  }, [state.routineLogs, today]);

  const waterLog = waterRoutine ? logByRoutineId.get(waterRoutine.id) : null;
  const waterValue = waterLog?.value ?? 0;
  const waterTarget = waterRoutine?.targetValue ?? 2500;
  const waterPercent = Math.min(
    100,
    Math.round((waterValue / waterTarget) * 100)
  );

  const completedRoutinesCount = useMemo(
    () =>
      booleanRoutines.filter(
        (r) => logByRoutineId.get(r.id)?.status === 'done'
      ).length,
    [booleanRoutines, logByRoutineId]
  );

  const momentum = useMemo(
    () =>
      computeTodayMomentum({
        todayCompletedCount: completedTodayTasks.length,
        todayPendingCount: todayTasks.length,
        routinesDoneCount: completedRoutinesCount,
        routinesTotalCount: booleanRoutines.length,
      }),
    [
      completedTodayTasks.length,
      todayTasks.length,
      completedRoutinesCount,
      booleanRoutines.length,
    ]
  );

  const totalScheduledMinutes = useMemo(
    () =>
      todayTasks.reduce((sum, t) => sum + (t.estMinutes ?? 25), 0),
    [todayTasks]
  );

  const handleAutoSuggestMainPriority = () => {
    const best = suggestMainPriority(state.tasks, today, activeGoalIds);
    if (best) {
      upsertTodayPlan({ mainTaskId: best.id });
    }
  };

  const blocks: Array<{ key: RoutineBlock; label: string; icon: React.ReactNode }> = [
    { key: 'morning', label: 'Subah (Morning)', icon: <Sun className="w-4 h-4" /> },
    { key: 'duty', label: 'Duty Preparation', icon: <Briefcase className="w-4 h-4" /> },
    { key: 'evening', label: 'Shaam (Evening)', icon: <Moon className="w-4 h-4" /> },
    { key: 'anytime', label: 'Anytime', icon: <Clock className="w-4 h-4" /> },
  ];

  return (
    <div className="space-y-6">
      {/* 1. Today Context Strip: Clean Date, Duty/Off-Day, Minimum Viable Day & Momentum Bar */}
      <section className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-4 sm:p-5">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-3">
          <div>
            <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400 font-mono tabular-nums">
              <span>Aaj · {today}</span>
              <span>·</span>
              <span>
                {todayPlan.isOff
                  ? 'Off Day (Chhutti)'
                  : `Duty ${todayPlan.dutyStart || '08:30'}`}
              </span>
            </div>
            <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-slate-100 mt-0.5">
              Aaj Ka Focus & Execution
            </h1>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {/* Off Day Toggle */}
            <button
              type="button"
              onClick={() => upsertTodayPlan({ isOff: !todayPlan.isOff })}
              className={`min-h-[40px] px-3 py-1.5 rounded-xl text-xs font-semibold transition-colors whitespace-nowrap shrink-0 border ${
                todayPlan.isOff
                  ? 'bg-amber-600 text-white border-amber-600'
                  : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-200 border-slate-200 dark:border-slate-700'
              }`}
            >
              {todayPlan.isOff ? 'Off Day: ON' : 'Duty Day'}
            </button>

            {/* Duty Start Time Input (if not Off Day) */}
            {!todayPlan.isOff && (
              <label className="min-h-[40px] flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-medium text-slate-700 dark:text-slate-200">
                <span>Duty:</span>
                <input
                  type="time"
                  aria-label="Duty Start Time"
                  value={todayPlan.dutyStart || '08:30'}
                  onChange={(e) =>
                    upsertTodayPlan({ dutyStart: e.target.value })
                  }
                  className="bg-transparent font-mono tabular-nums text-xs font-bold text-slate-900 dark:text-slate-100 focus:outline-none"
                />
              </label>
            )}

            {/* Shift Presets Progressive Disclosure Toggle */}
            <button
              type="button"
              onClick={() => setShowShiftPresets((v) => !v)}
              className="min-h-[40px] px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 flex items-center gap-1"
            >
              <span>Shift Presets</span>
              <ChevronDown
                className={`w-3.5 h-3.5 transition-transform ${
                  showShiftPresets ? 'rotate-180' : ''
                }`}
              />
            </button>

            {/* Minimum Viable Day Toggle */}
            <button
              type="button"
              onClick={() =>
                upsertTodayPlan({ minimumDay: !todayPlan.minimumDay })
              }
              className={`min-h-[40px] px-3 py-1.5 rounded-xl text-xs font-semibold transition-colors whitespace-nowrap shrink-0 border ${
                todayPlan.minimumDay
                  ? 'bg-teal-700 text-white border-teal-700'
                  : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-200 border-slate-200 dark:border-slate-700'
              }`}
            >
              {todayPlan.minimumDay ? 'Minimum Day: ON' : 'Minimum Day'}
            </button>

            {/* Zen Single-Focus Mode Toggle */}
            <button
              type="button"
              onClick={() => setZenMode((v) => !v)}
              data-testid="zen-mode-toggle"
              className={`min-h-[40px] px-3 py-1.5 rounded-xl text-xs font-semibold transition-colors whitespace-nowrap shrink-0 border flex items-center gap-1.5 ${
                zenMode
                  ? 'bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 border-slate-900 dark:border-slate-100'
                  : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-200 border-slate-200 dark:border-slate-700 hover:bg-slate-100'
              }`}
            >
              <Eye className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400" />
              <span>{zenMode ? 'Zen Focus: ON' : 'Zen Focus'}</span>
            </button>
          </div>
        </div>

        {/* Collapsible 1-Tap Duty Roster / Shift Presets */}
        {showShiftPresets && (
          <div className="mt-3 pt-3 border-t border-slate-100 dark:border-slate-800/80 flex flex-wrap items-center gap-2">
            <span className="text-xs font-medium text-slate-500 dark:text-slate-400 mr-1">
              1-Tap Shift Preset:
            </span>
            {DUTY_SHIFT_PRESETS.map((preset) => {
              const isSelected = preset.isOff
                ? todayPlan.isOff
                : !todayPlan.isOff && todayPlan.dutyStart === preset.dutyStart;
              return (
                <button
                  key={preset.id}
                  type="button"
                  onClick={() => {
                    upsertTodayPlan({
                      isOff: preset.isOff,
                      dutyStart:
                        preset.dutyStart ?? todayPlan.dutyStart ?? '08:30',
                    });
                    setShowShiftPresets(false);
                  }}
                  className={`min-h-[34px] px-3 py-1 rounded-lg text-xs font-medium transition-colors whitespace-nowrap shrink-0 border ${
                    isSelected
                      ? 'bg-teal-700/10 dark:bg-teal-500/20 border-teal-600/40 text-teal-800 dark:text-teal-300 font-semibold'
                      : 'bg-slate-50 dark:bg-slate-800/60 border-slate-200 dark:border-slate-700/70 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
                  }`}
                >
                  {preset.label}
                </button>
              );
            })}
          </div>
        )}

        {/* Aaj Ka Momentum Progress Bar */}
        <div
          data-testid="today-momentum-bar"
          className="mt-3.5 pt-3 border-t border-slate-100 dark:border-slate-800/80 space-y-1.5"
        >
          <div className="flex items-center justify-between text-xs">
            <span className="font-semibold text-slate-700 dark:text-slate-200 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
              Aaj Ka Momentum: {completedTodayTasks.length} Tasks +{' '}
              {completedRoutinesCount} Routines Done · {momentum.encouragement}
            </span>
            <span className="font-mono font-bold text-emerald-700 dark:text-emerald-400">
              {momentum.completedUnits} / {momentum.totalUnits} ({momentum.percent}%)
            </span>
          </div>
          <div className="w-full h-2.5 rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden">
            <motion.div
              className="h-full bg-gradient-to-r from-teal-600 to-emerald-500 rounded-full"
              initial={{ width: 0 }}
              animate={{ width: `${momentum.percent}%` }}
              transition={{ type: 'spring', stiffness: 120, damping: 18 }}
            />
          </div>
        </div>

        {/* Satisfying Celebration Toast Banner on Task/Routine Tick */}
        <AnimatePresence>
          {celebrationBanner && (
            <motion.div
              data-testid="tick-celebration-banner"
              initial={{ opacity: 0, y: -10, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -6, scale: 0.95 }}
              transition={{ type: 'spring', stiffness: 360, damping: 22 }}
              className="mt-3 rounded-xl bg-emerald-600 text-white px-4 py-2.5 text-xs font-bold flex items-center justify-between shadow-lg shadow-emerald-600/25"
            >
              <span className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 shrink-0" />
                {celebrationBanner}
              </span>
              <span className="font-mono text-[11px] bg-white/20 px-2 py-0.5 rounded-md">
                Momentum {momentum.percent}%
              </span>
            </motion.div>
          )}
        </AnimatePresence>

        {todayPlan.minimumDay && (
          <p className="mt-3 text-xs text-teal-800 dark:text-teal-300 bg-teal-50/70 dark:bg-teal-950/40 rounded-xl px-3.5 py-2">
            {STRINGS.today.minimumDayDesc}
          </p>
        )}

        {zenMode && (
          <div className="mt-3 rounded-xl bg-slate-900 dark:bg-slate-800 text-slate-100 px-3.5 py-2.5 text-xs flex items-center justify-between gap-2">
            <span>
              🧘 <strong>Zen Single-Focus Mode Active:</strong> Baaki lists shant hain — sirf 1 Main Priority aur Hydration par dhyan dein.
            </span>
            <button
              type="button"
              onClick={() => setZenMode(false)}
              className="px-2.5 py-1 rounded-lg bg-white/15 hover:bg-white/25 text-white font-semibold shrink-0"
            >
              Show Full Day
            </button>
          </div>
        )}
      </section>

      {/* 2. Gap Re-Entry Banner (Section 8.9: > 3 days gap, zero guilt) */}
      {showReEntryBanner && (
        <section className="rounded-2xl bg-amber-50/90 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="text-base font-bold text-amber-950 dark:text-amber-100">
              {STRINGS.today.reEntryTitle}
            </h2>
            <p className="text-xs text-amber-800 dark:text-amber-300 mt-1">
              {STRINGS.today.reEntrySubtitle}
            </p>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={performFreshStartCleanup}
              className="min-h-[44px] px-4 py-2 rounded-xl bg-amber-700 hover:bg-amber-600 text-white text-xs font-semibold whitespace-nowrap"
            >
              {STRINGS.today.reEntryCleanBtn(
                attention.overdueTasks.length + attention.staleTasks.length
              )}
            </button>
          </div>
        </section>
      )}

      {/* 3. Needs Attention Banner */}
      {(attention.totalCount > 0 || attention.oldInboxItems.length > 0) && (
        <section className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-4">
          <div className="flex items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0" />
              <div>
                <h2 className="text-sm font-bold text-slate-900 dark:text-slate-100">
                  {STRINGS.today.needsAttention}
                </h2>
                <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500 dark:text-slate-400 mt-0.5 font-mono tabular-nums">
                  {attention.overdueTasks.length > 0 && (
                    <span>{attention.overdueTasks.length} overdue</span>
                  )}
                  {attention.staleTasks.length > 0 && (
                    <>
                      <span>·</span>
                      <span>
                        {attention.staleTasks.length} stale (14+ din, review karein)
                      </span>
                    </>
                  )}
                  {attention.rescheduleHeavyTasks.length > 0 && (
                    <>
                      <span>·</span>
                      <span>
                        {attention.rescheduleHeavyTasks.length} task 3+ baar टला
                      </span>
                    </>
                  )}
                  {attention.oldInboxItems.length > 0 && (
                    <>
                      <span>·</span>
                      <span>
                        {attention.oldInboxItems.length} inbox thoughts 2+ din purane
                      </span>
                    </>
                  )}
                </div>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setShowAttentionSheet((v) => !v)}
              className="min-h-[44px] px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 whitespace-nowrap shrink-0"
            >
              {showAttentionSheet ? 'Chhupao' : 'Dekho & Suljhao'}
            </button>
          </div>

          {showAttentionSheet && (
            <div className="mt-4 pt-4 border-t border-slate-100 dark:border-slate-800 space-y-3">
              {[...attention.overdueTasks, ...attention.staleTasks].map((t) => (
                <div
                  key={t.id}
                  className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 py-2 border-b border-slate-100 dark:border-slate-800/60 last:border-none"
                >
                  <div>
                    <p className="text-sm font-medium text-slate-900 dark:text-slate-100">
                      {t.title}
                    </p>
                    <p className="text-xs text-slate-500 font-mono tabular-nums">
                      Due: {t.dueDate} · Rescheduled: {t.rescheduleCount}x
                    </p>
                  </div>
                  <div className="flex flex-wrap items-center gap-1.5">
                    <button
                      type="button"
                      onClick={() => rescheduleTask(t.id, today)}
                      className="min-h-[40px] px-3 py-1.5 rounded-lg bg-teal-50 dark:bg-teal-950/60 text-teal-800 dark:text-teal-300 text-xs font-medium"
                    >
                      Aaj Karo
                    </button>
                    <button
                      type="button"
                      onClick={() => rescheduleTask(t.id, addDays(today, 1))}
                      className="min-h-[40px] px-3 py-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-xs font-medium"
                    >
                      Kal Karo
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setSplittingTaskId(t.id);
                        setSplitLinesText(
                          `${t.title} - Step 1\n${t.title} - Step 2`
                        );
                      }}
                      className="min-h-[40px] px-3 py-1.5 rounded-lg bg-amber-50 dark:bg-amber-950/50 text-amber-800 dark:text-amber-300 text-xs font-medium"
                    >
                      Chhota Karo (Split)
                    </button>
                    <button
                      type="button"
                      onClick={() => updateTask(t.id, { status: 'cancelled' })}
                      className="min-h-[40px] px-3 py-1.5 rounded-lg bg-rose-50 dark:bg-rose-950/40 text-rose-700 dark:text-rose-300 text-xs font-medium"
                    >
                      Cancel
                    </button>
                  </div>
                </div>
              ))}

              {attention.oldInboxItems.length > 0 && (
                <div className="flex items-center justify-between pt-1">
                  <span className="text-xs text-slate-600 dark:text-slate-400">
                    {STRINGS.inbox.oldItemsInfo(attention.oldInboxItems.length)}
                  </span>
                  <button
                    type="button"
                    onClick={() => setActiveTab('inbox')}
                    className="min-h-[40px] px-3 py-1.5 rounded-lg text-xs font-semibold text-teal-700 dark:text-teal-400 flex items-center gap-1"
                  >
                    Brain Dump Triage Kholo <ChevronRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}
            </div>
          )}
        </section>
      )}

      {/* Main 2-Column Responsive Desktop Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column (7 cols): Main Priority + Today's Tasks */}
        <div className="lg:col-span-7 space-y-6">
          {/* 4. Main Priority Card */}
          <section className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5">
            <div className="flex items-center justify-between gap-4 mb-3">
              <div>
                <p className="text-xs font-medium text-teal-700 dark:text-teal-400">
                  Focus Anchor · 1 Main Priority
                </p>
                <h2 className="text-lg font-bold text-slate-900 dark:text-slate-100">
                  {STRINGS.today.mainPriority}
                </h2>
              </div>
              <button
                type="button"
                onClick={handleAutoSuggestMainPriority}
                className="min-h-[44px] px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 flex items-center gap-1.5 whitespace-nowrap shrink-0"
              >
                <Sparkles className="w-3.5 h-3.5 text-teal-600" />
                {STRINGS.today.suggestPriority}
              </button>
            </div>

            {mainPriorityTask ? (
              <motion.div
                layout
                animate={
                  celebratingId === mainPriorityTask.id ||
                  completingIds[mainPriorityTask.id]
                    ? {
                        scale: [1, 1.015, 1],
                        borderColor: 'rgba(16, 185, 129, 0.7)',
                      }
                    : {}
                }
                transition={{ duration: 0.45 }}
                className={`rounded-xl border p-4 space-y-3 transition-colors ${
                  completingIds[mainPriorityTask.id]
                    ? 'bg-emerald-50/80 dark:bg-emerald-950/35 border-emerald-400 dark:border-emerald-700'
                    : 'bg-slate-50 dark:bg-slate-950 border-slate-200/80 dark:border-slate-800'
                }`}
              >
                <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                  <div className="flex items-start gap-3">
                    <AnimatedCheckButton
                      size="lg"
                      checked={Boolean(completingIds[mainPriorityTask.id])}
                      celebrating={
                        celebratingId === mainPriorityTask.id ||
                        Boolean(completingIds[mainPriorityTask.id])
                      }
                      onToggle={() => {
                        if (focusTaskId === mainPriorityTask.id) {
                          setFocusRunning(false);
                          setFocusTaskId(null);
                        }
                        handleTickTaskWithDelight(mainPriorityTask);
                      }}
                      ariaLabel={`Complete main priority ${mainPriorityTask.title}`}
                    />

                    <div className="space-y-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <h3
                          className={`text-base font-bold transition-all duration-300 ${
                            completingIds[mainPriorityTask.id]
                              ? 'line-through text-emerald-700 dark:text-emerald-400'
                              : 'text-slate-900 dark:text-slate-100'
                          }`}
                        >
                          {mainPriorityTask.title}
                        </h3>
                        {completingIds[mainPriorityTask.id] && (
                          <motion.span
                            initial={{ scale: 0.7, opacity: 0 }}
                            animate={{ scale: 1, opacity: 1 }}
                            className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-emerald-600 text-white text-[11px] font-bold"
                          >
                            ✓ Shabaash! Pura Hua
                          </motion.span>
                        )}
                      </div>
                      {mainPriorityTask.nextAction && (
                        <p className="text-xs text-slate-600 dark:text-slate-300">
                          Next Step: {mainPriorityTask.nextAction}
                        </p>
                      )}
                      {todayPlan.minimumDay && (
                        <p className="text-xs text-teal-800 dark:text-teal-300 bg-teal-50 dark:bg-teal-950/50 rounded-lg px-2.5 py-1.5 mt-1">
                          Shield (Agar-To):{' '}
                          {suggestIfThenPlan(
                            mainPriorityTask.title,
                            mainPriorityTask.nextAction
                          )}
                        </p>
                      )}
                      <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500 font-mono tabular-nums pt-0.5">
                        <span>{mainPriorityTask.estMinutes ?? 25} min</span>
                        {mainPriorityTask.dueDate && (
                          <>
                            <span>·</span>
                            <span>Due: {mainPriorityTask.dueDate}</span>
                          </>
                        )}
                        {mainPriorityTask.goalId && (
                          <>
                            <span>·</span>
                            <span className="font-sans">
                              Goal:{' '}
                              {state.goals.find(
                                (g) => g.id === mainPriorityTask.goalId
                              )?.title || 'Linked'}
                            </span>
                          </>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 self-end sm:self-start shrink-0">
                    <button
                      type="button"
                      onClick={() => startFocusOnTask(mainPriorityTask)}
                      aria-label={`Start Focus Timer for ${mainPriorityTask.title}`}
                      className="min-h-[42px] px-3.5 py-2 rounded-xl border border-teal-600/40 bg-teal-50/70 dark:bg-teal-950/40 hover:bg-teal-100 dark:hover:bg-teal-900/50 text-teal-800 dark:text-teal-300 text-xs font-semibold flex items-center gap-1.5 whitespace-nowrap shrink-0"
                    >
                      <Play className="w-3.5 h-3.5" />
                      Focus
                    </button>
                    <motion.button
                      type="button"
                      whileTap={{ scale: 0.92 }}
                      onClick={() => {
                        if (focusTaskId === mainPriorityTask.id) {
                          setFocusRunning(false);
                          setFocusTaskId(null);
                        }
                        handleTickTaskWithDelight(mainPriorityTask);
                      }}
                      aria-label={`Mark main priority ${mainPriorityTask.title} done`}
                      className="min-h-[42px] px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold flex items-center gap-1.5 whitespace-nowrap shrink-0 shadow-xs"
                    >
                      <Check className="w-4 h-4 stroke-[2.5]" />
                      Ho Gaya ✓
                    </motion.button>
                  </div>
                </div>
              </motion.div>
            ) : (
              <p className="text-sm text-slate-500 dark:text-slate-400">
                Aaj ke liye koi pending Main Priority nahi hai.
              </p>
            )}

            {/* Flexible Deep Work Focus Timer Panel */}
            {focusTaskId && (
              <div
                data-testid="focus-timer-panel"
                className="mt-4 rounded-xl bg-teal-950 text-teal-50 p-4 space-y-3 border border-teal-800"
              >
                <div className="flex items-center justify-between gap-3">
                  <div className="flex items-center gap-2 min-w-0">
                    <Timer className="w-4 h-4 text-teal-400 shrink-0" />
                    <div className="truncate">
                      <p className="text-[11px] uppercase tracking-wider text-teal-300 font-semibold">
                        Flexible Focus Session
                      </p>
                      <p className="text-sm font-bold truncate">
                        {state.tasks.find((t) => t.id === focusTaskId)?.title ||
                          'Focus Session'}
                      </p>
                    </div>
                  </div>
                  <span className="text-2xl font-bold font-mono tabular-nums text-white whitespace-nowrap shrink-0">
                    {formatFocusSeconds(focusRemainingSec)}
                  </span>
                </div>

                <div className="w-full h-2 rounded-full bg-teal-900 overflow-hidden">
                  <div
                    className="h-full bg-teal-400 transition-all duration-300"
                    style={{
                      width: `${computeFocusProgress(
                        focusRemainingSec,
                        focusTotalSec
                      )}%`,
                    }}
                  />
                </div>

                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-1.5">
                    {[10, 15, 25, 45].map((m) => (
                      <button
                        key={m}
                        type="button"
                        onClick={() => {
                          setFocusTotalSec(m * 60);
                          setFocusRemainingSec(m * 60);
                        }}
                        className="min-h-[34px] px-2.5 py-1 rounded-lg bg-teal-900/80 hover:bg-teal-800 text-teal-200 text-xs font-mono"
                      >
                        {m}m
                      </button>
                    ))}
                    <button
                      type="button"
                      onClick={() => {
                        setFocusTotalSec((t) => t + 300);
                        setFocusRemainingSec((r) => r + 300);
                      }}
                      className="min-h-[34px] px-2.5 py-1 rounded-lg bg-teal-900/80 hover:bg-teal-800 text-teal-200 text-xs font-mono"
                    >
                      +5m
                    </button>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setFocusRunning((r) => !r)}
                      className="min-h-[38px] px-3 py-1.5 rounded-lg bg-teal-600 hover:bg-teal-500 text-white text-xs font-semibold flex items-center gap-1"
                    >
                      {focusRunning ? (
                        <>
                          <Pause className="w-3.5 h-3.5" />
                          Pause
                        </>
                      ) : (
                        <>
                          <Play className="w-3.5 h-3.5" />
                          Resume
                        </>
                      )}
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        const target = state.tasks.find(
                          (t) => t.id === focusTaskId
                        );
                        if (target) {
                          handleTickTaskWithDelight(target);
                        } else {
                          completeTask(focusTaskId);
                        }
                        setFocusRunning(false);
                        setFocusTaskId(null);
                      }}
                      className="min-h-[38px] px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold flex items-center gap-1"
                    >
                      <Check className="w-3.5 h-3.5" />
                      Done
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setFocusRunning(false);
                        setFocusTaskId(null);
                      }}
                      aria-label="Close Focus Timer"
                      className="min-h-[38px] px-2.5 py-1.5 rounded-lg bg-teal-900 hover:bg-teal-800 text-teal-200 text-xs"
                    >
                      <Square className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            )}
          </section>

          {/* 5. Today's Tasks Section (Hidden when Zen Focus Mode is active) */}
          {!zenMode && (
          <section className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 space-y-4">
            <div className="flex items-center justify-between gap-4">
              <div>
                <h2 className="text-lg font-bold text-slate-900 dark:text-slate-100">
                  {STRINGS.today.tasksTitle} ({todayTasks.length} Baaki ·{' '}
                  {completedTodayTasks.length} Done)
                </h2>
                <p className="text-xs text-slate-500 dark:text-slate-400 font-mono tabular-nums mt-0.5">
                  Baaki Time: {totalScheduledMinutes} min · 80% Safe Budget:{' '}
                  {dayPlanRecommendations.budgetMinutes} min
                </p>
              </div>
              <button
                type="button"
                onClick={() => setActiveTab('tasks')}
                className="min-h-[40px] px-3 py-1.5 rounded-xl text-xs font-semibold text-teal-700 dark:text-teal-400 hover:bg-slate-50 dark:hover:bg-slate-800 whitespace-nowrap shrink-0"
              >
                Sabhi Tasks ({state.tasks.filter((t) => t.status === 'todo').length})
              </button>
            </div>

            {todayTasks.length === 0 && completedTodayTasks.length === 0 ? (
              <div className="rounded-xl border border-dashed border-slate-200 dark:border-slate-800 p-6 text-center space-y-1.5">
                <p className="text-sm font-medium text-slate-700 dark:text-slate-300">
                  Aaj ke liye koi aur task scheduled nahi hai.
                </p>
                <p className="text-xs text-slate-500">
                  Zarurat ho tabhi Tasks tab se jodein — har waqt busy rehna zaruri nahi hai.
                </p>
              </div>
            ) : (
              <div className="space-y-4">
                {/* Pending Tasks List */}
                {todayTasks.length > 0 ? (
                  <div className="divide-y divide-slate-100 dark:divide-slate-800">
                    {todayTasks.map((task) => {
                      const isMain = task.id === mainPriorityTask?.id;
                      const isCompleting = Boolean(completingIds[task.id]);
                      const isCelebrating =
                        celebratingId === task.id || isCompleting;
                      const isMenuOpen = expandedTaskMenuId === task.id;
                      const linkedGoal = state.goals.find(
                        (g) => g.id === task.goalId
                      );

                      return (
                        <motion.div
                          key={task.id}
                          layout
                          animate={
                            isCelebrating
                              ? {
                                  backgroundColor: [
                                    'rgba(16, 185, 129, 0.20)',
                                    'rgba(16, 185, 129, 0.05)',
                                  ],
                                  scale: [1, 1.01, 1],
                                }
                              : {}
                          }
                          transition={{ duration: 0.45 }}
                          className={`py-3.5 first:pt-1 last:pb-1 flex flex-col gap-2.5 rounded-xl px-2 transition-colors ${
                            isCompleting
                              ? 'bg-emerald-50/70 dark:bg-emerald-950/30'
                              : ''
                          }`}
                        >
                          <div className="flex items-start justify-between gap-3">
                            <div className="flex items-start gap-3 min-w-0">
                              <AnimatedCheckButton
                                checked={isCompleting}
                                celebrating={isCelebrating}
                                onToggle={() => handleTickTaskWithDelight(task)}
                                ariaLabel={`Complete task ${task.title}`}
                              />

                              <div className="min-w-0">
                                <div className="flex flex-wrap items-center gap-2">
                                  <p
                                    className={`text-sm font-semibold transition-all duration-300 ${
                                      isCompleting
                                        ? 'line-through text-emerald-700 dark:text-emerald-400'
                                        : 'text-slate-900 dark:text-slate-100'
                                    }`}
                                  >
                                    {task.title}
                                  </p>
                                  {isCompleting && (
                                    <motion.span
                                      initial={{ scale: 0.7, opacity: 0 }}
                                      animate={{ scale: 1, opacity: 1 }}
                                      className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-emerald-600 text-white text-[11px] font-bold"
                                    >
                                      ✓ Pura Hua!
                                    </motion.span>
                                  )}
                                  {isMain && !isCompleting && (
                                    <span className="inline-flex items-center px-2 py-0.5 rounded-md bg-teal-50 dark:bg-teal-950/60 text-teal-700 dark:text-teal-300 text-[11px] font-semibold">
                                      ★ Main Priority
                                    </span>
                                  )}
                                </div>

                                {task.nextAction && !isCompleting && (
                                  <p className="text-xs text-slate-600 dark:text-slate-400 mt-0.5">
                                    → {task.nextAction}
                                  </p>
                                )}

                                <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500 font-mono tabular-nums mt-1">
                                  <span>{task.estMinutes ?? 20} min</span>
                                  {linkedGoal && (
                                    <>
                                      <span>·</span>
                                      <span className="font-sans text-slate-600 dark:text-slate-400">
                                        {linkedGoal.title}
                                      </span>
                                    </>
                                  )}
                                  {task.rescheduleCount >= 3 && (
                                    <>
                                      <span>·</span>
                                      <span className="text-amber-700 dark:text-amber-400 font-sans">
                                        {task.rescheduleCount}x टला
                                      </span>
                                    </>
                                  )}
                                </div>
                              </div>
                            </div>

                            {/* Clean 2-Button Primary Action + Progressive Disclosure Menu */}
                            <div className="flex items-center gap-1 shrink-0">
                              <button
                                type="button"
                                onClick={() => startFocusOnTask(task)}
                                aria-label={`Focus on ${task.title}`}
                                className="min-h-[38px] px-2.5 py-1.5 rounded-lg text-xs font-semibold text-teal-700 dark:text-teal-300 hover:bg-teal-50 dark:hover:bg-teal-950/50 flex items-center gap-1 whitespace-nowrap"
                              >
                                <Play className="w-3 h-3" />
                                Focus
                              </button>
                              <button
                                type="button"
                                onClick={() =>
                                  setExpandedTaskMenuId(
                                    isMenuOpen ? null : task.id
                                  )
                                }
                                aria-label={`More options for ${task.title}`}
                                className={`min-h-[38px] min-w-[38px] flex items-center justify-center rounded-lg text-xs transition-colors ${
                                  isMenuOpen
                                    ? 'bg-slate-200 dark:bg-slate-800 text-slate-900 dark:text-slate-100'
                                    : 'text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800'
                                }`}
                              >
                                <MoreHorizontal className="w-4 h-4" />
                              </button>
                            </div>
                          </div>

                          {/* Progressive Disclosure Secondary Task Options */}
                          {isMenuOpen && (
                            <div className="flex flex-wrap items-center gap-1.5 pl-9 pt-1">
                              {!isMain && (
                                <button
                                  type="button"
                                  onClick={() => {
                                    upsertTodayPlan({ mainTaskId: task.id });
                                    setExpandedTaskMenuId(null);
                                  }}
                                  className="min-h-[34px] px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 text-xs font-medium text-slate-700 dark:text-slate-200"
                                >
                                  ★ Make Main Priority
                                </button>
                              )}
                              <button
                                type="button"
                                onClick={() => {
                                  rescheduleTask(task.id, addDays(today, 1));
                                  setExpandedTaskMenuId(null);
                                }}
                                className="min-h-[34px] px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 text-xs font-medium text-slate-700 dark:text-slate-200"
                              >
                                Kal Karo (Tomorrow)
                              </button>
                              <button
                                type="button"
                                onClick={() => {
                                  splitTaskIntoSubtasks(
                                    task.id,
                                    generateTwoMinuteStarter(
                                      task.title,
                                      task.nextAction
                                    )
                                  );
                                  setExpandedTaskMenuId(null);
                                }}
                                className="min-h-[34px] px-2.5 py-1 rounded-lg bg-teal-50 dark:bg-teal-950/60 text-xs font-semibold text-teal-800 dark:text-teal-300 flex items-center gap-1"
                              >
                                <Zap className="w-3 h-3 text-teal-600" />
                                2-Min Starter Split
                              </button>
                              <button
                                type="button"
                                onClick={() => {
                                  setExpandedTaskMenuId(null);
                                  setSplittingTaskId(task.id);
                                  setSplitLinesText(
                                    `${task.title} - Part 1\n${task.title} - Part 2`
                                  );
                                }}
                                className="min-h-[34px] px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 text-xs font-medium text-slate-700 dark:text-slate-200 flex items-center gap-1"
                              >
                                <Scissors className="w-3 h-3" />
                                Chhota Karo (Split)
                              </button>
                            </div>
                          )}
                        </motion.div>
                      );
                    })}
                  </div>
                ) : (
                  <div className="rounded-xl bg-emerald-50/60 dark:bg-emerald-950/25 border border-emerald-200/70 dark:border-emerald-900/50 p-4 text-center">
                    <p className="text-sm font-bold text-emerald-800 dark:text-emerald-300">
                      🎉 Aaj ke sabhi scheduled tasks pure ho gaye!
                    </p>
                  </div>
                )}

                {/* Completed Today Section (Cleanly Separated, Collapsible) */}
                {completedTodayTasks.length > 0 && (
                  <div className="pt-3 border-t border-slate-100 dark:border-slate-800 space-y-2">
                    <button
                      type="button"
                      onClick={() => setShowCompletedToday((v) => !v)}
                      className="w-full flex items-center justify-between text-xs font-semibold text-emerald-700 dark:text-emerald-400 py-1 hover:underline"
                    >
                      <span>
                        ✓ Aaj Complete Hue Tasks ({completedTodayTasks.length})
                      </span>
                      <ChevronDown
                        className={`w-4 h-4 transition-transform ${
                          showCompletedToday ? 'rotate-180' : ''
                        }`}
                      />
                    </button>

                    {showCompletedToday && (
                      <div className="space-y-1.5">
                        {completedTodayTasks.map((task) => (
                          <motion.div
                            key={task.id}
                            layout
                            initial={{ opacity: 0, y: -4 }}
                            animate={{ opacity: 1, y: 0 }}
                            className="flex items-center justify-between gap-3 rounded-xl bg-emerald-50/40 dark:bg-emerald-950/20 px-3 py-2 border border-emerald-100 dark:border-emerald-900/40"
                          >
                            <div className="flex items-center gap-2.5 min-w-0">
                              <AnimatedCheckButton
                                size="sm"
                                checked={true}
                                celebrating={celebratingId === task.id}
                                onToggle={() => reopenTask(task.id)}
                                ariaLabel={`Reopen completed task ${task.title}`}
                              />
                              <span className="text-xs sm:text-sm font-medium line-through text-slate-400 dark:text-slate-500 truncate">
                                {task.title}
                              </span>
                              <span className="inline-flex items-center px-2 py-0.5 rounded-md bg-emerald-100 dark:bg-emerald-950/70 text-emerald-800 dark:text-emerald-300 text-[10px] font-bold shrink-0">
                                ✓ Done
                              </span>
                            </div>
                            <button
                              type="button"
                              onClick={() => reopenTask(task.id)}
                              className="min-h-[32px] px-2 py-1 rounded-lg text-xs font-medium text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 flex items-center gap-1 shrink-0"
                            >
                              <RotateCcw className="w-3 h-3" />
                              Undo
                            </button>
                          </motion.div>
                        ))}
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}
          </section>
          )}
        </div>

        {/* Right Column (5 cols): Water Card + Daily Routines + Reviews */}
        <div className="lg:col-span-5 space-y-6">
          {/* 6. Water / Hydration Card */}
          {waterRoutine && (
            <section
              data-testid="water-tracker-card"
              className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 space-y-4"
            >
              <div className="flex items-center justify-between gap-3">
                <div className="flex items-center gap-2.5">
                  <Droplets className="w-5 h-5 text-sky-600 dark:text-sky-400" />
                  <div>
                    <h2 className="text-base font-bold text-slate-900 dark:text-slate-100">
                      {STRINGS.today.waterTitle}
                    </h2>
                    <p className="text-xs text-slate-500 dark:text-slate-400 font-mono tabular-nums">
                      Checkpoints: 11:00 (750ml) · 14:00 (1500ml) · 18:00 (2000ml)
                    </p>
                  </div>
                </div>
                <span className="text-lg font-bold font-mono tabular-nums text-sky-700 dark:text-sky-300 whitespace-nowrap shrink-0">
                  {waterValue} / {waterTarget} ml
                </span>
              </div>

              <div className="w-full h-3 rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden">
                <div
                  className="h-full bg-sky-600 dark:bg-sky-500 transition-all duration-150"
                  style={{ width: `${waterPercent}%` }}
                />
              </div>

              <div className="grid grid-cols-3 gap-2.5">
                <button
                  type="button"
                  onClick={() => addWater(waterRoutine.id, 250)}
                  className="min-h-[44px] py-2.5 px-3 rounded-xl bg-sky-600 hover:bg-sky-500 text-white text-xs font-semibold font-mono tabular-nums transition-colors"
                >
                  +250 ml
                </button>
                <button
                  type="button"
                  onClick={() => addWater(waterRoutine.id, 500)}
                  className="min-h-[44px] py-2.5 px-3 rounded-xl bg-sky-700 hover:bg-sky-600 text-white text-xs font-semibold font-mono tabular-nums transition-colors"
                >
                  +500 ml
                </button>
                <button
                  type="button"
                  disabled={waterValue <= 0}
                  onClick={() => addWater(waterRoutine.id, -250)}
                  className="min-h-[44px] py-2.5 px-3 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 disabled:opacity-40 text-xs font-medium flex items-center justify-center gap-1"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  Undo
                </button>
              </div>
            </section>
          )}

          {/* 7. Routines Block-Wise Card (Collapsible Blocks, hidden in Zen Mode) */}
          {!zenMode && (
          <section className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-base font-bold text-slate-900 dark:text-slate-100">
                {STRINGS.today.routinesTitle}
              </h2>
              <span className="text-xs text-slate-500 font-mono tabular-nums">
                {completedRoutinesCount}/{booleanRoutines.length} Done
              </span>
            </div>

            <div className="space-y-3">
              {blocks.map((b) => {
                const items = booleanRoutines.filter((r) => r.block === b.key);
                if (items.length === 0) return null;
                const blockDoneCount = items.filter(
                  (r) => logByRoutineId.get(r.id)?.status === 'done'
                ).length;
                const isCollapsed = Boolean(collapsedBlocks[b.key]);

                return (
                  <div key={b.key} className="space-y-2">
                    <button
                      type="button"
                      onClick={() =>
                        setCollapsedBlocks((prev) => ({
                          ...prev,
                          [b.key]: !prev[b.key],
                        }))
                      }
                      className="w-full flex items-center justify-between gap-2 px-2.5 py-1.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs font-semibold text-slate-600 dark:text-slate-300 transition-colors"
                    >
                      <span className="flex items-center gap-1.5">
                        {b.icon}
                        <span>{b.label}</span>
                      </span>
                      <span className="flex items-center gap-2 font-mono text-[11px] text-slate-500">
                        <span>
                          {blockDoneCount}/{items.length} Done
                        </span>
                        <ChevronDown
                          className={`w-3.5 h-3.5 transition-transform ${
                            isCollapsed ? '-rotate-90' : ''
                          }`}
                        />
                      </span>
                    </button>

                    {!isCollapsed && (
                    <div className="divide-y divide-slate-100 dark:divide-slate-800 border border-slate-100 dark:border-slate-800 rounded-xl">
                      {items.map((routine) => {
                        const log = logByRoutineId.get(routine.id);
                        const isDone = log?.status === 'done';
                        const isSkipped = log?.status === 'skipped';
                        const isCelebrating = celebratingId === routine.id;
                        const dueMins = computeRoutineDueMinutes(
                          routine,
                          state.settings,
                          todayPlan
                        );

                        return (
                          <div
                            key={routine.id}
                            className={`flex items-center justify-between gap-2 px-3 py-2 transition-colors ${
                              isDone
                                ? 'bg-emerald-50/30 dark:bg-emerald-950/15'
                                : ''
                            }`}
                          >
                            <div className="flex items-center gap-2.5 flex-1 min-w-0">
                              <AnimatedCheckButton
                                size="sm"
                                checked={isDone}
                                skipped={isSkipped}
                                celebrating={isCelebrating}
                                onToggle={() =>
                                  handleTickRoutineWithDelight(
                                    routine.id,
                                    routine.title,
                                    isDone
                                  )
                                }
                                ariaLabel={`Toggle routine ${routine.title}`}
                              />
                              <button
                                type="button"
                                onClick={() =>
                                  handleTickRoutineWithDelight(
                                    routine.id,
                                    routine.title,
                                    isDone
                                  )
                                }
                                className="flex-1 text-left py-1 min-w-0"
                              >
                                <div className="flex items-center gap-2">
                                  <p
                                    className={`text-sm font-medium transition-all ${
                                      isDone
                                        ? 'line-through text-slate-400 dark:text-slate-500'
                                        : isSkipped
                                          ? 'text-slate-400 italic'
                                          : 'text-slate-900 dark:text-slate-100'
                                    }`}
                                  >
                                    {routine.title}
                                  </p>
                                  {isDone && (
                                    <span className="inline-flex items-center px-1.5 py-0.5 rounded bg-emerald-100 dark:bg-emerald-950/70 text-emerald-800 dark:text-emerald-300 text-[10px] font-bold">
                                      ✓
                                    </span>
                                  )}
                                </div>
                                <p className="text-xs text-slate-500 font-mono tabular-nums">
                                  {dueMins !== null
                                    ? `Due ${formatMinutesToTime(dueMins)}`
                                    : 'Duty time set karein'}
                                  {routine.isMust ? ' · Must' : ''}
                                  {isSkipped ? ' · Skipped today' : ''}
                                </p>
                              </button>
                            </div>

                            {!isDone && !isSkipped && (
                              <button
                                type="button"
                                onClick={() => skipRoutineToday(routine.id)}
                                aria-label={`Skip ${routine.title}`}
                                className="min-h-[44px] px-2.5 text-xs text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 flex items-center gap-1 shrink-0"
                              >
                                <SkipForward className="w-3.5 h-3.5" />
                                Skip
                              </button>
                            )}
                          </div>
                        );
                      })}
                    </div>
                    )}
                  </div>
                );
              })}
            </div>
          </section>
          )}

          {/* 8. Evening Close-Out & Weekly Review Triggers */}
          <section className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 space-y-3">
            <h2 className="text-base font-bold text-slate-900 dark:text-slate-100">
              Review & Adjust (No Guilt)
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Reviews plan ko adjust karte hain, aapki worth ko nahi.
            </p>
            <div className="flex flex-col sm:flex-row gap-2.5">
              <button
                type="button"
                onClick={() => setShowDailyReview(true)}
                className="min-h-[44px] flex-1 px-4 py-2.5 rounded-xl bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 text-xs font-semibold flex items-center justify-center gap-2"
              >
                <Calendar className="w-4 h-4" />
                {STRINGS.today.dailyReviewBtn}
              </button>
              <button
                type="button"
                onClick={() => setShowWeeklyReview(true)}
                className="min-h-[44px] px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-200 text-xs font-semibold flex items-center justify-center gap-2"
              >
                {STRINGS.today.weeklyReviewBtn}
              </button>
            </div>
          </section>
        </div>
      </div>

      {/* Task Split Modal */}
      {splittingTaskId && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4"
          role="dialog"
          aria-modal="true"
        >
          <div className="w-full max-w-md rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 space-y-4">
            <h3 className="text-base font-bold text-slate-900 dark:text-slate-100">
              Task Ko Chhota Karo (Split into 2-4 Steps)
            </h3>
            <p className="text-xs text-slate-500">
              Har line ek naya chhota actionable task ban jayegi aur bada parent task cancel ho jayega.
            </p>
            <textarea
              rows={4}
              value={splitLinesText}
              onChange={(e) => setSplitLinesText(e.target.value)}
              className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 p-3 text-base text-slate-900 dark:text-slate-100"
            />
            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setSplittingTaskId(null)}
                className="min-h-[44px] px-4 py-2 rounded-xl text-xs font-medium text-slate-600 dark:text-slate-300"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  splitTaskIntoSubtasks(
                    splittingTaskId,
                    splitLinesText.split('\n')
                  );
                  setSplittingTaskId(null);
                }}
                className="min-h-[44px] px-4 py-2 rounded-xl bg-teal-700 text-white text-xs font-semibold"
              >
                Split Tasks Save Karo
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Daily Review Modal (Section 8.5) */}
      {showDailyReview && (
        <div
          className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 p-0 sm:p-4 overflow-y-auto"
          role="dialog"
          aria-modal="true"
        >
          <div className="w-full max-w-xl max-h-[90vh] overflow-y-auto rounded-t-3xl sm:rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 sm:p-6 space-y-4">
            <h3 className="text-lg font-bold text-slate-900 dark:text-slate-100">
              {STRINGS.reviews.dailyTitle} ({today})
            </h3>

            <div className="rounded-xl bg-slate-50 dark:bg-slate-950 p-3.5 text-xs space-y-1">
              <p className="font-semibold text-slate-800 dark:text-slate-200">
                Auto-Summary (Aaj Kya Hua):
              </p>
              <p className="text-slate-600 dark:text-slate-400 font-mono tabular-nums">
                Routines Done:{' '}
                {
                  booleanRoutines.filter(
                    (r) => logByRoutineId.get(r.id)?.status === 'done'
                  ).length
                }
                /{booleanRoutines.length} · Water: {waterValue} ml · Tasks Completed:{' '}
                {completedTodayTasks.length}
              </p>
            </div>

            {todayTasks.length > 0 && (
              <div className="space-y-2">
                <p className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                  Aaj Ke Pending Tasks ({todayTasks.length}) — Endless Carryover Mat Karein:
                </p>
                <div className="divide-y divide-slate-100 dark:divide-slate-800 border border-slate-200 dark:border-slate-800 rounded-xl p-3">
                  {todayTasks.map((t) => (
                    <div
                      key={t.id}
                      className="py-2 first:pt-0 last:pb-0 flex flex-col sm:flex-row sm:items-center justify-between gap-2"
                    >
                      <span className="text-xs font-medium text-slate-900 dark:text-slate-100">
                        {t.title}
                      </span>
                      <div className="flex flex-wrap gap-1.5">
                        <button
                          type="button"
                          onClick={() =>
                            rescheduleTask(t.id, addDays(today, 1))
                          }
                          className="min-h-[38px] px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 text-xs font-medium"
                        >
                          {STRINGS.reviews.pendingActions.tomorrow}
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            setShowDailyReview(false);
                            setSplittingTaskId(t.id);
                            setSplitLinesText(
                              `${t.title} - Step 1\n${t.title} - Step 2`
                            );
                          }}
                          className="min-h-[38px] px-2.5 py-1 rounded-lg bg-amber-50 dark:bg-amber-950/50 text-amber-800 dark:text-amber-300 text-xs font-medium"
                        >
                          {STRINGS.reviews.pendingActions.split}
                        </button>
                        <button
                          type="button"
                          onClick={() =>
                            updateTask(t.id, { status: 'cancelled' })
                          }
                          className="min-h-[38px] px-2.5 py-1 rounded-lg bg-rose-50 dark:bg-rose-950/40 text-rose-700 dark:text-rose-300 text-xs font-medium"
                        >
                          {STRINGS.reviews.pendingActions.cancel}
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Kuch unexpected ya naya kya hua aaj? (Optional)
              </label>
              <input
                type="text"
                value={surpriseText}
                onChange={(e) => setSurpriseText(e.target.value)}
                placeholder="e.g. Duty shift lambi rahi ya extra travel..."
                className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-3.5 py-2.5 text-base"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Kal ke plan me kya 1 chhota badlav karna hai? (Optional)
              </label>
              <input
                type="text"
                value={changeTomorrow}
                onChange={(e) => setChangeTomorrow(e.target.value)}
                placeholder="e.g. Subah sabse pehle Main Priority ke 15 min..."
                className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-3.5 py-2.5 text-base"
              />
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowDailyReview(false)}
                className="min-h-[44px] px-4 py-2 rounded-xl text-xs font-medium text-slate-600 dark:text-slate-300"
              >
                Close
              </button>
              <button
                type="button"
                onClick={() => {
                  saveDailyReview({
                    reviewDate: today,
                    completedText: `Tasks: ${completedTodayTasks.length}, Water: ${waterValue}ml`,
                    pendingText: `${todayTasks.length} pending`,
                    surpriseText,
                    changeTomorrow,
                  });
                  setShowDailyReview(false);
                }}
                className="min-h-[44px] px-5 py-2 rounded-xl bg-teal-700 text-white text-xs font-semibold"
              >
                Daily Review Save Karo
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Weekly Review Modal (Section 8.6) */}
      {showWeeklyReview && (
        <div
          className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 p-0 sm:p-4 overflow-y-auto"
          role="dialog"
          aria-modal="true"
        >
          <div className="w-full max-w-xl max-h-[90vh] overflow-y-auto rounded-t-3xl sm:rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 sm:p-6 space-y-4">
            <h3 className="text-lg font-bold text-slate-900 dark:text-slate-100">
              {STRINGS.reviews.weeklyTitle} (Week of {weekStartMonday(today)})
            </h3>

            <div className="rounded-xl bg-slate-50 dark:bg-slate-950 p-3.5 text-xs space-y-1.5">
              <p className="font-semibold text-slate-800 dark:text-slate-200">
                Active Goals Check ({activeGoalIds.size} Active):
              </p>
              {state.goals
                .filter((g) => g.status === 'active')
                .map((g) => (
                  <div
                    key={g.id}
                    className="flex items-center justify-between text-slate-600 dark:text-slate-400"
                  >
                    <span>• {g.title}</span>
                    <button
                      type="button"
                      onClick={() => {
                        setShowWeeklyReview(false);
                        setActiveQualityGateGoalId(g.id);
                      }}
                      className="text-teal-700 dark:text-teal-400 underline ml-2"
                    >
                      Review / Pause
                    </button>
                  </div>
                ))}
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                1. Is hafte kya achha raha (Accomplishments)?
              </label>
              <textarea
                rows={2}
                value={weeklyAccomplishments}
                onChange={(e) => setWeeklyAccomplishments(e.target.value)}
                className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 p-3 text-base"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                2. Kahan atke ya kya mushkil aayi (Challenges)?
              </label>
              <textarea
                rows={2}
                value={weeklyChallenges}
                onChange={(e) => setWeeklyChallenges(e.target.value)}
                className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 p-3 text-base"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                3. Kaunsa goal pause/adjust karna hai (Decisions)?
              </label>
              <input
                type="text"
                value={weeklyDecisions}
                onChange={(e) => setWeeklyDecisions(e.target.value)}
                className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-3.5 py-2.5 text-base"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                4. Agle hafte ki top 3 priorities:
              </label>
              <textarea
                rows={2}
                value={weeklyNextPriorities}
                onChange={(e) => setWeeklyNextPriorities(e.target.value)}
                className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 p-3 text-base"
              />
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowWeeklyReview(false)}
                className="min-h-[44px] px-4 py-2 rounded-xl text-xs font-medium text-slate-600 dark:text-slate-300"
              >
                Close
              </button>
              <button
                type="button"
                onClick={() => {
                  saveWeeklyReview({
                    weekStart: weekStartMonday(today),
                    accomplishments: weeklyAccomplishments,
                    challenges: weeklyChallenges,
                    decisions: weeklyDecisions,
                    nextPriorities: weeklyNextPriorities,
                  });
                  setShowWeeklyReview(false);
                }}
                className="min-h-[44px] px-5 py-2 rounded-xl bg-teal-700 text-white text-xs font-semibold"
              >
                Weekly Review Save Karo
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
