'use client';

import React, { useMemo, useState } from 'react';
import {
  Check,
  RotateCcw,
  Scissors,
  Sparkles,
  Trash2,
  Clock,
  ArrowRight,
  Tag,
  Infinity as InfinityIcon,
  Target,
  SlidersHorizontal,
  X,
  Plus,
  CheckSquare,
  ChevronDown,
  ChevronUp,
  FolderKanban,
  CornerDownRight,
  Zap,
} from 'lucide-react';
import { useGoalOs } from '@/src/context/goal-os-context';
import {
  AISuggestionDraft,
  GoalType,
  InboxItem,
} from '@/src/lib/types';
import {
  generateTwoMinuteStarter,
  normalizeGoalTags,
  PRESET_GOAL_TAGS,
  suggestContextualBrainDumpMatch,
} from '@/src/lib/logic/planner';
import { VoiceMicButton } from '@/src/components/voice-mic-button';

type FilterDestination =
  | 'goal_category'
  | 'specific_goal'
  | 'soch_vichar'
  | 'daily_task'
  | 'trash';

export function InboxView() {
  const {
    state,
    today,
    quickCapture,
    updateInboxItem,
    restoreInboxItem,
    splitInboxItem,
    convertInboxToEntity,
    moveInboxToExistingGoal,
    captureAndMoveToGoal,
    createLifeArea,
    requestAiSuggestion,
    setActiveTab,
    showToast,
  } = useGoalOs();

  // 1. Main Brain Dump Input Box + Contextual Menu State (when user types an item)
  const [captureText, setCaptureText] = useState('');
  const [inputCategoryOverride, setInputCategoryOverride] = useState<
    string | null
  >(null);
  const [inputGoalOverride, setInputGoalOverride] = useState<string>('');
  const [inputGoalStepType, setInputGoalStepType] = useState<
    'milestone' | 'task'
  >('milestone');
  const [inputGoalType, setInputGoalType] = useState<GoalType>('outcome');
  const [showInputNewCategory, setShowInputNewCategory] = useState(false);
  const [inputNewCategoryName, setInputNewCategoryName] = useState('');
  const [showTrashView, setShowTrashView] = useState(false);

  // 2. Inline Contextual Menu State for items in the Brain Dump list (01, 02, 03...)
  const [expandedContextItemId, setExpandedContextItemId] = useState<
    string | null
  >(null);
  const [inlineTargetGoalId, setInlineTargetGoalId] = useState<string>('');
  const [inlineStepType, setInlineStepType] = useState<'milestone' | 'task'>(
    'milestone'
  );
  const [inlineGoalType, setInlineGoalType] = useState<GoalType>('outcome');

  // 3. Active Item in the Full "Filter & Decide" Modal
  const [filteringId, setFilteringId] = useState<string | null>(null);
  const [filterDest, setFilterDest] =
    useState<FilterDestination>('goal_category');
  const [editedContent, setEditedContent] = useState('');
  const [decisionNote, setDecisionNote] = useState('');

  // Goal Category & Specific Goal options inside Filter Modal
  const [selectedAreaId, setSelectedAreaId] = useState<string>('area-health');
  const [selectedSpecificGoalId, setSelectedSpecificGoalId] =
    useState<string>('');
  const [specificGoalStepType, setSpecificGoalStepType] = useState<
    'milestone' | 'task'
  >('milestone');
  const [newCategoryName, setNewCategoryName] = useState('');
  const [showNewCategoryInput, setShowNewCategoryInput] = useState(false);
  const [goalMode, setGoalMode] = useState<GoalType>('outcome');
  const [goalTagsInput, setGoalTagsInput] = useState('');

  // Daily Task options inside Filter Modal
  const [taskNextAction, setTaskNextAction] = useState('');
  const [taskEstMinutes, setTaskEstMinutes] = useState(20);
  const [taskScheduledDate, setTaskScheduledDate] = useState(today);

  // Split sub-mode inside Filter Modal
  const [showSplitBox, setShowSplitBox] = useState(false);
  const [splitText, setSplitText] = useState('');

  // Optional AI helper inside Filter Modal
  const [aiDraft, setAiDraft] = useState<AISuggestionDraft | null>(null);
  const [aiLoading, setAiLoading] = useState(false);

  const activeLifeAreas = useMemo(
    () => state.lifeAreas.filter((a) => a.status === 'active'),
    [state.lifeAreas]
  );

  const activeGoals = useMemo(
    () => state.goals.filter((g) => g.status === 'active'),
    [state.goals]
  );

  // Smart Contextual Suggestion while typing in the Brain Dump Box
  const inputSuggestion = useMemo(
    () =>
      suggestContextualBrainDumpMatch(
        captureText,
        activeLifeAreas,
        activeGoals
      ),
    [captureText, activeLifeAreas, activeGoals]
  );

  const effectiveInputCategoryId =
    inputCategoryOverride !== null
      ? inputCategoryOverride
      : inputSuggestion.suggestedAreaId;

  const effectiveInputGoalId =
    inputGoalOverride ||
    inputSuggestion.suggestedGoalId ||
    activeGoals[0]?.id ||
    '';

  // Active Brain Dump list (new, processing, waiting, someday)
  const brainDumpItems = useMemo(
    () =>
      state.inboxItems.filter(
        (item) =>
          item.status === 'new' ||
          item.status === 'processing' ||
          item.status === 'waiting' ||
          item.status === 'someday'
      ),
    [state.inboxItems]
  );

  const trashedItems = useMemo(
    () => state.inboxItems.filter((item) => item.status === 'trash'),
    [state.inboxItems]
  );

  const activeFilteringItem = useMemo(
    () => state.inboxItems.find((i) => i.id === filteringId) || null,
    [state.inboxItems, filteringId]
  );

  const resetInputState = () => {
    setCaptureText('');
    setInputCategoryOverride(null);
    setInputGoalOverride('');
    setShowInputNewCategory(false);
    setInputNewCategoryName('');
  };

  // Default Relax Save: saves to Brain Dump list (with optional assigned category) and opens contextual menu on it
  const handleRelaxSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!captureText.trim()) return;
    const created = quickCapture(captureText, 'manual', {
      lifeAreaId: effectiveInputCategoryId || null,
    });
    resetInputState();
    setShowTrashView(false);
    if (created) {
      setExpandedContextItemId(created.id);
      const match = suggestContextualBrainDumpMatch(
        created.content,
        activeLifeAreas,
        activeGoals
      );
      setInlineTargetGoalId(
        match.suggestedGoalId || activeGoals[0]?.id || ''
      );
    }
  };

  // Input Contextual Action 1: Create New Goal directly in selected Category from typed text
  const handleInputCreateCategoryGoal = () => {
    if (!captureText.trim()) return;
    const targetAreaId =
      effectiveInputCategoryId || activeLifeAreas[0]?.id || 'area-health';
    const createdItem = quickCapture(captureText, 'manual', {
      lifeAreaId: targetAreaId,
    });
    if (createdItem) {
      convertInboxToEntity(createdItem.id, 'goal_candidate', {
        title: captureText.trim().split('\n')[0],
        desiredOutcome: captureText.trim(),
        purposeReason: 'Brain Dump input contextual menu se banaya gaya goal',
        lifeAreaId: targetAreaId,
        goalType: inputGoalType,
        directActivate: true,
      });
    }
    resetInputState();
    setActiveTab('goals');
  };

  // Input Contextual Action 2: Move typed text directly into a Specific Existing Goal
  const handleInputMoveToSpecificGoal = () => {
    if (!captureText.trim() || !effectiveInputGoalId) return;
    captureAndMoveToGoal(
      captureText.trim(),
      effectiveInputGoalId,
      inputGoalStepType
    );
    resetInputState();
    setActiveTab('goals');
  };

  // Input Contextual Action 3: Move typed text directly to Trash
  const handleInputMoveToTrash = () => {
    if (!captureText.trim()) return;
    quickCapture(captureText, 'manual', {
      status: 'trash',
      decisionNote: 'Brain Dump input se seedha Trash me daala gaya',
    });
    resetInputState();
  };

  const handleCreateInputNewCategory = () => {
    if (!inputNewCategoryName.trim()) return;
    const created = createLifeArea(inputNewCategoryName.trim());
    if (created) {
      setInputCategoryOverride(created.id);
      setInputNewCategoryName('');
      setShowInputNewCategory(false);
    }
  };

  const toggleItemContextMenu = (item: InboxItem) => {
    if (expandedContextItemId === item.id) {
      setExpandedContextItemId(null);
      return;
    }
    setExpandedContextItemId(item.id);
    const match = suggestContextualBrainDumpMatch(
      item.content,
      activeLifeAreas,
      activeGoals
    );
    const areaGoals = activeGoals.filter(
      (g) => g.lifeAreaId === (item.lifeAreaId || match.suggestedAreaId)
    );
    setInlineTargetGoalId(
      match.suggestedGoalId ||
        areaGoals[0]?.id ||
        activeGoals[0]?.id ||
        ''
    );
    setInlineStepType('milestone');
    setInlineGoalType('outcome');
  };

  const openFilterModal = (
    item: InboxItem,
    initialDest: FilterDestination = 'goal_category'
  ) => {
    const match = suggestContextualBrainDumpMatch(
      item.content,
      activeLifeAreas,
      activeGoals
    );
    setFilteringId(item.id);
    setFilterDest(initialDest);
    setEditedContent(item.content);
    setDecisionNote(item.decisionNote || '');
    setSelectedAreaId(
      item.lifeAreaId ||
        match.suggestedAreaId ||
        state.lifeAreas[0]?.id ||
        'area-health'
    );
    setSelectedSpecificGoalId(
      match.suggestedGoalId || activeGoals[0]?.id || ''
    );
    setSpecificGoalStepType('milestone');
    setNewCategoryName('');
    setShowNewCategoryInput(false);
    setGoalMode('outcome');
    setGoalTagsInput(
      item.tags && item.tags.length > 0 ? item.tags.join(' ') : ''
    );
    setTaskNextAction(item.content.split('\n')[0]);
    setTaskEstMinutes(20);
    setTaskScheduledDate(today);
    setShowSplitBox(false);
    setSplitText(
      item.content.includes('\n')
        ? item.content
        : `${item.content} - Step 1\n${item.content} - Step 2`
    );
    setAiDraft(item.aiSuggestionJson || null);
  };

  const handleCreateInlineCategory = () => {
    if (!newCategoryName.trim()) return;
    const created = createLifeArea(newCategoryName.trim());
    if (created) {
      setSelectedAreaId(created.id);
      setNewCategoryName('');
      setShowNewCategoryInput(false);
    }
  };

  const handleAiAssist = async (item: InboxItem) => {
    setAiLoading(true);
    try {
      const { draft } = await requestAiSuggestion(
        'inbox_clarify',
        editedContent || item.content
      );
      setAiDraft(draft);
      if (draft.refinedTitle) {
        setEditedContent(draft.refinedTitle);
      }
      if (draft.nextAction) {
        setTaskNextAction(draft.nextAction);
      }
    } finally {
      setAiLoading(false);
    }
  };

  // Option 1: Send filtered thought directly into the chosen Goal Category as a new Goal
  const handleSendToGoalCategory = (
    item: InboxItem,
    overrideAreaId?: string,
    overrideGoalMode?: GoalType
  ) => {
    const cleanText =
      (filteringId === item.id ? editedContent.trim() : item.content.trim()) ||
      item.content;
    let targetAreaId =
      overrideAreaId ||
      selectedAreaId ||
      item.lifeAreaId ||
      state.lifeAreas[0]?.id ||
      'area-health';
    if (filteringId === item.id && newCategoryName.trim()) {
      const created = createLifeArea(newCategoryName.trim());
      if (created) targetAreaId = created.id;
    }
    const parsedTags =
      filteringId === item.id
        ? normalizeGoalTags(goalTagsInput)
        : item.tags || [];

    convertInboxToEntity(item.id, 'goal_candidate', {
      title: cleanText.split('\n')[0],
      desiredOutcome: cleanText,
      purposeReason:
        decisionNote.trim() || 'Brain Dump se filter karke chuna gaya goal',
      lifeAreaId: targetAreaId,
      goalType: overrideGoalMode || goalMode,
      tags: parsedTags,
      directActivate: true,
    });

    setFilteringId(null);
    setExpandedContextItemId(null);
    setActiveTab('goals');
  };

  // Option 2: Move filtered thought directly into a Specific Existing Goal
  const handleMoveItemToSpecificGoal = (
    item: InboxItem,
    goalId: string,
    stepType: 'milestone' | 'task'
  ) => {
    if (!goalId) return;
    const customTitle =
      filteringId === item.id
        ? editedContent.trim().split('\n')[0]
        : item.content.trim().split('\n')[0];
    moveInboxToExistingGoal(item.id, goalId, stepType, customTitle);
    setFilteringId(null);
    setExpandedContextItemId(null);
    setActiveTab('goals');
  };

  // Option 3: Keep in Brain Dump for later reflection ("Baad me soch-vichar")
  const handleReturnToBrainDumpForReflection = (item: InboxItem) => {
    const cleanText =
      (filteringId === item.id ? editedContent.trim() : item.content.trim()) ||
      item.content;
    const parsedTags =
      filteringId === item.id
        ? normalizeGoalTags(goalTagsInput)
        : item.tags || [];
    updateInboxItem(item.id, {
      content: cleanText,
      status: 'someday',
      lifeAreaId: selectedAreaId || item.lifeAreaId || null,
      tags: parsedTags,
      decisionNote:
        decisionNote.trim() || 'Baad me soch-vichar ke liye rakha gaya',
    });
    setFilteringId(null);
    setExpandedContextItemId(null);
  };

  // Option 4: Convert to Daily Task
  const handleConvertToTask = (item: InboxItem) => {
    const cleanText = editedContent.trim() || item.content;
    convertInboxToEntity(item.id, 'task', {
      title: cleanText.split('\n')[0],
      nextAction: taskNextAction.trim() || cleanText,
      estMinutes: taskEstMinutes,
      scheduledDate: taskScheduledDate || today,
      goalId: null,
    });
    setFilteringId(null);
    setExpandedContextItemId(null);
  };

  // Option 5: Move useless thought to Trash
  const handleMoveToTrash = (item: InboxItem) => {
    updateInboxItem(item.id, {
      status: 'trash',
      decisionNote: 'Bekar thought — Trash me bheja gaya',
    });
    setFilteringId(null);
    setExpandedContextItemId(null);
  };

  const hasTypedText = captureText.trim().length > 0;
  const selectedInputAreaObj = activeLifeAreas.find(
    (a) => a.id === effectiveInputCategoryId
  );

  return (
    <div className="max-w-2xl mx-auto space-y-10 pb-8">
      {/* 1. CLEAN MINIMALIST BRAIN DUMP BOX + CONTEXTUAL MENU WHEN TYPING */}
      <section className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/90 dark:border-slate-800 p-6 sm:p-8 shadow-2xs space-y-6">
        <div className="flex items-start justify-between gap-4">
          <div className="space-y-1">
            <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900 dark:text-slate-100">
              Brain Dump
            </h1>
            <p className="text-sm text-slate-500 dark:text-slate-400 leading-relaxed">
              Jo bhi mann me aaye yahan khali kar dein — likhte hi aap Category, Specific Goal ya Trash bhi chun sakte hain.
            </p>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <VoiceMicButton
              onTranscript={(spoken) =>
                setCaptureText((prev) =>
                  prev.trim() ? `${prev.trim()} ${spoken}` : spoken
                )
              }
              onStatusMessage={(msg) => showToast(msg, 'info')}
            />
            {trashedItems.length > 0 && (
              <button
                type="button"
                onClick={() => setShowTrashView((v) => !v)}
                className={`min-h-[38px] px-3.5 py-1.5 rounded-xl text-xs font-semibold border transition-colors flex items-center gap-1.5 shrink-0 ${
                  showTrashView
                    ? 'bg-rose-50 dark:bg-rose-950/50 border-rose-300 dark:border-rose-800 text-rose-700 dark:text-rose-300'
                    : 'bg-slate-50/80 dark:bg-slate-800/80 border-slate-200/80 dark:border-slate-700 text-slate-600 dark:text-slate-400 hover:text-slate-900'
                }`}
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>
                  {showTrashView
                    ? '← Brain Dump List'
                    : `Trash (${trashedItems.length})`}
                </span>
              </button>
            )}
          </div>
        </div>

        <form onSubmit={handleRelaxSave} className="space-y-5">
          {/* Large Minimalist Brain Dump Box */}
          <textarea
            rows={4}
            value={captureText}
            onChange={(e) => setCaptureText(e.target.value)}
            onKeyDown={(e) => {
              if ((e.metaKey || e.ctrlKey) && e.key === 'Enter') {
                handleRelaxSave(e);
              }
            }}
            placeholder="Yahan kuch bhi likhein — koi vichaar, goal, kaam, chinta ya naya idea..."
            aria-label="Brain Dump Box"
            className="w-full rounded-2xl border border-slate-200 dark:border-slate-800 bg-[#FAF8F5]/80 dark:bg-slate-950/70 p-5 text-base sm:text-lg leading-relaxed text-slate-900 dark:text-slate-100 placeholder:text-slate-400 focus:outline-none focus:border-teal-600 focus:bg-white dark:focus:bg-slate-950 focus:ring-3 focus:ring-teal-600/15 transition-all resize-y"
          />

          {/* CONTEXTUAL MENU: Appears automatically as soon as the user types an item */}
          {hasTypedText && (
            <div
              data-testid="brain-dump-input-contextual-menu"
              className="rounded-2xl bg-slate-50/80 dark:bg-slate-950/80 border border-teal-600/25 dark:border-teal-500/25 p-5 space-y-5 transition-all"
            >
              <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-200/70 dark:border-slate-800/80 pb-3">
                <div className="flex items-center gap-2">
                  <span className="inline-flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-teal-800 dark:text-teal-300">
                    <SlidersHorizontal className="w-3.5 h-3.5 text-teal-600" />
                    Contextual Quick Filter
                  </span>
                  {inputSuggestion.matchedReason && (
                    <span className="text-[11px] font-medium px-2.5 py-0.5 rounded-full bg-teal-100/80 dark:bg-teal-950 text-teal-800 dark:text-teal-300">
                      Auto-hint: {inputSuggestion.matchedReason}
                    </span>
                  )}
                </div>

                {/* Direct Move to Trash button right in the contextual menu */}
                <button
                  type="button"
                  onClick={handleInputMoveToTrash}
                  className="min-h-[34px] px-3 py-1 rounded-xl bg-rose-50/80 dark:bg-rose-950/50 hover:bg-rose-100 border border-rose-200/80 dark:border-rose-800 text-rose-700 dark:text-rose-300 text-xs font-semibold flex items-center gap-1.5 transition-colors"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Bekar Hai → Seedha Trash</span>
                </button>
              </div>

              {/* A. Assign a Category OR Create a New Goal in that Category */}
              <div className="space-y-3">
                <div className="flex items-center justify-between gap-2">
                  <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                    <FolderKanban className="w-3.5 h-3.5 text-teal-600" />
                    <span>1. Category Assign Karein (Optional):</span>
                  </label>
                  <button
                    type="button"
                    onClick={() => setShowInputNewCategory((v) => !v)}
                    className="text-xs font-semibold text-teal-700 dark:text-teal-400 hover:underline flex items-center gap-1"
                  >
                    <Plus className="w-3 h-3" />
                    <span>
                      {showInputNewCategory ? 'Cancel' : '+ Naya Category'}
                    </span>
                  </button>
                </div>

                <div className="flex flex-wrap gap-2">
                  <button
                    type="button"
                    onClick={() => setInputCategoryOverride('')}
                    className={`min-h-[36px] px-3.5 py-1.5 rounded-xl text-xs font-semibold border transition-all ${
                      !effectiveInputCategoryId
                        ? 'bg-slate-800 text-white dark:bg-slate-200 dark:text-slate-900 border-slate-800'
                        : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 border-slate-200/80 dark:border-slate-800'
                    }`}
                  >
                    Bina Category (Sirf Save)
                  </button>
                  {activeLifeAreas.map((area) => {
                    const isSelected = effectiveInputCategoryId === area.id;
                    return (
                      <button
                        key={area.id}
                        type="button"
                        onClick={() => setInputCategoryOverride(area.id)}
                        className={`min-h-[36px] px-3.5 py-1.5 rounded-xl text-xs font-semibold border transition-all flex items-center gap-1.5 ${
                          isSelected
                            ? 'bg-teal-700 text-white border-teal-700 shadow-2xs'
                            : 'bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-200 border-slate-200/80 dark:border-slate-800 hover:border-teal-500'
                        }`}
                      >
                        <span>{area.name}</span>
                        {isSelected && <Check className="w-3.5 h-3.5" />}
                      </button>
                    );
                  })}
                </div>

                {showInputNewCategory && (
                  <div className="flex items-center gap-2 pt-1">
                    <input
                      type="text"
                      value={inputNewCategoryName}
                      onChange={(e) => setInputNewCategoryName(e.target.value)}
                      placeholder="Naya Category naam (e.g. Fitness, Study)..."
                      className="flex-1 min-h-[38px] rounded-xl border border-teal-500 bg-white dark:bg-slate-900 px-3 py-1.5 text-xs"
                    />
                    <button
                      type="button"
                      onClick={handleCreateInputNewCategory}
                      className="min-h-[38px] px-3.5 py-1.5 rounded-xl bg-teal-700 text-white text-xs font-semibold"
                    >
                      Add Category
                    </button>
                  </div>
                )}

                {selectedInputAreaObj && (
                  <div className="flex flex-wrap items-center justify-between gap-2 pt-1 bg-teal-50/60 dark:bg-teal-950/30 border border-teal-200/80 dark:border-teal-900 rounded-xl px-3.5 py-2.5">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-semibold text-teal-900 dark:text-teal-200">
                        Category: <strong>{selectedInputAreaObj.name}</strong>
                      </span>
                      <div className="inline-flex rounded-lg border border-teal-300/80 dark:border-teal-800 bg-white dark:bg-slate-900 p-0.5">
                        <button
                          type="button"
                          onClick={() => setInputGoalType('outcome')}
                          className={`px-2.5 py-0.5 rounded-md text-[11px] font-semibold ${
                            inputGoalType === 'outcome'
                              ? 'bg-teal-700 text-white'
                              : 'text-slate-600 dark:text-slate-400'
                          }`}
                        >
                          Goal
                        </button>
                        <button
                          type="button"
                          onClick={() => setInputGoalType('ongoing_direction')}
                          className={`px-2.5 py-0.5 rounded-md text-[11px] font-semibold ${
                            inputGoalType === 'ongoing_direction'
                              ? 'bg-teal-700 text-white'
                              : 'text-slate-600 dark:text-slate-400'
                          }`}
                        >
                          Ongoing Goal
                        </button>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={handleInputCreateCategoryGoal}
                      className="min-h-[36px] px-3.5 py-1.5 rounded-xl bg-teal-700 hover:bg-teal-600 text-white text-xs font-bold flex items-center gap-1.5 shadow-2xs"
                    >
                      <Target className="w-3.5 h-3.5" />
                      <span>
                        Seedha {selectedInputAreaObj.name} Goal Banao →
                      </span>
                    </button>
                  </div>
                )}
              </div>

              {/* B. Move Directly to a Specific Existing Goal */}
              {activeGoals.length > 0 && (
                <div className="space-y-2.5 pt-3 border-t border-slate-200/70 dark:border-slate-800/80">
                  <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                    <CornerDownRight className="w-3.5 h-3.5 text-teal-600" />
                    <span>
                      2. Ya Seedha Kisi Specific Goal ke Andar Move Karein:
                    </span>
                  </label>
                  <div className="grid grid-cols-1 sm:grid-cols-12 gap-2">
                    <select
                      aria-label="Select Specific Goal for Brain Dump item"
                      value={effectiveInputGoalId}
                      onChange={(e) => setInputGoalOverride(e.target.value)}
                      className="sm:col-span-7 w-full min-w-0 min-h-[40px] rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 px-3 py-2 text-xs font-medium text-slate-800 dark:text-slate-200 truncate"
                    >
                      {activeGoals.map((g) => {
                        const areaName =
                          state.lifeAreas.find((a) => a.id === g.lifeAreaId)
                            ?.name || 'Goal';
                        return (
                          <option key={g.id} value={g.id}>
                            [{areaName}] {g.title}
                          </option>
                        );
                      })}
                    </select>

                    <div className="sm:col-span-5 flex items-center gap-1.5">
                      <select
                        aria-label="Goal addition mode"
                        value={inputGoalStepType}
                        onChange={(e) =>
                          setInputGoalStepType(
                            e.target.value as 'milestone' | 'task'
                          )
                        }
                        className="flex-1 min-w-0 min-h-[40px] rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 px-2.5 py-2 text-xs font-medium text-slate-700 dark:text-slate-300"
                      >
                        <option value="milestone">As Plan Step</option>
                        <option value="task">As Daily Task</option>
                      </select>

                      <button
                        type="button"
                        onClick={handleInputMoveToSpecificGoal}
                        className="min-h-[40px] px-3.5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 dark:bg-slate-100 dark:hover:bg-slate-200 text-white dark:text-slate-900 text-xs font-bold flex items-center gap-1 whitespace-nowrap shrink-0"
                      >
                        <span>Move</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Wide "Relax" Pill Button right below the box */}
          <div className="flex justify-center pt-1">
            <button
              type="submit"
              disabled={!hasTypedText}
              className="w-full sm:w-96 min-h-[50px] px-8 py-3 rounded-full bg-teal-700 hover:bg-teal-600 active:scale-[0.99] disabled:opacity-40 text-white text-base font-bold tracking-wide shadow-xs transition-all flex items-center justify-center gap-2"
            >
              <Check className="w-5 h-5" />
              <span>
                {selectedInputAreaObj
                  ? `Relax — Save Thought (${selectedInputAreaObj.name})`
                  : 'Relax — Save Thought'}
              </span>
            </button>
          </div>
        </form>
      </section>

      {/* 2. MINIMALIST LIST OF THOUGHTS WITH GENEROUS WHITESPACE & CRISP DIVIDERS */}
      {!showTrashView ? (
        <section className="space-y-4" aria-label="Brain Dump List">
          <div className="flex items-baseline justify-between px-2">
            <div className="flex items-center gap-2.5">
              <h2 className="text-sm font-bold uppercase tracking-wider text-slate-800 dark:text-slate-200">
                Captured Thoughts
              </h2>
              <span className="inline-flex items-center justify-center px-2 py-0.5 rounded-full text-xs font-mono font-semibold bg-slate-200/70 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                {brainDumpItems.length}
              </span>
            </div>
            <span className="text-xs text-slate-400 dark:text-slate-500 hidden sm:inline">
              Select an item to categorize, move to a goal, or discard
            </span>
          </div>

          {brainDumpItems.length === 0 ? (
            <div className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 p-12 text-center space-y-2">
              <p className="text-base font-semibold text-slate-800 dark:text-slate-200">
                Brain Dump bilkul khali aur shant hai.
              </p>
              <p className="text-sm text-slate-500">
                Upar bade box me kuch bhi likh kar &ldquo;Relax&rdquo; dabayein — wo niche list me aa jayega.
              </p>
            </div>
          ) : (
            <div className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/90 dark:border-slate-800 shadow-2xs divide-y divide-slate-200/80 dark:divide-slate-800 overflow-hidden">
              {brainDumpItems.map((item, idx) => {
                const isSochVichar = item.status === 'someday';
                const assignedArea = state.lifeAreas.find(
                  (a) => a.id === item.lifeAreaId
                );
                const isContextOpen = expandedContextItemId === item.id;

                return (
                  <article
                    key={item.id}
                    className={`transition-colors ${
                      isContextOpen
                        ? 'bg-teal-50/25 dark:bg-teal-950/15'
                        : 'hover:bg-slate-50/70 dark:hover:bg-slate-800/30'
                    }`}
                  >
                    {/* Minimalist Item Row with generous whitespace */}
                    <div className="px-5 py-5 sm:px-7 sm:py-6">
                      <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
                        {/* Left: Index Number + Thought Content + Metadata */}
                        <div
                          className="flex items-start gap-4 flex-1 min-w-0 cursor-pointer"
                          onClick={() => toggleItemContextMenu(item)}
                        >
                          <span className="font-mono text-xs font-semibold text-slate-400 dark:text-slate-500 pt-1 select-none shrink-0 w-6">
                            {String(idx + 1).padStart(2, '0')}
                          </span>

                          <div className="flex-1 min-w-0 space-y-2.5">
                            <p className="text-[15px] sm:text-base font-medium text-slate-900 dark:text-slate-100 leading-relaxed break-words">
                              {item.content}
                            </p>

                            <div className="flex flex-wrap items-center gap-2 text-xs">
                              {assignedArea ? (
                                <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-teal-50 dark:bg-teal-950/70 text-teal-800 dark:text-teal-300 font-medium border border-teal-200/60 dark:border-teal-800/60">
                                  <span className="w-1.5 h-1.5 rounded-full bg-teal-600 dark:bg-teal-400" />
                                  {assignedArea.name}
                                </span>
                              ) : (
                                <span className="text-slate-400 dark:text-slate-500">
                                  Uncategorized
                                </span>
                              )}

                              {isSochVichar && (
                                <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-amber-50 dark:bg-amber-950/50 text-amber-800 dark:text-amber-300 font-medium border border-amber-200/60 dark:border-amber-800/60">
                                  <Clock className="w-3 h-3" />
                                  Soch-Vichar
                                </span>
                              )}

                              {item.decisionNote && (
                                <span className="text-slate-500 dark:text-slate-400">
                                  · {item.decisionNote}
                                </span>
                              )}
                            </div>
                          </div>
                        </div>

                        {/* Right: Clean Minimalist Action Controls */}
                        <div className="flex items-center justify-end gap-2 shrink-0 pl-10 sm:pl-0 pt-1 sm:pt-0">
                          <button
                            type="button"
                            onClick={() => toggleItemContextMenu(item)}
                            aria-expanded={isContextOpen}
                            className={`min-h-[36px] px-3 py-1.5 rounded-xl text-xs font-medium border transition-all flex items-center gap-1.5 whitespace-nowrap ${
                              isContextOpen
                                ? 'bg-teal-50 dark:bg-teal-950/70 border-teal-600/60 text-teal-900 dark:text-teal-200 font-semibold'
                                : 'bg-transparent border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-300 hover:border-slate-300 dark:hover:border-slate-700 hover:bg-slate-100/60 dark:hover:bg-slate-800/60'
                            }`}
                          >
                            <span>Category / Goal</span>
                            {isContextOpen ? (
                              <ChevronUp className="w-3.5 h-3.5" />
                            ) : (
                              <ChevronDown className="w-3.5 h-3.5" />
                            )}
                          </button>

                          <button
                            type="button"
                            onClick={() => openFilterModal(item)}
                            className="min-h-[36px] px-3.5 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 dark:bg-slate-100 dark:hover:bg-slate-200 text-white dark:text-slate-900 text-xs font-semibold transition-colors flex items-center gap-1.5 whitespace-nowrap"
                          >
                            <SlidersHorizontal className="w-3 h-3" />
                            <span>Filter</span>
                          </button>

                          <button
                            type="button"
                            onClick={() => handleMoveToTrash(item)}
                            aria-label={`Trash thought ${idx + 1}`}
                            title="Bekar thought — Trash me daalo"
                            className="min-h-[36px] min-w-[36px] rounded-xl text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 flex items-center justify-center transition-colors"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>

                      {/* INLINE CONTEXTUAL MENU FOR THIS ITEM (Cleanly separated inside the row) */}
                      {isContextOpen && (
                        <div
                          data-testid={`item-context-menu-${idx + 1}`}
                          className="mt-5 pt-5 border-t border-dashed border-slate-200 dark:border-slate-800 pl-0 sm:pl-10 space-y-5"
                        >
                          {/* 1. Assign Category or Convert to Category Goal */}
                          <div className="space-y-2.5">
                            <div className="flex flex-wrap items-center justify-between gap-2">
                              <span className="text-xs font-semibold text-slate-600 dark:text-slate-400">
                                1. Category Assign Karein (1-Tap):
                              </span>
                              {assignedArea && (
                                <div className="flex flex-wrap items-center gap-1.5">
                                  <select
                                    aria-label="New goal mode"
                                    value={inlineGoalType}
                                    onChange={(e) =>
                                      setInlineGoalType(
                                        e.target.value as GoalType
                                      )
                                    }
                                    className="min-h-[32px] rounded-lg border border-teal-300/80 dark:border-teal-800 bg-white dark:bg-slate-900 px-2.5 py-1 text-[11px] font-semibold text-teal-900 dark:text-teal-200"
                                  >
                                    <option value="outcome">Target Goal</option>
                                    <option value="ongoing_direction">
                                      Ongoing Goal
                                    </option>
                                  </select>
                                  <button
                                    type="button"
                                    onClick={() =>
                                      handleSendToGoalCategory(
                                        item,
                                        assignedArea.id,
                                        inlineGoalType
                                      )
                                    }
                                    className="min-h-[32px] px-3 py-1 rounded-lg bg-teal-700 hover:bg-teal-600 text-white text-xs font-semibold flex items-center gap-1.5"
                                  >
                                    <Target className="w-3 h-3" />
                                    <span>
                                      {assignedArea.name} me Naya Goal Banao →
                                    </span>
                                  </button>
                                </div>
                              )}
                            </div>

                            <div className="flex flex-wrap gap-2">
                              {activeLifeAreas.map((area) => {
                                const isCurrent = item.lifeAreaId === area.id;
                                return (
                                  <button
                                    key={area.id}
                                    type="button"
                                    onClick={() => {
                                      updateInboxItem(item.id, {
                                        lifeAreaId: area.id,
                                      });
                                      const firstGoalInArea = activeGoals.find(
                                        (g) => g.lifeAreaId === area.id
                                      );
                                      if (firstGoalInArea) {
                                        setInlineTargetGoalId(
                                          firstGoalInArea.id
                                        );
                                      }
                                    }}
                                    className={`min-h-[34px] px-3.5 py-1 rounded-xl text-xs font-medium border transition-all flex items-center gap-1.5 ${
                                      isCurrent
                                        ? 'bg-teal-700 text-white border-teal-700 font-semibold shadow-2xs'
                                        : 'bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-800 hover:border-teal-500'
                                    }`}
                                  >
                                    <span>{area.name}</span>
                                    {isCurrent && <Check className="w-3 h-3" />}
                                  </button>
                                );
                              })}
                            </div>
                          </div>

                          {/* 2. Move Directly to a Specific Goal */}
                          {activeGoals.length > 0 && (
                            <div className="space-y-2 pt-4 border-t border-slate-200/60 dark:border-slate-800/70">
                              <span className="block text-xs font-semibold text-slate-600 dark:text-slate-400">
                                2. Seedha Kisi Specific Goal me Move Karein:
                              </span>
                              <div className="grid grid-cols-1 sm:grid-cols-12 gap-2">
                                <select
                                  aria-label="Choose specific goal for item"
                                  value={
                                    inlineTargetGoalId ||
                                    activeGoals[0]?.id ||
                                    ''
                                  }
                                  onChange={(e) =>
                                    setInlineTargetGoalId(e.target.value)
                                  }
                                  className="sm:col-span-7 w-full min-w-0 min-h-[38px] rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 px-3 py-1.5 text-xs font-medium text-slate-800 dark:text-slate-200 truncate"
                                >
                                  {activeGoals.map((g) => {
                                    const areaName =
                                      state.lifeAreas.find(
                                        (a) => a.id === g.lifeAreaId
                                      )?.name || 'Goal';
                                    return (
                                      <option key={g.id} value={g.id}>
                                        [{areaName}] {g.title}
                                      </option>
                                    );
                                  })}
                                </select>

                                <div className="sm:col-span-5 flex items-center gap-1.5">
                                  <select
                                    aria-label="Move item as step or task"
                                    value={inlineStepType}
                                    onChange={(e) =>
                                      setInlineStepType(
                                        e.target.value as 'milestone' | 'task'
                                      )
                                    }
                                    className="flex-1 min-w-0 min-h-[38px] rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 px-2.5 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-300"
                                  >
                                    <option value="milestone">
                                      As Plan Step
                                    </option>
                                    <option value="task">As Daily Task</option>
                                  </select>

                                  <button
                                    type="button"
                                    onClick={() =>
                                      handleMoveItemToSpecificGoal(
                                        item,
                                        inlineTargetGoalId ||
                                          activeGoals[0]?.id ||
                                          '',
                                        inlineStepType
                                      )
                                    }
                                    className="min-h-[38px] px-3.5 py-1.5 rounded-xl bg-teal-700 hover:bg-teal-600 text-white text-xs font-semibold flex items-center gap-1 whitespace-nowrap shrink-0"
                                  >
                                    <span>Move to Goal</span>
                                    <ArrowRight className="w-3.5 h-3.5" />
                                  </button>
                                </div>
                              </div>
                            </div>
                          )}

                          {/* 3. Quick Footer Actions (Soch-Vichar, Full Filter, Trash) */}
                          <div className="flex flex-wrap items-center justify-between gap-2 pt-3 border-t border-slate-200/60 dark:border-slate-800/70">
                            <div className="flex flex-wrap items-center gap-2">
                              <button
                                type="button"
                                onClick={() =>
                                  handleReturnToBrainDumpForReflection(item)
                                }
                                className="min-h-[34px] px-3 py-1 rounded-xl bg-amber-50/80 dark:bg-amber-950/40 border border-amber-200/80 dark:border-amber-800 text-amber-800 dark:text-amber-300 text-xs font-medium flex items-center gap-1.5"
                              >
                                <Clock className="w-3.5 h-3.5" />
                                <span>Soch-Vichar (Hold)</span>
                              </button>

                              <button
                                type="button"
                                onClick={() => {
                                  splitInboxItem(
                                    item.id,
                                    generateTwoMinuteStarter(item.content)
                                  );
                                  setExpandedContextItemId(null);
                                }}
                                className="min-h-[34px] px-3 py-1 rounded-xl bg-teal-50/80 dark:bg-teal-950/50 border border-teal-200/80 dark:border-teal-800 text-teal-800 dark:text-teal-300 text-xs font-semibold flex items-center gap-1.5"
                              >
                                <Zap className="w-3.5 h-3.5 text-teal-600" />
                                <span>2-Min Starter Split</span>
                              </button>

                              <button
                                type="button"
                                onClick={() => openFilterModal(item)}
                                className="min-h-[34px] px-3 py-1 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 text-xs font-medium flex items-center gap-1.5"
                              >
                                <SlidersHorizontal className="w-3.5 h-3.5 text-teal-600" />
                                <span>Pura Filter & Split Kholein</span>
                              </button>
                            </div>

                            <button
                              type="button"
                              onClick={() => handleMoveToTrash(item)}
                              className="min-h-[34px] px-3 py-1 rounded-xl bg-rose-50/80 dark:bg-rose-950/50 border border-rose-200/80 dark:border-rose-800 text-rose-700 dark:text-rose-300 text-xs font-medium flex items-center gap-1.5"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                              <span>Trash me Daalo</span>
                            </button>
                          </div>
                        </div>
                      )}
                    </div>
                  </article>
                );
              })}
            </div>
          )}
        </section>
      ) : (
        /* Clean Minimalist Trash View */
        <section className="space-y-4">
          <div className="flex items-center justify-between px-2">
            <h2 className="text-sm font-bold uppercase tracking-wider text-rose-700 dark:text-rose-400">
              Trash / Discarded Thoughts ({trashedItems.length})
            </h2>
            <button
              type="button"
              onClick={() => setShowTrashView(false)}
              className="text-xs font-semibold text-teal-700 dark:text-teal-400 hover:underline"
            >
              ← Wapas Brain Dump par jayein
            </button>
          </div>
          <div className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/90 dark:border-slate-800 divide-y divide-slate-200/80 dark:divide-slate-800 overflow-hidden">
            {trashedItems.map((item, idx) => (
              <div
                key={item.id}
                className="flex items-center justify-between gap-4 px-6 py-4.5 opacity-80"
              >
                <div className="flex items-center gap-4 min-w-0">
                  <span className="text-xs font-mono text-slate-400">
                    {String(idx + 1).padStart(2, '0')}
                  </span>
                  <p className="text-sm text-slate-600 dark:text-slate-400 line-through truncate">
                    {item.content}
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => restoreInboxItem(item.id)}
                  className="min-h-[36px] px-3.5 py-1.5 rounded-xl bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 text-xs font-semibold flex items-center gap-1.5 shrink-0"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Wapas Lao</span>
                </button>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* 3. FULL "FILTER & DECIDE" MODAL (Opens when clicking "Filter" next to a thought) */}
      {activeFilteringItem && (
        <div
          className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 backdrop-blur-xs p-0 sm:p-4 overflow-y-auto"
          role="dialog"
          aria-modal="true"
          aria-labelledby="brain-dump-filter-title"
        >
          <div className="w-full max-w-xl max-h-[92vh] overflow-y-auto rounded-t-3xl sm:rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 sm:p-6 shadow-2xl space-y-5">
            {/* Modal Header */}
            <div className="flex items-start justify-between gap-3 border-b border-slate-100 dark:border-slate-800 pb-3.5">
              <div>
                <p className="text-xs font-bold uppercase tracking-wider text-teal-700 dark:text-teal-400">
                  Brain Dump Thought Filter
                </p>
                <h2
                  id="brain-dump-filter-title"
                  className="text-lg font-bold text-slate-900 dark:text-slate-100"
                >
                  Is Thought Ka Kya Karna Hai?
                </h2>
              </div>
              <button
                type="button"
                onClick={() => setFilteringId(null)}
                aria-label="Close Filter Modal"
                className="min-h-[40px] min-w-[40px] rounded-xl flex items-center justify-center text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Thought Wording Edit + Split / AI Helpers */}
            <div className="space-y-2">
              <div className="flex items-center justify-between gap-2">
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                  Thought Text (Chahein to saaf/edit kar lein):
                </label>
                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={() => setShowSplitBox((v) => !v)}
                    className="min-h-[32px] px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 text-xs font-medium text-slate-700 dark:text-slate-300 flex items-center gap-1"
                  >
                    <Scissors className="w-3 h-3" />
                    <span>2 Tukdon me Split</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => handleAiAssist(activeFilteringItem)}
                    disabled={aiLoading}
                    className="min-h-[32px] px-2.5 py-1 rounded-lg bg-teal-50 dark:bg-teal-950/60 text-xs font-semibold text-teal-800 dark:text-teal-300 flex items-center gap-1"
                  >
                    <Sparkles className="w-3 h-3" />
                    <span>{aiLoading ? 'Soch raha...' : 'AI Suggest'}</span>
                  </button>
                </div>
              </div>

              <textarea
                rows={2}
                value={editedContent}
                onChange={(e) => setEditedContent(e.target.value)}
                className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 p-3 text-base text-slate-900 dark:text-slate-100"
              />

              {aiDraft && (
                <div className="rounded-xl bg-teal-50/70 dark:bg-teal-950/40 border border-teal-200 dark:border-teal-900 p-2.5 text-xs text-teal-900 dark:text-teal-200">
                  AI Sujhaav: {aiDraft.explanation}
                </div>
              )}

              {showSplitBox && (
                <div className="rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 p-3 space-y-2">
                  <p className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                    Har line alag Brain Dump item ban jayegi:
                  </p>
                  <textarea
                    rows={3}
                    value={splitText}
                    onChange={(e) => setSplitText(e.target.value)}
                    className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 p-2.5 text-sm"
                  />
                  <div className="flex justify-end gap-2">
                    <button
                      type="button"
                      onClick={() => setShowSplitBox(false)}
                      className="px-3 py-1 text-xs text-slate-500"
                    >
                      Cancel
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        splitInboxItem(
                          activeFilteringItem.id,
                          splitText.split('\n')
                        );
                        setFilteringId(null);
                      }}
                      className="min-h-[36px] px-3.5 py-1 rounded-lg bg-teal-700 text-white text-xs font-semibold"
                    >
                      Split Karo
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* 5 Clear Filter Destinations */}
            <div className="space-y-3">
              <p className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                1. Chunein Iska Kya Karna Hai:
              </p>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() => setFilterDest('goal_category')}
                  className={`min-h-[54px] p-2.5 rounded-xl border text-left transition-all flex flex-col justify-between ${
                    filterDest === 'goal_category'
                      ? 'border-2 border-teal-600 bg-teal-50/70 dark:bg-teal-950/50 text-teal-900 dark:text-teal-200'
                      : 'border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-50'
                  }`}
                >
                  <Target className="w-4 h-4 text-teal-600" />
                  <span className="text-xs font-bold leading-tight mt-1">
                    Naya Goal (Category me)
                  </span>
                </button>

                <button
                  type="button"
                  onClick={() => setFilterDest('specific_goal')}
                  className={`min-h-[54px] p-2.5 rounded-xl border text-left transition-all flex flex-col justify-between ${
                    filterDest === 'specific_goal'
                      ? 'border-2 border-teal-600 bg-teal-50/70 dark:bg-teal-950/50 text-teal-900 dark:text-teal-200'
                      : 'border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-50'
                  }`}
                >
                  <CornerDownRight className="w-4 h-4 text-teal-600" />
                  <span className="text-xs font-bold leading-tight mt-1">
                    Specific Goal me Move
                  </span>
                </button>

                <button
                  type="button"
                  onClick={() => setFilterDest('daily_task')}
                  className={`min-h-[54px] p-2.5 rounded-xl border text-left transition-all flex flex-col justify-between ${
                    filterDest === 'daily_task'
                      ? 'border-2 border-teal-600 bg-teal-50/70 dark:bg-teal-950/50 text-teal-900 dark:text-teal-200'
                      : 'border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-50'
                  }`}
                >
                  <CheckSquare className="w-4 h-4 text-teal-600" />
                  <span className="text-xs font-bold leading-tight mt-1">
                    Aaj / Kal Ka Task Banao
                  </span>
                </button>

                <button
                  type="button"
                  onClick={() => setFilterDest('soch_vichar')}
                  className={`min-h-[54px] p-2.5 rounded-xl border text-left transition-all flex flex-col justify-between ${
                    filterDest === 'soch_vichar'
                      ? 'border-2 border-amber-500 bg-amber-50/70 dark:bg-amber-950/40 text-amber-900 dark:text-amber-200'
                      : 'border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-50'
                  }`}
                >
                  <Clock className="w-4 h-4 text-amber-600" />
                  <span className="text-xs font-bold leading-tight mt-1">
                    Soch-Vichar (Wapas Brain Dump)
                  </span>
                </button>

                <button
                  type="button"
                  onClick={() => setFilterDest('trash')}
                  className={`min-h-[54px] p-2.5 rounded-xl border text-left transition-all flex flex-col justify-between ${
                    filterDest === 'trash'
                      ? 'border-2 border-rose-600 bg-rose-50/70 dark:bg-rose-950/40 text-rose-900 dark:text-rose-200'
                      : 'border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:bg-rose-50/40'
                  }`}
                >
                  <Trash2 className="w-4 h-4 text-rose-600" />
                  <span className="text-xs font-bold leading-tight mt-1">
                    Bekar Hai (Trash)
                  </span>
                </button>
              </div>
            </div>

            {/* DESTINATION 1 DETAILS: Pick Goal Category (Health, Finance, Relationship, etc.) + Goal vs Ongoing Goal */}
            {filterDest === 'goal_category' && (
              <div className="rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 p-4 space-y-4">
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-bold text-slate-800 dark:text-slate-200">
                      Kis Goal Category ke andar add karna hai?
                    </label>
                    <button
                      type="button"
                      onClick={() => setShowNewCategoryInput((v) => !v)}
                      className="text-xs font-semibold text-teal-700 dark:text-teal-400 hover:underline flex items-center gap-1"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      {showNewCategoryInput ? 'Cancel' : '+ Naya Category'}
                    </button>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                    {activeLifeAreas.map((area) => {
                      const isSelected = selectedAreaId === area.id;
                      const goalCount = state.goals.filter(
                        (g) =>
                          g.status === 'active' && g.lifeAreaId === area.id
                      ).length;
                      return (
                        <button
                          key={area.id}
                          type="button"
                          onClick={() => setSelectedAreaId(area.id)}
                          className={`min-h-[44px] px-3.5 py-2 rounded-xl border text-left transition-all flex items-center justify-between ${
                            isSelected
                              ? 'bg-teal-700 text-white border-teal-700 font-bold shadow-2xs'
                              : 'bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-200 border-slate-200 dark:border-slate-800 hover:border-teal-500'
                          }`}
                        >
                          <span className="text-xs truncate">{area.name}</span>
                          <span
                            className={`text-xs font-mono ml-1.5 ${
                              isSelected ? 'text-teal-100' : 'text-slate-400'
                            }`}
                          >
                            {goalCount}
                          </span>
                        </button>
                      );
                    })}
                  </div>

                  {showNewCategoryInput && (
                    <div className="flex items-center gap-2 pt-1">
                      <input
                        type="text"
                        value={newCategoryName}
                        onChange={(e) => setNewCategoryName(e.target.value)}
                        placeholder="Naya Category naam (e.g. Fitness, Study, Business)..."
                        className="flex-1 min-h-[42px] rounded-xl border border-teal-500 bg-white dark:bg-slate-900 px-3 py-2 text-sm"
                      />
                      <button
                        type="button"
                        onClick={handleCreateInlineCategory}
                        className="min-h-[42px] px-4 py-2 rounded-xl bg-teal-700 text-white text-xs font-semibold"
                      >
                        Add
                      </button>
                    </div>
                  )}
                </div>

                {/* Goal vs Ongoing Goal */}
                <div className="space-y-1.5">
                  <label className="block text-xs font-bold text-slate-800 dark:text-slate-200">
                    Goal Type Chunein:
                  </label>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => setGoalMode('outcome')}
                      className={`min-h-[44px] p-2.5 rounded-xl border text-left flex items-center gap-2.5 ${
                        goalMode === 'outcome'
                          ? 'border-teal-600 bg-white dark:bg-slate-900 text-teal-900 dark:text-teal-200 font-bold shadow-2xs'
                          : 'border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400'
                      }`}
                    >
                      <Target className="w-4 h-4 text-teal-600 shrink-0" />
                      <div>
                        <p className="text-xs font-bold">
                          Goal (Target Outcome)
                        </p>
                        <p className="text-[11px] opacity-75">
                          Jise plan karke poora karna hai
                        </p>
                      </div>
                    </button>

                    <button
                      type="button"
                      onClick={() => setGoalMode('ongoing_direction')}
                      className={`min-h-[44px] p-2.5 rounded-xl border text-left flex items-center gap-2.5 ${
                        goalMode === 'ongoing_direction'
                          ? 'border-teal-600 bg-white dark:bg-slate-900 text-teal-900 dark:text-teal-200 font-bold shadow-2xs'
                          : 'border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400'
                      }`}
                    >
                      <InfinityIcon className="w-4 h-4 text-teal-600 shrink-0" />
                      <div>
                        <p className="text-xs font-bold">
                          Ongoing Goal (Hamesha Chalne Wala)
                        </p>
                        <p className="text-[11px] opacity-75">
                          Life-long system jo lagataar chalta rahe
                        </p>
                      </div>
                    </button>
                  </div>
                </div>

                {/* Optional #Tags */}
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-slate-600 dark:text-slate-400 flex items-center gap-1">
                    <Tag className="w-3.5 h-3.5 text-teal-600" />
                    Optional #Tag:
                  </label>
                  <div className="flex flex-wrap gap-1.5">
                    {PRESET_GOAL_TAGS.map((tag) => {
                      const activeTags = normalizeGoalTags(goalTagsInput);
                      const isTagged = activeTags.includes(tag);
                      return (
                        <button
                          key={tag}
                          type="button"
                          onClick={() => {
                            const next = isTagged
                              ? activeTags.filter((t) => t !== tag)
                              : [...activeTags, tag];
                            setGoalTagsInput(next.join(' '));
                          }}
                          className={`min-h-[28px] px-2.5 py-0.5 rounded-lg text-xs font-mono border ${
                            isTagged
                              ? 'bg-teal-700 text-white border-teal-700 font-semibold'
                              : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 border-slate-200 dark:border-slate-700'
                          }`}
                        >
                          {tag}
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>
            )}

            {/* DESTINATION 2 DETAILS: Move Directly to a Specific Existing Goal */}
            {filterDest === 'specific_goal' && (
              <div className="rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 p-4 space-y-4">
                <div className="space-y-2">
                  <label className="block text-xs font-bold text-slate-800 dark:text-slate-200">
                    Kis Specific Goal ke andar move karna hai?
                  </label>
                  <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
                    {activeGoals.map((goal) => {
                      const areaName =
                        state.lifeAreas.find((a) => a.id === goal.lifeAreaId)
                          ?.name || 'Goal';
                      const isSelected = selectedSpecificGoalId === goal.id;
                      return (
                        <button
                          key={goal.id}
                          type="button"
                          onClick={() => setSelectedSpecificGoalId(goal.id)}
                          className={`w-full p-3 rounded-xl border text-left transition-all flex items-center justify-between gap-2 ${
                            isSelected
                              ? 'border-2 border-teal-600 bg-teal-50/70 dark:bg-teal-950/50 text-teal-900 dark:text-teal-200 font-bold'
                              : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-200'
                          }`}
                        >
                          <div className="min-w-0">
                            <span className="text-[11px] font-bold uppercase tracking-wider text-teal-700 dark:text-teal-400 block">
                              {areaName}
                            </span>
                            <span className="text-xs sm:text-sm truncate block">
                              {goal.title}
                            </span>
                          </div>
                          {isSelected && (
                            <Check className="w-4 h-4 text-teal-600 shrink-0" />
                          )}
                        </button>
                      );
                    })}
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="block text-xs font-bold text-slate-800 dark:text-slate-200">
                    Goal ke andar kis roop me jodein?
                  </label>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => setSpecificGoalStepType('milestone')}
                      className={`min-h-[42px] px-3 py-2 rounded-xl border text-xs font-semibold text-left ${
                        specificGoalStepType === 'milestone'
                          ? 'border-teal-600 bg-white dark:bg-slate-900 text-teal-900 dark:text-teal-200 font-bold'
                          : 'border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400'
                      }`}
                    >
                      2. Plan Step (Milestone)
                    </button>
                    <button
                      type="button"
                      onClick={() => setSpecificGoalStepType('task')}
                      className={`min-h-[42px] px-3 py-2 rounded-xl border text-xs font-semibold text-left ${
                        specificGoalStepType === 'task'
                          ? 'border-teal-600 bg-white dark:bg-slate-900 text-teal-900 dark:text-teal-200 font-bold'
                          : 'border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400'
                      }`}
                    >
                      3. Aage Ka Process (Daily Task)
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* DESTINATION 3 DETAILS: Soch-Vichar (Return to Brain Dump) */}
            {filterDest === 'soch_vichar' && (
              <div className="rounded-2xl bg-amber-50/60 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800 p-4 space-y-3">
                <p className="text-xs font-semibold text-amber-900 dark:text-amber-200">
                  Abhi pakka nahi hai? Koi baat nahi — ise wapas Brain Dump me rakhein taaki baad me aaram se soch-vichar kar sakein.
                </p>
                <input
                  type="text"
                  value={decisionNote}
                  onChange={(e) => setDecisionNote(e.target.value)}
                  placeholder="Optional note (e.g. Agle hafte sochenge)..."
                  className="w-full rounded-xl border border-amber-300 dark:border-amber-800 bg-white dark:bg-slate-900 px-3.5 py-2 text-sm"
                />
              </div>
            )}

            {/* DESTINATION 4 DETAILS: Convert directly to Daily Task */}
            {filterDest === 'daily_task' && (
              <div className="rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 p-4 space-y-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Concrete Action Step:
                  </label>
                  <input
                    type="text"
                    value={taskNextAction}
                    onChange={(e) => setTaskNextAction(e.target.value)}
                    className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-3 py-2 text-sm"
                  />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      Kab Karna Hai?
                    </label>
                    <input
                      type="date"
                      value={taskScheduledDate}
                      onChange={(e) => setTaskScheduledDate(e.target.value)}
                      className="w-full min-h-[42px] rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-3 py-1.5 text-xs font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      Est. Minutes
                    </label>
                    <input
                      type="number"
                      min={5}
                      max={240}
                      value={taskEstMinutes}
                      onChange={(e) =>
                        setTaskEstMinutes(Number(e.target.value))
                      }
                      className="w-full min-h-[42px] rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-3 py-1.5 text-xs font-mono"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* DESTINATION 5 DETAILS: Bekar Thought -> Trash */}
            {filterDest === 'trash' && (
              <div className="rounded-2xl bg-rose-50/70 dark:bg-rose-950/30 border border-rose-200 dark:border-rose-900 p-4 text-xs text-rose-900 dark:text-teal-200">
                Ye thought bekar hai to ise seedha Trash me bhej dein. Aap kabhi bhi Trash se wapas nikal sakte hain.
              </div>
            )}

            {/* Modal Footer Action Button */}
            <div className="flex items-center justify-between gap-3 pt-2 border-t border-slate-100 dark:border-slate-800">
              <button
                type="button"
                onClick={() => setFilteringId(null)}
                className="min-h-[44px] px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                Cancel
              </button>

              {filterDest === 'goal_category' && (
                <button
                  type="button"
                  onClick={() =>
                    handleSendToGoalCategory(activeFilteringItem)
                  }
                  className="min-h-[46px] px-6 py-2.5 rounded-xl bg-teal-700 hover:bg-teal-600 text-white text-sm font-bold flex items-center gap-2 shadow-sm"
                >
                  <span>
                    {activeLifeAreas.find((a) => a.id === selectedAreaId)
                      ?.name || 'Goal'}{' '}
                    Category me Add Karo
                  </span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              )}

              {filterDest === 'specific_goal' && (
                <button
                  type="button"
                  onClick={() =>
                    handleMoveItemToSpecificGoal(
                      activeFilteringItem,
                      selectedSpecificGoalId || activeGoals[0]?.id || '',
                      specificGoalStepType
                    )
                  }
                  className="min-h-[46px] px-6 py-2.5 rounded-xl bg-teal-700 hover:bg-teal-600 text-white text-sm font-bold flex items-center gap-2 shadow-sm"
                >
                  <span>Chune Gaye Goal me Move Karo</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              )}

              {filterDest === 'soch_vichar' && (
                <button
                  type="button"
                  onClick={() =>
                    handleReturnToBrainDumpForReflection(activeFilteringItem)
                  }
                  className="min-h-[46px] px-6 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-white text-sm font-bold flex items-center gap-2 shadow-sm"
                >
                  <Clock className="w-4 h-4" />
                  <span>Wapas Brain Dump me Rakho</span>
                </button>
              )}

              {filterDest === 'daily_task' && (
                <button
                  type="button"
                  onClick={() => handleConvertToTask(activeFilteringItem)}
                  className="min-h-[46px] px-6 py-2.5 rounded-xl bg-teal-700 hover:bg-teal-600 text-white text-sm font-bold flex items-center gap-2 shadow-sm"
                >
                  <Check className="w-4 h-4" />
                  <span>Daily Task me Add Karo</span>
                </button>
              )}

              {filterDest === 'trash' && (
                <button
                  type="button"
                  onClick={() => handleMoveToTrash(activeFilteringItem)}
                  className="min-h-[46px] px-6 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-sm font-bold flex items-center gap-2 shadow-sm"
                >
                  <Trash2 className="w-4 h-4" />
                  <span>Trash me Daalo</span>
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
