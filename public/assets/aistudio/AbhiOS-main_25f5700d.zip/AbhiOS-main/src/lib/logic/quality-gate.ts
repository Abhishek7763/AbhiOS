import { ExportPayload, Goal } from '../types';

export interface GoalGateEvaluation {
  isReadyToAccept: boolean;
  missingFields: string[];
  warnings: string[];
  advisorySleepOnIt: boolean;
  activeGoalCountWarning: boolean;
}

/**
 * V2 Section 2: Evaluates a Goal Candidate against the Quality Gate rules.
 * - Requires desired outcome (or clear title), personal reason, life area, and review cadence/date.
 * - Soft advisory if activeGoalsCount >= 5 (never blocks).
 * - Soft "sleep on it" suggestion if trade-offs mention large cost/hours or multiple life areas.
 */
export function evaluateGoalCandidateGate(
  candidate: Partial<Goal>,
  activeGoalsCount: number
): GoalGateEvaluation {
  const missingFields: string[] = [];
  const warnings: string[] = [];

  if (!candidate.title || candidate.title.trim().length < 3) {
    missingFields.push('Goal Title / Outcome');
  }
  if (!candidate.desiredOutcome || candidate.desiredOutcome.trim().length < 5) {
    missingFields.push('Desired Outcome (Kya alag ya sach hona chahiye)');
  }
  if (!candidate.purposeReason || candidate.purposeReason.trim().length < 3) {
    missingFields.push('Personal Reason (Kyun zaruri hai)');
  }
  if (!candidate.lifeAreaId) {
    missingFields.push('Life Area');
  }

  if (!candidate.tradeoffs || candidate.tradeoffs.trim().length === 0) {
    warnings.push(
      'Cost / Trade-off khali hai: soch lein ki is goal ke liye waqt ya energy kahan se aayegi.'
    );
  }
  if (!candidate.capacityNotes || candidate.capacityNotes.trim().length === 0) {
    warnings.push(
      'First Next Action ya capacity note likhne se shuruaat aasan hoti hai.'
    );
  }

  const combinedText = `${candidate.title || ''} ${candidate.desiredOutcome || ''} ${candidate.tradeoffs || ''}`.toLowerCase();
  const advisorySleepOnIt =
    combinedText.length > 180 ||
    /roz 3 ghante|loan|invest|quit|career switch|marathon|business/i.test(
      combinedText
    );

  const activeGoalCountWarning = activeGoalsCount >= 5;

  return {
    isReadyToAccept: missingFields.length === 0,
    missingFields,
    warnings,
    advisorySleepOnIt,
    activeGoalCountWarning,
  };
}

/**
 * Section 7.3 & S9: Validates an imported JSON backup file before restoring.
 */
export function validateImportPayload(obj: unknown): {
  ok: boolean;
  errors: string[];
} {
  const errors: string[] = [];
  if (!obj || typeof obj !== 'object') {
    return { ok: false, errors: ['File valid JSON object nahi hai.'] };
  }

  const payload = obj as Partial<ExportPayload>;
  if (payload.app !== 'goal-os') {
    errors.push('Invalid app identifier: "goal-os" hona chahiye.');
  }
  if (typeof payload.version !== 'number' || payload.version < 1) {
    errors.push('Invalid export version.');
  }
  if (!payload.tables || typeof payload.tables !== 'object') {
    errors.push('Missing "tables" object in backup JSON.');
    return { ok: false, errors };
  }

  const requiredArrays: Array<keyof ExportPayload['tables']> = [
    'lifeAreas',
    'inboxItems',
    'goals',
    'tasks',
    'routines',
  ];

  for (const key of requiredArrays) {
    if (!Array.isArray(payload.tables[key])) {
      errors.push(`Table "${key}" ek valid array nahi hai.`);
    }
  }

  return {
    ok: errors.length === 0,
    errors,
  };
}
