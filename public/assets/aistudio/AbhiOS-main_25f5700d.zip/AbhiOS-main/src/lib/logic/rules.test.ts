import test from 'node:test';
import assert from 'node:assert/strict';
import {
  addDays,
  computeRoutineDueMinutes,
  daysBetween,
  isInQuietHours,
  isoDow,
  todayLocal,
} from './dates';
import {
  applyWaterDelta,
  computeFocusProgress,
  computeGoalProgressAndNextStep,
  computeLifeBalanceSnapshot,
  computeNextRecurrenceDate,
  computeTodayMomentum,
  DUTY_SHIFT_PRESETS,
  filterRoutinesForToday,
  formatFocusSeconds,
  generateTwoMinuteStarter,
  normalizeGoalTags,
  searchAllEntities,
  suggestContextualBrainDumpMatch,
  suggestDayTasks,
  suggestIfThenPlan,
  suggestMainPriority,
} from './planner';
import { computeNeedsAttention, shouldShowReEntry } from './attention';
import {
  evaluateGoalCandidateGate,
  validateImportPayload,
} from './quality-gate';
import { evaluateReminderTick } from './tick-logic';
import { Routine, Task, UserSettings } from '../types';

test('todayLocal respects dayRolloverHour at 02:30 IST', () => {
  // 2026-10-30 02:30 IST is 2026-10-29 21:00 UTC
  const nightDutyUtc = new Date('2026-10-29T21:00:00.000Z');
  assert.equal(todayLocal('Asia/Kolkata', 4, nightDutyUtc), '2026-10-29');
  assert.equal(todayLocal('Asia/Kolkata', 2, nightDutyUtc), '2026-10-30');
});

test('isInQuietHours handles midnight wrap (23:00 to 06:00)', () => {
  assert.equal(isInQuietHours(23 * 60 + 15, '23:00', '06:00'), true);
  assert.equal(isInQuietHours(2 * 60, '23:00', '06:00'), true);
  assert.equal(isInQuietHours(6 * 60, '23:00', '06:00'), false);
  assert.equal(isInQuietHours(14 * 60, '23:00', '06:00'), false);
});

test('computeRoutineDueMinutes handles wake and duty_start offsets', () => {
  const settings = { wakeTime: '06:30' };
  const readyForDuty = {
    anchorType: 'duty_start' as const,
    clockTime: null,
    anchorOffsetMin: -90,
  };
  assert.equal(
    computeRoutineDueMinutes(readyForDuty, settings, {
      dutyStart: '08:00',
      isOff: false,
    }),
    6 * 60 + 30 // 08:00 - 90m = 06:30
  );
  assert.equal(
    computeRoutineDueMinutes(readyForDuty, settings, {
      dutyStart: null,
      isOff: false,
    }),
    null
  );
});

test('suggestMainPriority and suggestDayTasks respect urgency, stale rule, and 80% budget', () => {
  const today = '2026-10-30';
  const tasks: Task[] = [
    {
      id: 't-stale',
      userId: 'u1',
      title: '20 days old stale task',
      status: 'todo',
      dueDate: addDays(today, -20),
      estMinutes: 30,
      rescheduleCount: 0,
      createdAt: today,
      updatedAt: today,
    },
    {
      id: 't-today',
      userId: 'u1',
      goalId: 'g-active',
      title: 'Due today active goal task',
      status: 'todo',
      dueDate: today,
      estMinutes: 45,
      rescheduleCount: 0,
      createdAt: today,
      updatedAt: today,
    },
    {
      id: 't-tomorrow',
      userId: 'u1',
      title: 'Due tomorrow task',
      status: 'todo',
      dueDate: addDays(today, 1),
      estMinutes: 40,
      rescheduleCount: 0,
      createdAt: today,
      updatedAt: today,
    },
  ];

  const main = suggestMainPriority(tasks, today, new Set(['g-active']));
  assert.equal(main?.id, 't-today');

  // 100 available minutes => 80m budget. t-today (45m) + t-stale (30m) = 75m (t-tomorrow 40m won't fit 80m)
  const plan = suggestDayTasks(tasks, 100, today, new Set(['g-active']));
  assert.equal(plan.budgetMinutes, 80);
  assert.equal(plan.mainTask?.id, 't-today');
  assert.equal(plan.totalMinutes <= 80, true);
});

test('applyWaterDelta transitions partial -> done -> null on zero', () => {
  const waterRoutine = { id: 'r-water', targetValue: 2500 };
  let log = applyWaterDelta(null, waterRoutine, 250, '2026-10-30', 'u1');
  assert.equal(log?.value, 250);
  assert.equal(log?.status, 'partial');

  log = applyWaterDelta(log, waterRoutine, 2250, '2026-10-30', 'u1');
  assert.equal(log?.value, 2500);
  assert.equal(log?.status, 'done');

  const cleared = applyWaterDelta(log, waterRoutine, -2500, '2026-10-30', 'u1');
  assert.equal(cleared, null);
});

test('computeNeedsAttention separates overdue (<14d) from stale (>=14d) and checks re-entry', () => {
  const today = '2026-10-30';
  const summary = computeNeedsAttention({
    today,
    tasks: [
      {
        id: 't1',
        userId: 'u1',
        title: 'Recent overdue',
        status: 'todo',
        dueDate: addDays(today, -3),
        rescheduleCount: 0,
        createdAt: today,
        updatedAt: today,
      },
      {
        id: 't2',
        userId: 'u1',
        title: 'Stale overdue',
        status: 'todo',
        dueDate: addDays(today, -16),
        rescheduleCount: 4,
        createdAt: today,
        updatedAt: today,
      },
    ],
    inboxItems: [],
    goals: [],
  });

  assert.equal(summary.overdueTasks.length, 1);
  assert.equal(summary.staleTasks.length, 1);
  assert.equal(summary.rescheduleHeavyTasks.length, 1);
  assert.equal(shouldShowReEntry('2026-10-25', today), true);
  assert.equal(shouldShowReEntry('2026-10-28', today), false);
});

test('evaluateGoalCandidateGate enforces required fields and soft active cap', () => {
  const incomplete = evaluateGoalCandidateGate({ title: 'Get Fit' }, 6);
  assert.equal(incomplete.isReadyToAccept, false);
  assert.equal(incomplete.activeGoalCountWarning, true);

  const complete = evaluateGoalCandidateGate(
    {
      title: 'Run 5km comfortably',
      desiredOutcome: '30 minute me bina ruke 5km daudna',
      purposeReason: 'Stamina aur duty ke baad energy banaye rakhne ke liye',
      lifeAreaId: 'area-health',
    },
    3
  );
  assert.equal(complete.isReadyToAccept, true);
  assert.equal(complete.activeGoalCountWarning, false);
});

test('evaluateReminderTick respects quiet hours, checkpoints, and digest batching', () => {
  const settings: UserSettings = {
    userId: 'u1',
    timezone: 'Asia/Kolkata',
    wakeTime: '06:30',
    quietStart: '23:00',
    quietEnd: '06:00',
    dayRolloverHour: 4,
    dailyWorkloadMinutes: 120,
    dutyPromptTime: '06:45',
    reviewTime: '21:30',
    maxRemindersPerDay: 8,
    pushEnabled: true,
  };

  const routines: Routine[] = [
    {
      id: 'r-brush',
      userId: 'u1',
      title: 'Brush & Fresh',
      block: 'morning',
      anchorType: 'wake',
      anchorOffsetMin: 15, // 06:45
      appliesOn: 'all',
      daysOfWeek: [1, 2, 3, 4, 5, 6, 7],
      isMust: true,
      active: true,
      sortOrder: 1,
    },
    {
      id: 'r-water',
      userId: 'u1',
      title: 'Paani 2.5L',
      block: 'anytime',
      anchorType: 'clock',
      anchorOffsetMin: 0,
      appliesOn: 'all',
      daysOfWeek: [1, 2, 3, 4, 5, 6, 7],
      isMust: true,
      targetValue: 2500,
      stepValue: 250,
      unit: 'ml',
      checkpoints: [{ at: '11:00', min: 750 }],
      active: true,
      sortOrder: 2,
    },
  ];

  // At 07:00 (420m), Brush (due 06:45 = 405m) is within 90m window
  const res = evaluateReminderTick({
    todayDate: '2026-10-30',
    nowMin: 7 * 60,
    settings,
    dayPlan: {
      id: 'dp1',
      userId: 'u1',
      planDate: '2026-10-30',
      isOff: false,
      dutyStart: '09:00',
      minimumDay: false,
      locked: false,
    },
    routines,
    routineLogs: [],
    reminderSentToday: [],
    hasDailyReviewToday: false,
  });

  assert.equal(res.skippedQuietHours, false);
  assert.equal(res.dueItems.length, 1);
  assert.equal(res.digestNotification?.actions[0]?.action, 'done');
  assert.equal(daysBetween('2026-10-29', '2026-10-30'), 1);
  assert.equal(isoDow('2026-10-30'), 5); // Friday
});

test('validateImportPayload rejects malformed files and accepts valid goal-os exports', () => {
  assert.equal(validateImportPayload(null).ok, false);
  assert.equal(validateImportPayload({ app: 'other' }).ok, false);
  assert.equal(
    validateImportPayload({
      app: 'goal-os',
      version: 2,
      exported_at: new Date().toISOString(),
      tables: {
        lifeAreas: [],
        inboxItems: [],
        goals: [],
        tasks: [],
        routines: [],
      },
    }).ok,
    true
  );
});

test('focus timer helpers, If-Then plan generator, and shift presets work deterministically', () => {
  assert.equal(formatFocusSeconds(1500), '25:00');
  assert.equal(formatFocusSeconds(65), '01:05');
  assert.equal(formatFocusSeconds(0), '00:00');
  assert.equal(computeFocusProgress(750, 1500), 50);
  assert.equal(computeFocusProgress(0, 1500), 100);
  assert.equal(DUTY_SHIFT_PRESETS.length, 5);
  assert.ok(suggestIfThenPlan('Morning Walk', 'Jute pehen kar bahar niklo').includes('Agar duty ke baad'));
});

test('normalizeGoalTags and computeTodayMomentum work accurately', () => {
  assert.deepEqual(normalizeGoalTags('health, #Relationship, finance #health'), [
    '#health',
    '#relationship',
    '#finance',
  ]);
  const mom = computeTodayMomentum({
    todayPendingCount: 2,
    todayCompletedCount: 2,
    routinesDoneCount: 3,
    routinesTotalCount: 4,
  });
  assert.equal(mom.completedUnits, 5);
  assert.equal(mom.totalUnits, 8);
  assert.equal(mom.percent, 63);
});

test('suggestContextualBrainDumpMatch suggests matching category and goal from typed thought', () => {
  const areas = [
    { id: 'area-health', name: 'Health', status: 'active' },
    { id: 'area-finance', name: 'Finance', status: 'active' },
    { id: 'area-relationships', name: 'Relationship', status: 'active' },
  ];
  const goals = [
    {
      id: 'goal-1',
      title: 'Duty ke saath consistent energy aur 2.5L hydration system',
      lifeAreaId: 'area-health',
      status: 'active',
    },
    {
      id: 'goal-2',
      title: '6-Month Emergency Fund (₹50,000 Buffer)',
      lifeAreaId: 'area-finance',
      status: 'active',
    },
  ];

  const financeMatch = suggestContextualBrainDumpMatch(
    'Har mahine ₹5,000 emergency fund me alag rakhna hai',
    areas,
    goals
  );
  assert.equal(financeMatch.suggestedAreaId, 'area-finance');
  assert.equal(financeMatch.suggestedGoalId, 'goal-2');

  const healthMatch = suggestContextualBrainDumpMatch(
    'Subah morning walk aur 2.5L water bottle lena hai',
    areas,
    goals
  );
  assert.equal(healthMatch.suggestedAreaId, 'area-health');
  assert.equal(healthMatch.suggestedGoalId, 'goal-1');
});

test('computeGoalProgressAndNextStep, computeNextRecurrenceDate, generateTwoMinuteStarter, computeLifeBalanceSnapshot, and searchAllEntities work accurately', () => {
  const progress = computeGoalProgressAndNextStep(
    'g1',
    [
      {
        id: 'm1',
        userId: 'u1',
        goalId: 'g1',
        title: 'Step 1',
        status: 'done',
        seq: 1,
        createdAt: '',
        updatedAt: '',
      },
      {
        id: 'm2',
        userId: 'u1',
        goalId: 'g1',
        title: 'Step 2',
        status: 'todo',
        seq: 2,
        createdAt: '',
        updatedAt: '',
      },
    ],
    [
      {
        id: 't1',
        userId: 'u1',
        goalId: 'g1',
        title: 'Task 1',
        status: 'done',
        rescheduleCount: 0,
        createdAt: '',
        updatedAt: '',
      },
      {
        id: 't2',
        userId: 'u1',
        goalId: 'g1',
        title: 'Task 2 Next',
        status: 'todo',
        rescheduleCount: 0,
        createdAt: '',
        updatedAt: '',
      },
    ]
  );
  assert.equal(progress.completedSteps, 2);
  assert.equal(progress.totalSteps, 4);
  assert.equal(progress.percent, 50);
  assert.equal(progress.nextUpTask?.id, 't2');
  assert.equal(progress.nextUpMilestone?.id, 'm2');

  assert.equal(computeNextRecurrenceDate('2026-10-30', 'daily'), '2026-10-31');
  assert.equal(computeNextRecurrenceDate('2026-10-30', 'weekly'), '2026-11-06');
  assert.equal(computeNextRecurrenceDate('2026-10-30', 'monthly'), '2026-11-30');
  assert.equal(computeNextRecurrenceDate('2026-01-31', 'monthly'), '2026-02-28');

  const starter = generateTwoMinuteStarter('Purani almari sort karna');
  assert.equal(starter.length, 2);
  assert.ok(starter[0].includes('2-Min Shuruat'));

  const snapshot = computeLifeBalanceSnapshot(
    [
      { id: 'area-health', userId: 'u1', name: 'Health', status: 'active', sortOrder: 1 },
      { id: 'area-rel', userId: 'u1', name: 'Relationship', status: 'active', sortOrder: 2 },
    ],
    [
      {
        id: 'g1',
        userId: 'u1',
        lifeAreaId: 'area-health',
        title: 'Hydration',
        goalType: 'ongoing_direction',
        status: 'active',
        createdAt: '',
        updatedAt: '',
      },
    ],
    []
  );
  assert.equal(snapshot.items.length, 2);
  assert.ok(snapshot.calmInsight.includes('Relationship'));

  const hits = searchAllEntities('hydration', {
    lifeAreas: [{ id: 'area-health', userId: 'u1', name: 'Health', status: 'active', sortOrder: 1 }],
    inboxItems: [],
    goals: [
      {
        id: 'g1',
        userId: 'u1',
        lifeAreaId: 'area-health',
        title: '2.5L Hydration System',
        goalType: 'ongoing_direction',
        status: 'active',
        createdAt: '',
        updatedAt: '',
      },
    ],
    tasks: [],
    routines: [],
  });
  assert.equal(hits.length, 1);
  assert.equal(hits[0].kind, 'goal');
});





