'use client';

import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
} from 'react';
import {
  onAuthStateChanged,
  signInWithPopup,
  signOut,
  User,
} from 'firebase/auth';
import { auth, googleAuthProvider } from '@/src/lib/firebase';
import {
  AISuggestionDraft,
  AppStateData,
  DailyReview,
  DayPlan,
  ExportPayload,
  Goal,
  InboxItem,
  InboxLink,
  LifeArea,
  Milestone,
  Project,
  Routine,
  Task,
  UserSettings,
  WeeklyReview,
} from '@/src/lib/types';
import { createInitialSeedData } from '@/src/lib/seed-data';
import { addDays, todayLocal } from '@/src/lib/logic/dates';
import {
  applyWaterDelta,
  computeNextRecurrenceDate,
} from '@/src/lib/logic/planner';
import { validateImportPayload } from '@/src/lib/logic/quality-gate';

const LOCAL_STORAGE_KEY = 'goalos_v2_state_cache';

export type NavTab = 'today' | 'inbox' | 'tasks' | 'goals' | 'settings';

export interface ToastMessage {
  id: string;
  text: string;
  type: 'success' | 'info' | 'warning' | 'error';
  undoAction?: () => void;
}

interface GoalOsContextValue {
  state: AppStateData;
  today: string;
  activeTab: NavTab;
  setActiveTab: (tab: NavTab) => void;
  user: User | null;
  authLoading: boolean;
  cloudSynced: boolean;
  aiAvailable: boolean;
  darkMode: boolean;
  toggleDarkMode: () => void;
  toasts: ToastMessage[];
  showToast: (
    text: string,
    type?: ToastMessage['type'],
    undoAction?: () => void
  ) => void;
  dismissToast: (id: string) => void;
  // Auth
  signInWithGoogle: () => Promise<void>;
  logoutUser: () => Promise<void>;
  // Quick Capture & Inbox
  quickCaptureOpen: boolean;
  setQuickCaptureOpen: (open: boolean) => void;
  quickCapture: (
    content: string,
    source?: InboxItem['source'],
    options?: {
      lifeAreaId?: string | null;
      tags?: string[];
      status?: InboxItem['status'];
      decisionNote?: string;
    }
  ) => InboxItem | null;
  updateInboxItem: (id: string, patch: Partial<InboxItem>) => void;
  restoreInboxItem: (id: string) => void;
  splitInboxItem: (id: string, subContents: string[]) => void;
  mergeInboxItems: (primaryId: string, duplicateId: string) => void;
  convertInboxToEntity: (
    inboxId: string,
    targetType: 'task' | 'goal_candidate' | 'project' | 'routine',
    fields: Record<string, unknown>
  ) => string;
  moveInboxToExistingGoal: (
    inboxId: string,
    goalId: string,
    stepType?: 'milestone' | 'task',
    customTitle?: string
  ) => string;
  captureAndMoveToGoal: (
    content: string,
    goalId: string,
    stepType?: 'milestone' | 'task'
  ) => string | null;
  // Goal Quality Gate & Goals
  activeQualityGateGoalId: string | null;
  setActiveQualityGateGoalId: (id: string | null) => void;
  createGoalCandidate: (fields: Partial<Goal>) => Goal;
  createDirectGoal: (fields: Partial<Goal>) => Goal;
  updateGoal: (id: string, patch: Partial<Goal>) => void;
  resolveGoalCandidateGate: (
    goalId: string,
    decision:
      | 'accept'
      | 'refine'
      | 'convert_project'
      | 'convert_task'
      | 'convert_habit'
      | 'someday'
      | 'reference'
      | 'decline',
    patch: Partial<Goal>,
    firstNextActionTitle?: string
  ) => void;
  createProject: (fields: Partial<Project>) => Project;
  updateProject: (id: string, patch: Partial<Project>) => void;
  createMilestone: (fields: Partial<Milestone>) => Milestone;
  updateMilestone: (id: string, patch: Partial<Milestone>) => void;
  reorderMilestone: (milestoneId: string, direction: 'up' | 'down') => void;
  createLifeArea: (name: string, description?: string) => LifeArea | null;
  updateLifeArea: (id: string, patch: Partial<LifeArea>) => void;
  archiveLifeArea: (id: string) => void;
  // Tasks
  createTask: (fields: Partial<Task>) => Task;
  updateTask: (id: string, patch: Partial<Task>) => void;
  completeTask: (id: string) => void;
  reopenTask: (id: string) => void;
  rescheduleTask: (id: string, newDate: string) => void;
  splitTaskIntoSubtasks: (id: string, subTitles: string[]) => void;
  // Today, DayPlan, Routines & Water
  todayPlan: DayPlan;
  upsertTodayPlan: (patch: Partial<DayPlan>) => void;
  toggleRoutineDone: (routineId: string) => void;
  skipRoutineToday: (routineId: string) => void;
  addWater: (routineId: string, deltaMl: number) => void;
  createRoutine: (fields: Partial<Routine>) => void;
  updateRoutine: (id: string, patch: Partial<Routine>) => void;
  reorderRoutine: (id: string, direction: 'up' | 'down') => void;
  // Reviews & Re-entry
  saveDailyReview: (fields: Partial<DailyReview>) => void;
  saveWeeklyReview: (fields: Partial<WeeklyReview>) => void;
  simulateGapDays: (days: number) => void;
  performFreshStartCleanup: () => void;
  // Settings, Backup & AI
  updateSettings: (patch: Partial<UserSettings>) => void;
  exportBackupJson: () => ExportPayload;
  importBackupJson: (
    rawJson: unknown,
    mode: 'merge' | 'replace-empty'
  ) => { ok: boolean; error?: string };
  requestAiSuggestion: (
    mode:
      | 'inbox_clarify'
      | 'goal_gate_assist'
      | 'goal_breakdown'
      | 'task_split',
    text: string,
    context?: Record<string, unknown>
  ) => Promise<{ aiUsed: boolean; draft: AISuggestionDraft }>;
}

const GoalOsContext = createContext<GoalOsContextValue | null>(null);

function makeId(prefix: string): string {
  return `${prefix}-${Date.now().toString(36)}-${Math.random()
    .toString(36)
    .slice(2, 7)}`;
}

export function GoalOsProvider({ children }: { children: React.ReactNode }) {
  const [state, setState] = useState<AppStateData>(() =>
    createInitialSeedData('local-user')
  );
  const [activeTab, setActiveTab] = useState<NavTab>('today');
  const [user, setUser] = useState<User | null>(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [cloudSynced, setCloudSynced] = useState(false);
  const [aiAvailable, setAiAvailable] = useState(false);
  const [darkMode, setDarkMode] = useState(false);
  const [quickCaptureOpen, setQuickCaptureOpen] = useState(false);
  const [activeQualityGateGoalId, setActiveQualityGateGoalId] = useState<
    string | null
  >(null);
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const idTokenRef = useRef<string | null>(null);
  const hydratedRef = useRef(false);

  const showToast = useCallback(
    (
      text: string,
      type: ToastMessage['type'] = 'success',
      undoAction?: () => void
    ) => {
      const id = makeId('toast');
      setToasts((prev) => [...prev.slice(-2), { id, text, type, undoAction }]);
      setTimeout(() => {
        setToasts((prev) => prev.filter((t) => t.id !== id));
      }, 4500);
    },
    []
  );

  const dismissToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  // Load cached state & theme + check AI status on mount
  useEffect(() => {
    try {
      const savedTheme = window.localStorage.getItem('goalos_dark_mode');
      const isDark = savedTheme === 'true';
      setDarkMode(isDark);
      document.documentElement.classList.toggle('dark', isDark);

      const raw = window.localStorage.getItem(LOCAL_STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw) as AppStateData;
        if (parsed && Array.isArray(parsed.inboxItems)) {
          const seed = createInitialSeedData(parsed.settings?.userId || 'local-user');
          const seedAreaMap = new Map(seed.lifeAreas.map((a) => [a.id, a]));
          const existingAreaIds = new Set((parsed.lifeAreas || []).map((a) => a.id));
          const missingAreas = seed.lifeAreas.filter((a) => !existingAreaIds.has(a.id));
          const existingGoalIds = new Set((parsed.goals || []).map((g) => g.id));
          const missingSeedGoals = seed.goals.filter(
            (g) => !existingGoalIds.has(g.id)
          );
          const seedInboxMap = new Map(seed.inboxItems.map((i) => [i.id, i]));
          const seedGoalMap = new Map(seed.goals.map((g) => [g.id, g]));
          setState({
            ...parsed,
            lifeAreas: [
              ...(parsed.lifeAreas || []).map((a) => {
                const seedArea = seedAreaMap.get(a.id);
                return seedArea ? { ...a, name: seedArea.name } : a;
              }),
              ...missingAreas,
            ],
            inboxItems: (parsed.inboxItems || []).map((item) => {
              const seedMatch = seedInboxMap.get(item.id);
              return {
                ...item,
                lifeAreaId: item.lifeAreaId ?? seedMatch?.lifeAreaId ?? null,
                tags:
                  item.tags && item.tags.length > 0
                    ? item.tags
                    : seedMatch?.tags || [],
              };
            }),
            goals: [
              ...(parsed.goals || []).map((goal) => {
                const seedMatch = seedGoalMap.get(goal.id);
                return {
                  ...goal,
                  tags:
                    goal.tags && goal.tags.length > 0
                      ? goal.tags
                      : seedMatch?.tags || [],
                };
              }),
              ...missingSeedGoals,
            ],
          });
        }
      }
    } catch {
      // Ignore localStorage parse errors
    } finally {
      hydratedRef.current = true;
    }

    fetch('/api/ai/suggest')
      .then((r) => r.json())
      .then((d) => {
        if (typeof d?.aiAvailable === 'boolean') {
          setAiAvailable(d.aiAvailable);
        }
      })
      .catch(() => {});
  }, []);

  const toggleDarkMode = useCallback(() => {
    setDarkMode((prev) => {
      const next = !prev;
      document.documentElement.classList.toggle('dark', next);
      try {
        window.localStorage.setItem('goalos_dark_mode', String(next));
      } catch {}
      return next;
    });
  }, []);

  // Firebase Auth listener + Cloud SQL state fetch
  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (firebaseUser) => {
      setUser(firebaseUser);
      setAuthLoading(false);

      if (!firebaseUser) {
        idTokenRef.current = null;
        setCloudSynced(false);
        return;
      }

      try {
        const token = await firebaseUser.getIdToken();
        idTokenRef.current = token;
        const res = await fetch('/api/state', {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (res.ok) {
          const data = await res.json();
          if (data.state) {
            setState(data.state);
            setCloudSynced(true);
            window.localStorage.setItem(
              LOCAL_STORAGE_KEY,
              JSON.stringify(data.state)
            );
          }
        }
      } catch (err) {
        console.warn('Cloud SQL fetch fallback to local cache:', err);
      }
    });

    return () => unsub();
  }, []);

  // Persist state changes to localStorage and debounced Cloud SQL sync
  useEffect(() => {
    if (!hydratedRef.current) return;
    try {
      window.localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(state));
    } catch {}

    if (!user) return;
    const timer = setTimeout(async () => {
      try {
        const token = await user.getIdToken();
        idTokenRef.current = token;
        const res = await fetch('/api/state', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({ action: 'sync', state }),
        });
        if (res.ok) {
          setCloudSynced(true);
        }
      } catch {
        setCloudSynced(false);
      }
    }, 600);

    return () => clearTimeout(timer);
  }, [state, user]);

  const signInWithGoogle = useCallback(async () => {
    try {
      await signInWithPopup(auth, googleAuthProvider);
      showToast('Google Account aur Cloud SQL sync jud gaya!', 'success');
    } catch (error: unknown) {
      const msg =
        error instanceof Error ? error.message : 'Google Sign-In cancel hua.';
      showToast(msg, 'warning');
    }
  }, [showToast]);

  const logoutUser = useCallback(async () => {
    await signOut(auth);
    idTokenRef.current = null;
    setCloudSynced(false);
    showToast('Signed out (Local offline mode active).', 'info');
  }, [showToast]);

  const today = useMemo(() => {
    return todayLocal(
      state.settings.timezone || 'Asia/Kolkata',
      state.settings.dayRolloverHour ?? 4
    );
  }, [state.settings.timezone, state.settings.dayRolloverHour]);

  const todayPlan = useMemo<DayPlan>(() => {
    const found = state.dayPlans.find((dp) => dp.planDate === today);
    if (found) return found;
    return {
      id: `${state.settings.userId}_${today}`,
      userId: state.settings.userId,
      planDate: today,
      isOff: false,
      dutyStart: '08:30',
      minimumDay: false,
      mainTaskId: null,
      locked: false,
    };
  }, [state.dayPlans, state.settings.userId, today]);

  // 1. Quick Capture (5-second Brain Dump with optional Field & Labels)
  const quickCapture = useCallback(
    (
      content: string,
      source: InboxItem['source'] = 'quick_capture',
      options?: {
        lifeAreaId?: string | null;
        tags?: string[];
        status?: InboxItem['status'];
        decisionNote?: string;
      }
    ): InboxItem | null => {
      const trimmed = content.trim();
      if (!trimmed) return null;
      const nowIso = new Date().toISOString();
      const targetStatus = options?.status || 'new';
      const newItem: InboxItem = {
        id: makeId('inb'),
        userId: state.settings.userId,
        content: trimmed,
        status: targetStatus,
        itemType: targetStatus === 'trash' ? 'duplicate' : 'unknown',
        source,
        lifeAreaId: options?.lifeAreaId || null,
        tags: options?.tags && options.tags.length > 0 ? options.tags : [],
        decisionNote: options?.decisionNote,
        createdAt: nowIso,
        updatedAt: nowIso,
      };
      setState((prev) => ({
        ...prev,
        inboxItems: [newItem, ...prev.inboxItems],
      }));
      if (targetStatus === 'trash') {
        showToast(
          'Thought seedha Trash me bhej diya gaya (Trash se wapas nikal sakte hain).',
          'info'
        );
      } else {
        showToast(
          'Brain Dump me save ho gaya — ab bagal se Category ya Goal me bhej sakte hain.',
          'success'
        );
      }
      return newItem;
    },
    [state.settings.userId, showToast]
  );

  const updateInboxItem = useCallback(
    (id: string, patch: Partial<InboxItem>) => {
      const nowIso = new Date().toISOString();
      setState((prev) => ({
        ...prev,
        inboxItems: prev.inboxItems.map((item) =>
          item.id === id ? { ...item, ...patch, updatedAt: nowIso } : item
        ),
      }));
    },
    []
  );

  const restoreInboxItem = useCallback(
    (id: string) => {
      updateInboxItem(id, { status: 'new', archivedAt: null });
      showToast('Thought wapas Unprocessed queue me aa gaya.', 'info');
    },
    [updateInboxItem, showToast]
  );

  const splitInboxItem = useCallback(
    (id: string, subContents: string[]) => {
      const validLines = subContents.map((s) => s.trim()).filter(Boolean);
      if (validLines.length === 0) return;
      const nowIso = new Date().toISOString();
      setState((prev) => {
        const parent = prev.inboxItems.find((i) => i.id === id);
        if (!parent) return prev;

        const childItems: InboxItem[] = validLines.map((line) => ({
          id: makeId('inb'),
          userId: prev.settings.userId,
          content: line,
          status: 'new',
          itemType: 'unknown',
          source: 'split',
          decisionNote: `Split from: "${parent.content.slice(0, 45)}"`,
          createdAt: nowIso,
          updatedAt: nowIso,
        }));

        const links: InboxLink[] = childItems.map((child) => ({
          id: makeId('lnk'),
          userId: prev.settings.userId,
          inboxItemId: id,
          targetType: 'inbox_item',
          targetId: child.id,
          createdAt: nowIso,
        }));

        return {
          ...prev,
          inboxItems: [
            ...childItems,
            ...prev.inboxItems.map((item) =>
              item.id === id
                ? {
                    ...item,
                    status: 'processed' as const,
                    linkedEntityType: 'split_multiple' as const,
                    processedAt: nowIso,
                    updatedAt: nowIso,
                  }
                : item
            ),
          ],
          inboxLinks: [...prev.inboxLinks, ...links],
        };
      });
      showToast(
        `Thought ko ${validLines.length} alag items me split kar diya gaya.`,
        'success'
      );
    },
    [showToast]
  );

  const mergeInboxItems = useCallback(
    (primaryId: string, duplicateId: string) => {
      if (primaryId === duplicateId) return;
      const nowIso = new Date().toISOString();
      setState((prev) => {
        const primary = prev.inboxItems.find((i) => i.id === primaryId);
        const dup = prev.inboxItems.find((i) => i.id === duplicateId);
        if (!primary || !dup) return prev;

        const mergedContent = `${primary.content}\n---\n[Merged]: ${dup.content}`;
        return {
          ...prev,
          inboxItems: prev.inboxItems.map((item) => {
            if (item.id === primaryId) {
              return { ...item, content: mergedContent, updatedAt: nowIso };
            }
            if (item.id === duplicateId) {
              return {
                ...item,
                status: 'trash' as const,
                itemType: 'duplicate' as const,
                decisionNote: `Merged into ${primaryId}`,
                updatedAt: nowIso,
              };
            }
            return item;
          }),
        };
      });
      showToast('Dono thoughts merge ho gaye (duplicate Trash me gaya).', 'info');
    },
    [showToast]
  );

  const convertInboxToEntity = useCallback(
    (
      inboxId: string,
      targetType: 'task' | 'goal_candidate' | 'project' | 'routine',
      fields: Record<string, unknown>
    ): string => {
      const nowIso = new Date().toISOString();
      const newEntityId = makeId(
        targetType === 'goal_candidate' ? 'goal' : targetType.slice(0, 4)
      );

      setState((prev) => {
        const origin = prev.inboxItems.find((i) => i.id === inboxId);
        const rawText = origin?.content || '';
        const defaultAreaId = prev.lifeAreas[0]?.id || 'area-personal';

        let nextTasks = prev.tasks;
        let nextGoals = prev.goals;
        let nextProjects = prev.projects;
        let nextRoutines = prev.routines;
        let linkedEntityType: InboxItem['linkedEntityType'] = 'task';

        if (targetType === 'task') {
          linkedEntityType = 'task';
          const newTask: Task = {
            id: newEntityId,
            userId: prev.settings.userId,
            title: String(fields.title || rawText.slice(0, 140)),
            nextAction: String(fields.nextAction || ''),
            goalId: fields.goalId ? String(fields.goalId) : null,
            milestoneId: fields.milestoneId ? String(fields.milestoneId) : null,
            projectId: fields.projectId ? String(fields.projectId) : null,
            originInboxItemId: inboxId,
            status: 'todo',
            estMinutes: fields.estMinutes ? Number(fields.estMinutes) : 20,
            dueDate: fields.dueDate ? String(fields.dueDate) : null,
            scheduledDate: fields.scheduledDate
              ? String(fields.scheduledDate)
              : null,
            rescheduleCount: 0,
            createdAt: nowIso,
            updatedAt: nowIso,
          };
          nextTasks = [newTask, ...prev.tasks];
        } else if (targetType === 'goal_candidate') {
          linkedEntityType = 'goal';
          const isDirectActive = Boolean(fields.directActivate);
          const resolvedTags =
            Array.isArray(fields.tags) && fields.tags.length > 0
              ? (fields.tags as string[])
              : origin?.tags || [];
          const newCandidate: Goal = {
            id: newEntityId,
            userId: prev.settings.userId,
            lifeAreaId: String(
              fields.lifeAreaId || origin?.lifeAreaId || defaultAreaId
            ),
            title: String(fields.title || rawText.slice(0, 140)),
            desiredOutcome: String(fields.desiredOutcome || rawText),
            purposeReason: String(fields.purposeReason || ''),
            ownershipReflection: String(fields.ownershipReflection || ''),
            evidenceOfProgress: String(fields.evidenceOfProgress || ''),
            controlNotes: String(fields.controlNotes || ''),
            tradeoffs: String(fields.tradeoffs || ''),
            capacityNotes: String(fields.capacityNotes || ''),
            tags: resolvedTags,
            goalType:
              (fields.goalType as 'outcome' | 'ongoing_direction') || 'outcome',
            status: isDirectActive ? 'active' : 'candidate',
            targetDate: fields.targetDate ? String(fields.targetDate) : null,
            reviewDate: addDays(today, 7),
            reviewCadence:
              (fields.reviewCadence as 'weekly' | 'biweekly' | 'monthly') ||
              'weekly',
            originInboxItemId: inboxId,
            createdAt: nowIso,
            updatedAt: nowIso,
          };
          nextGoals = [newCandidate, ...prev.goals];
        } else if (targetType === 'project') {
          linkedEntityType = 'project';
          const newProj: Project = {
            id: newEntityId,
            userId: prev.settings.userId,
            goalId: fields.goalId ? String(fields.goalId) : null,
            lifeAreaId: String(
              fields.lifeAreaId || origin?.lifeAreaId || defaultAreaId
            ),
            title: String(fields.title || rawText.slice(0, 140)),
            description: String(fields.description || rawText),
            status: 'active',
            originInboxItemId: inboxId,
            createdAt: nowIso,
            updatedAt: nowIso,
          };
          nextProjects = [newProj, ...prev.projects];
        } else if (targetType === 'routine') {
          linkedEntityType = 'routine';
          const newRoutine: Routine = {
            id: newEntityId,
            userId: prev.settings.userId,
            originInboxItemId: inboxId,
            title: String(fields.title || rawText.slice(0, 80)),
            block: (fields.block as Routine['block']) || 'anytime',
            anchorType:
              (fields.anchorType as Routine['anchorType']) || 'clock',
            clockTime: String(fields.clockTime || '08:00'),
            anchorOffsetMin: Number(fields.anchorOffsetMin || 0),
            appliesOn: (fields.appliesOn as Routine['appliesOn']) || 'all',
            daysOfWeek: [1, 2, 3, 4, 5, 6, 7],
            isMust: Boolean(fields.isMust),
            active: true,
            sortOrder: prev.routines.length + 1,
          };
          nextRoutines = [...prev.routines, newRoutine];
        }

        const newLink: InboxLink = {
          id: makeId('lnk'),
          userId: prev.settings.userId,
          inboxItemId: inboxId,
          targetType: linkedEntityType,
          targetId: newEntityId,
          createdAt: nowIso,
        };

        return {
          ...prev,
          tasks: nextTasks,
          goals: nextGoals,
          projects: nextProjects,
          routines: nextRoutines,
          inboxLinks: [...prev.inboxLinks, newLink],
          inboxItems: prev.inboxItems.map((i) =>
            i.id === inboxId
              ? {
                  ...i,
                  status: 'processed' as const,
                  itemType:
                    targetType === 'routine'
                      ? ('habit_candidate' as const)
                      : targetType,
                  lifeAreaId:
                    fields.lifeAreaId
                      ? String(fields.lifeAreaId)
                      : i.lifeAreaId || null,
                  tags:
                    Array.isArray(fields.tags) && fields.tags.length > 0
                      ? (fields.tags as string[])
                      : i.tags || [],
                  linkedEntityType,
                  linkedEntityId: newEntityId,
                  processedAt: nowIso,
                  updatedAt: nowIso,
                }
              : i
          ),
        };
      });

      if (targetType === 'goal_candidate') {
        if (fields.directActivate) {
          showToast(
            'Brain Dump se Active Goal seedha Department me add ho gaya!',
            'success'
          );
        } else {
          setActiveQualityGateGoalId(newEntityId);
          showToast(
            'Goal Candidate ban gaya — ab Quality Gate review karein.',
            'info'
          );
        }
      } else {
        showToast(`Inbox item ko ${targetType} me badal diya gaya!`, 'success');
      }

      return newEntityId;
    },
    [today, showToast]
  );

  const moveInboxToExistingGoal = useCallback(
    (
      inboxId: string,
      goalId: string,
      stepType: 'milestone' | 'task' = 'milestone',
      customTitle?: string
    ): string => {
      const nowIso = new Date().toISOString();
      const stepId = makeId(stepType === 'milestone' ? 'ms' : 'task');

      setState((prev) => {
        const origin = prev.inboxItems.find((i) => i.id === inboxId);
        const targetGoal = prev.goals.find((g) => g.id === goalId);
        const cleanTitle = (
          customTitle ||
          origin?.content.split('\n')[0] ||
          'Goal Action Step'
        ).trim();

        let nextMilestones = prev.milestones;
        let nextTasks = prev.tasks;

        if (stepType === 'milestone') {
          const existingGoalMs = prev.milestones.filter(
            (m) => m.goalId === goalId
          );
          const newMs: Milestone = {
            id: stepId,
            userId: prev.settings.userId,
            goalId,
            title: cleanTitle,
            description: origin?.content || cleanTitle,
            status: 'todo',
            seq: existingGoalMs.length + 1,
            createdAt: nowIso,
            updatedAt: nowIso,
          };
          nextMilestones = [...prev.milestones, newMs];
        } else {
          const newTask: Task = {
            id: stepId,
            userId: prev.settings.userId,
            title: cleanTitle,
            nextAction: origin?.content || cleanTitle,
            goalId,
            milestoneId: null,
            projectId: null,
            originInboxItemId: inboxId,
            status: 'todo',
            estMinutes: 25,
            dueDate: null,
            scheduledDate: today,
            rescheduleCount: 0,
            createdAt: nowIso,
            updatedAt: nowIso,
          };
          nextTasks = [newTask, ...prev.tasks];
        }

        const newLink: InboxLink = {
          id: makeId('lnk'),
          userId: prev.settings.userId,
          inboxItemId: inboxId,
          targetType: 'goal',
          targetId: goalId,
          createdAt: nowIso,
        };

        return {
          ...prev,
          milestones: nextMilestones,
          tasks: nextTasks,
          inboxLinks: [...prev.inboxLinks, newLink],
          inboxItems: prev.inboxItems.map((i) =>
            i.id === inboxId
              ? {
                  ...i,
                  status: 'processed' as const,
                  itemType:
                    stepType === 'milestone'
                      ? ('goal_candidate' as const)
                      : ('task' as const),
                  lifeAreaId: targetGoal?.lifeAreaId || i.lifeAreaId || null,
                  linkedEntityType: 'goal' as const,
                  linkedEntityId: goalId,
                  decisionNote: `Moved directly to Goal: ${
                    targetGoal?.title || goalId
                  }`,
                  processedAt: nowIso,
                  updatedAt: nowIso,
                }
              : i
          ),
        };
      });

      showToast(
        stepType === 'milestone'
          ? 'Thought seedha chune gaye Goal ke Plan (Step) me jud gaya!'
          : 'Thought seedha chune gaye Goal ke Daily Task me jud gaya!',
        'success'
      );

      return stepId;
    },
    [today, showToast]
  );

  const captureAndMoveToGoal = useCallback(
    (
      content: string,
      goalId: string,
      stepType: 'milestone' | 'task' = 'milestone'
    ): string | null => {
      const trimmed = content.trim();
      if (!trimmed) return null;
      const nowIso = new Date().toISOString();
      const inboxId = makeId('inb');
      const stepId = makeId(stepType === 'milestone' ? 'ms' : 'task');

      setState((prev) => {
        const targetGoal = prev.goals.find((g) => g.id === goalId);
        const cleanTitle = trimmed.split('\n')[0].trim();

        const newInboxItem: InboxItem = {
          id: inboxId,
          userId: prev.settings.userId,
          content: trimmed,
          status: 'processed',
          itemType: stepType === 'milestone' ? 'goal_candidate' : 'task',
          source: 'manual',
          lifeAreaId: targetGoal?.lifeAreaId || null,
          linkedEntityType: 'goal',
          linkedEntityId: goalId,
          decisionNote: `Moved directly to Goal: ${
            targetGoal?.title || goalId
          }`,
          processedAt: nowIso,
          createdAt: nowIso,
          updatedAt: nowIso,
        };

        let nextMilestones = prev.milestones;
        let nextTasks = prev.tasks;

        if (stepType === 'milestone') {
          const existingGoalMs = prev.milestones.filter(
            (m) => m.goalId === goalId
          );
          const newMs: Milestone = {
            id: stepId,
            userId: prev.settings.userId,
            goalId,
            title: cleanTitle,
            description: trimmed,
            status: 'todo',
            seq: existingGoalMs.length + 1,
            createdAt: nowIso,
            updatedAt: nowIso,
          };
          nextMilestones = [...prev.milestones, newMs];
        } else {
          const newTask: Task = {
            id: stepId,
            userId: prev.settings.userId,
            title: cleanTitle,
            nextAction: trimmed,
            goalId,
            milestoneId: null,
            projectId: null,
            originInboxItemId: inboxId,
            status: 'todo',
            estMinutes: 25,
            dueDate: null,
            scheduledDate: today,
            rescheduleCount: 0,
            createdAt: nowIso,
            updatedAt: nowIso,
          };
          nextTasks = [newTask, ...prev.tasks];
        }

        const newLink: InboxLink = {
          id: makeId('lnk'),
          userId: prev.settings.userId,
          inboxItemId: inboxId,
          targetType: 'goal',
          targetId: goalId,
          createdAt: nowIso,
        };

        return {
          ...prev,
          inboxItems: [newInboxItem, ...prev.inboxItems],
          milestones: nextMilestones,
          tasks: nextTasks,
          inboxLinks: [...prev.inboxLinks, newLink],
        };
      });

      showToast(
        stepType === 'milestone'
          ? 'Thought seedha chune gaye Goal ke Plan (Steps) me add ho gaya!'
          : 'Thought seedha chune gaye Goal ke Daily Tasks me add ho gaya!',
        'success'
      );

      return stepId;
    },
    [today, showToast]
  );

  // 2. Goal Quality Gate & Goals
  const createGoalCandidate = useCallback(
    (fields: Partial<Goal>): Goal => {
      const nowIso = new Date().toISOString();
      const newGoal: Goal = {
        id: makeId('goal'),
        userId: state.settings.userId,
        lifeAreaId:
          fields.lifeAreaId || state.lifeAreas[0]?.id || 'area-personal',
        title: fields.title || 'Naya Goal Candidate',
        desiredOutcome: fields.desiredOutcome || '',
        purposeReason: fields.purposeReason || '',
        ownershipReflection: fields.ownershipReflection || '',
        evidenceOfProgress: fields.evidenceOfProgress || '',
        controlNotes: fields.controlNotes || '',
        tradeoffs: fields.tradeoffs || '',
        capacityNotes: fields.capacityNotes || '',
        tags: fields.tags || [],
        goalType: fields.goalType || 'outcome',
        status: 'candidate',
        targetDate: fields.targetDate || null,
        reviewDate: fields.reviewDate || addDays(today, 7),
        reviewCadence: fields.reviewCadence || 'weekly',
        originInboxItemId: fields.originInboxItemId || null,
        createdAt: nowIso,
        updatedAt: nowIso,
      };
      setState((prev) => ({
        ...prev,
        goals: [newGoal, ...prev.goals],
      }));
      setActiveQualityGateGoalId(newGoal.id);
      return newGoal;
    },
    [state.settings.userId, state.lifeAreas, today]
  );

  const createDirectGoal = useCallback(
    (fields: Partial<Goal>): Goal => {
      const nowIso = new Date().toISOString();
      const newGoal: Goal = {
        id: makeId('goal'),
        userId: state.settings.userId,
        lifeAreaId:
          fields.lifeAreaId || state.lifeAreas[0]?.id || 'area-health',
        title: (fields.title || 'Naya Ongoing Goal').trim(),
        desiredOutcome: fields.desiredOutcome?.trim() || '',
        purposeReason: fields.purposeReason?.trim() || '',
        ownershipReflection: fields.ownershipReflection?.trim() || '',
        evidenceOfProgress: fields.evidenceOfProgress?.trim() || '',
        controlNotes: fields.controlNotes?.trim() || '',
        tradeoffs: fields.tradeoffs?.trim() || '',
        capacityNotes: fields.capacityNotes?.trim() || '',
        tags: fields.tags || [],
        goalType: fields.goalType || 'ongoing_direction',
        status: fields.status || 'active',
        targetDate: fields.targetDate || null,
        reviewDate: fields.reviewDate || addDays(today, 7),
        reviewCadence: fields.reviewCadence || 'weekly',
        originInboxItemId: fields.originInboxItemId || null,
        createdAt: nowIso,
        updatedAt: nowIso,
      };
      setState((prev) => ({
        ...prev,
        goals: [newGoal, ...prev.goals],
      }));
      showToast(
        newGoal.goalType === 'ongoing_direction'
          ? 'Ongoing Goal set ho gaya — ye hamesha active system ki tarah chalega!'
          : 'Goal save ho gaya!',
        'success'
      );
      return newGoal;
    },
    [state.settings.userId, state.lifeAreas, today, showToast]
  );

  const updateGoal = useCallback(
    (id: string, patch: Partial<Goal>) => {
      const nowIso = new Date().toISOString();
      setState((prev) => ({
        ...prev,
        goals: prev.goals.map((g) =>
          g.id === id ? { ...g, ...patch, updatedAt: nowIso } : g
        ),
      }));
      showToast('Goal update ho gaya.', 'success');
    },
    [showToast]
  );

  const resolveGoalCandidateGate = useCallback(
    (
      goalId: string,
      decision:
        | 'accept'
        | 'refine'
        | 'convert_project'
        | 'convert_task'
        | 'convert_habit'
        | 'someday'
        | 'reference'
        | 'decline',
      patch: Partial<Goal>,
      firstNextActionTitle?: string
    ) => {
      const nowIso = new Date().toISOString();
      setState((prev) => {
        const targetGoal = prev.goals.find((g) => g.id === goalId);
        if (!targetGoal) return prev;
        const mergedGoal: Goal = {
          ...targetGoal,
          ...patch,
          updatedAt: nowIso,
        };

        if (decision === 'accept') {
          const acceptedGoal: Goal = {
            ...mergedGoal,
            status: 'active',
            reviewDate: mergedGoal.reviewDate || addDays(today, 7),
          };
          const nextTasks = [...prev.tasks];
          if (firstNextActionTitle && firstNextActionTitle.trim()) {
            nextTasks.unshift({
              id: makeId('task'),
              userId: prev.settings.userId,
              goalId: acceptedGoal.id,
              title: firstNextActionTitle.trim(),
              nextAction: firstNextActionTitle.trim(),
              status: 'todo',
              estMinutes: 25,
              scheduledDate: today,
              dueDate: null,
              rescheduleCount: 0,
              originInboxItemId: acceptedGoal.originInboxItemId || null,
              createdAt: nowIso,
              updatedAt: nowIso,
            });
          }
          return {
            ...prev,
            goals: prev.goals.map((g) =>
              g.id === goalId ? acceptedGoal : g
            ),
            tasks: nextTasks,
          };
        }

        if (decision === 'refine') {
          return {
            ...prev,
            goals: prev.goals.map((g) =>
              g.id === goalId ? { ...mergedGoal, status: 'candidate' } : g
            ),
          };
        }

        if (decision === 'convert_project') {
          const newProj: Project = {
            id: makeId('proj'),
            userId: prev.settings.userId,
            lifeAreaId: mergedGoal.lifeAreaId,
            title: mergedGoal.title,
            description: mergedGoal.desiredOutcome || mergedGoal.purposeReason,
            status: 'active',
            originInboxItemId: mergedGoal.originInboxItemId,
            createdAt: nowIso,
            updatedAt: nowIso,
          };
          return {
            ...prev,
            projects: [newProj, ...prev.projects],
            goals: prev.goals.filter((g) => g.id !== goalId),
          };
        }

        if (decision === 'convert_task') {
          const newTask: Task = {
            id: makeId('task'),
            userId: prev.settings.userId,
            title: mergedGoal.title,
            nextAction:
              firstNextActionTitle ||
              mergedGoal.capacityNotes ||
              mergedGoal.desiredOutcome ||
              '',
            status: 'todo',
            estMinutes: 30,
            scheduledDate: today,
            rescheduleCount: 0,
            originInboxItemId: mergedGoal.originInboxItemId,
            createdAt: nowIso,
            updatedAt: nowIso,
          };
          return {
            ...prev,
            tasks: [newTask, ...prev.tasks],
            goals: prev.goals.filter((g) => g.id !== goalId),
          };
        }

        if (decision === 'convert_habit') {
          const newRoutine: Routine = {
            id: makeId('rt'),
            userId: prev.settings.userId,
            title: mergedGoal.title.slice(0, 80),
            block: 'anytime',
            anchorType: 'clock',
            clockTime: '08:00',
            anchorOffsetMin: 0,
            appliesOn: 'all',
            daysOfWeek: [1, 2, 3, 4, 5, 6, 7],
            isMust: false,
            active: true,
            sortOrder: prev.routines.length + 1,
            originInboxItemId: mergedGoal.originInboxItemId,
          };
          return {
            ...prev,
            routines: [...prev.routines, newRoutine],
            goals: prev.goals.filter((g) => g.id !== goalId),
          };
        }

        if (decision === 'someday' || decision === 'reference') {
          const newInb: InboxItem = {
            id: makeId('inb'),
            userId: prev.settings.userId,
            content: `${mergedGoal.title} — ${mergedGoal.desiredOutcome || ''}`,
            status: decision === 'someday' ? 'someday' : 'archived',
            itemType: decision === 'someday' ? 'goal_candidate' : 'reference',
            source: 'manual',
            decisionNote: mergedGoal.purposeReason || 'Moved from Goal Gate',
            createdAt: nowIso,
            updatedAt: nowIso,
          };
          return {
            ...prev,
            inboxItems: [newInb, ...prev.inboxItems],
            goals: prev.goals.filter((g) => g.id !== goalId),
          };
        }

        // decline
        return {
          ...prev,
          goals: prev.goals.map((g) =>
            g.id === goalId ? { ...mergedGoal, status: 'archived' } : g
          ),
        };
      });

      setActiveQualityGateGoalId(null);
      const toastMap: Record<typeof decision, string> = {
        accept: 'Goal Quality Gate pass! Ab ye Active Goal hai.',
        refine: 'Goal Candidate save ho gaya (kal phir review kar sakte hain).',
        convert_project: 'Goal Candidate ko Project me badal diya gaya.',
        convert_task: 'Goal Candidate ko Single Task me badal diya gaya.',
        convert_habit: 'Goal Candidate ko Daily Routine me badal diya gaya.',
        someday: 'Someday / Maybe list me surakshit rakh diya gaya.',
        reference: 'Reference / Idea archive me save kar diya gaya.',
        decline: 'Goal Candidate decline karke archive kar diya gaya.',
      };
      showToast(toastMap[decision], 'success');
    },
    [today, showToast]
  );

  const createProject = useCallback(
    (fields: Partial<Project>): Project => {
      const nowIso = new Date().toISOString();
      const proj: Project = {
        id: makeId('proj'),
        userId: state.settings.userId,
        goalId: fields.goalId || null,
        lifeAreaId:
          fields.lifeAreaId || state.lifeAreas[0]?.id || 'area-personal',
        title: fields.title || 'Naya Project',
        description: fields.description || '',
        status: 'active',
        originInboxItemId: fields.originInboxItemId || null,
        createdAt: nowIso,
        updatedAt: nowIso,
      };
      setState((prev) => ({ ...prev, projects: [proj, ...prev.projects] }));
      showToast('Project add ho gaya.', 'success');
      return proj;
    },
    [state.settings.userId, state.lifeAreas, showToast]
  );

  const updateProject = useCallback((id: string, patch: Partial<Project>) => {
    const nowIso = new Date().toISOString();
    setState((prev) => ({
      ...prev,
      projects: prev.projects.map((p) =>
        p.id === id ? { ...p, ...patch, updatedAt: nowIso } : p
      ),
    }));
  }, []);

  const createMilestone = useCallback(
    (fields: Partial<Milestone>): Milestone => {
      const nowIso = new Date().toISOString();
      const existingForGoal = state.milestones.filter(
        (m) => m.goalId === fields.goalId
      );
      const ms: Milestone = {
        id: makeId('ms'),
        userId: state.settings.userId,
        goalId: fields.goalId || '',
        title: fields.title || 'Milestone Checkpoint',
        description: fields.description || '',
        status: 'todo',
        seq: existingForGoal.length + 1,
        createdAt: nowIso,
        updatedAt: nowIso,
      };
      setState((prev) => ({ ...prev, milestones: [...prev.milestones, ms] }));
      showToast('Milestone joda gaya.', 'success');
      return ms;
    },
    [state.milestones, state.settings.userId, showToast]
  );

  const updateMilestone = useCallback(
    (id: string, patch: Partial<Milestone>) => {
      const nowIso = new Date().toISOString();
      setState((prev) => ({
        ...prev,
        milestones: prev.milestones.map((m) =>
          m.id === id ? { ...m, ...patch, updatedAt: nowIso } : m
        ),
      }));
    },
    []
  );

  const reorderMilestone = useCallback(
    (milestoneId: string, direction: 'up' | 'down') => {
      setState((prev) => {
        const target = prev.milestones.find((m) => m.id === milestoneId);
        if (!target) return prev;
        const siblings = prev.milestones
          .filter((m) => m.goalId === target.goalId)
          .sort((a, b) => a.seq - b.seq);
        const idx = siblings.findIndex((m) => m.id === milestoneId);
        const swapIdx = direction === 'up' ? idx - 1 : idx + 1;
        if (swapIdx < 0 || swapIdx >= siblings.length) return prev;

        const reordered = [...siblings];
        const temp = reordered[idx];
        reordered[idx] = reordered[swapIdx];
        reordered[swapIdx] = temp;

        const seqMap = new Map<string, number>();
        reordered.forEach((m, i) => seqMap.set(m.id, i + 1));

        return {
          ...prev,
          milestones: prev.milestones.map((m) =>
            seqMap.has(m.id) ? { ...m, seq: seqMap.get(m.id)! } : m
          ),
        };
      });
    },
    []
  );

  const createLifeArea = useCallback(
    (name: string, description?: string): LifeArea | null => {
      if (!name.trim()) return null;
      const newArea: LifeArea = {
        id: makeId('area'),
        userId: state.settings.userId,
        name: name.trim(),
        description: description?.trim() || '',
        status: 'active',
        sortOrder: state.lifeAreas.length + 1,
      };
      setState((prev) => ({
        ...prev,
        lifeAreas: [...prev.lifeAreas, newArea],
      }));
      showToast(`Department / Field "${name.trim()}" add ho gaya.`, 'success');
      return newArea;
    },
    [state.settings.userId, state.lifeAreas.length, showToast]
  );

  const updateLifeArea = useCallback(
    (id: string, patch: Partial<LifeArea>) => {
      setState((prev) => ({
        ...prev,
        lifeAreas: prev.lifeAreas.map((a) =>
          a.id === id ? { ...a, ...patch } : a
        ),
      }));
      showToast('Department update ho gaya.', 'success');
    },
    [showToast]
  );

  const archiveLifeArea = useCallback((id: string) => {
    setState((prev) => ({
      ...prev,
      lifeAreas: prev.lifeAreas.map((a) =>
        a.id === id ? { ...a, status: 'archived' as const } : a
      ),
    }));
  }, []);

  // 3. Tasks
  const createTask = useCallback(
    (fields: Partial<Task>): Task => {
      const nowIso = new Date().toISOString();
      const newTask: Task = {
        id: makeId('task'),
        userId: state.settings.userId,
        goalId: fields.goalId || null,
        milestoneId: fields.milestoneId || null,
        projectId: fields.projectId || null,
        parentTaskId: fields.parentTaskId || null,
        originInboxItemId: fields.originInboxItemId || null,
        title: (fields.title || 'Naya Task').trim(),
        nextAction: fields.nextAction?.trim() || null,
        status: fields.status || 'todo',
        estMinutes: fields.estMinutes ?? 25,
        dueDate: fields.dueDate || null,
        scheduledDate: fields.scheduledDate || null,
        recurrence: fields.recurrence || 'none',
        rescheduleCount: 0,
        createdAt: nowIso,
        updatedAt: nowIso,
      };
      setState((prev) => ({
        ...prev,
        tasks: [newTask, ...prev.tasks],
      }));
      showToast('Task save ho gaya.', 'success');
      return newTask;
    },
    [state.settings.userId, showToast]
  );

  const updateTask = useCallback((id: string, patch: Partial<Task>) => {
    const nowIso = new Date().toISOString();
    setState((prev) => ({
      ...prev,
      tasks: prev.tasks.map((t) =>
        t.id === id ? { ...t, ...patch, updatedAt: nowIso } : t
      ),
    }));
  }, []);

  const completeTask = useCallback(
    (id: string) => {
      const nowIso = new Date().toISOString();
      let extraToastNote = '';

      setState((prev) => {
        const target = prev.tasks.find((t) => t.id === id);
        if (!target) return prev;

        let updatedTasks = prev.tasks.map((t) =>
          t.id === id
            ? {
                ...t,
                status: 'done' as const,
                completedAt: nowIso,
                updatedAt: nowIso,
              }
            : t
        );

        // 1. Recurring Task Auto-Spawn Next Occurrence
        if (target.recurrence && target.recurrence !== 'none') {
          const baseDate = target.scheduledDate || target.dueDate || today;
          const nextDate = computeNextRecurrenceDate(
            baseDate,
            target.recurrence
          );
          if (nextDate) {
            const spawnedTask: Task = {
              id: makeId('task'),
              userId: prev.settings.userId,
              goalId: target.goalId || null,
              milestoneId: target.milestoneId || null,
              projectId: target.projectId || null,
              parentTaskId: target.id,
              originInboxItemId: target.originInboxItemId || null,
              title: target.title,
              nextAction: target.nextAction || null,
              status: 'todo',
              estMinutes: target.estMinutes ?? 25,
              dueDate: target.dueDate ? nextDate : null,
              scheduledDate: nextDate,
              recurrence: target.recurrence,
              rescheduleCount: 0,
              createdAt: nowIso,
              updatedAt: nowIso,
            };
            updatedTasks = [spawnedTask, ...updatedTasks];
            extraToastNote = ` · Agla ${target.recurrence} task (${nextDate}) set ho gaya`;
          }
        }

        // 2. Goal Next-Action Auto-Queue: if this task belonged to a Goal, ensure the next step is queued
        if (target.goalId) {
          const remainingGoalTodoTasks = updatedTasks.filter(
            (t) =>
              t.goalId === target.goalId &&
              t.id !== id &&
              (t.status === 'todo' || t.status === 'doing')
          );

          const hasTodayTaskForGoal = remainingGoalTodoTasks.some(
            (t) => t.scheduledDate === today
          );

          if (!hasTodayTaskForGoal && remainingGoalTodoTasks.length > 0) {
            const nextUp = remainingGoalTodoTasks[0];
            updatedTasks = updatedTasks.map((t) =>
              t.id === nextUp.id
                ? { ...t, scheduledDate: today, updatedAt: nowIso }
                : t
            );
            extraToastNote = ` · Goal ka agla step "${nextUp.title.slice(
              0,
              32
            )}" Aaj me queue ho gaya!`;
          }
        }

        return {
          ...prev,
          tasks: updatedTasks,
        };
      });

      showToast(
        `Shabash! Task poora ho gaya${extraToastNote}`,
        'success',
        () => {
          updateTask(id, { status: 'todo', completedAt: null });
        }
      );
    },
    [showToast, today, updateTask]
  );

  const reopenTask = useCallback(
    (id: string) => {
      updateTask(id, { status: 'todo', completedAt: null });
      showToast('Task reopen kar diya gaya.', 'info');
    },
    [updateTask, showToast]
  );

  const rescheduleTask = useCallback(
    (id: string, newDate: string) => {
      const nowIso = new Date().toISOString();
      setState((prev) => ({
        ...prev,
        tasks: prev.tasks.map((t) =>
          t.id === id
            ? {
                ...t,
                scheduledDate: newDate,
                dueDate: t.dueDate && t.dueDate < newDate ? newDate : t.dueDate,
                rescheduleCount: (t.rescheduleCount ?? 0) + 1,
                updatedAt: nowIso,
              }
            : t
        ),
      }));
      showToast(`Task ${newDate} ke liye reschedule ho gaya.`, 'info');
    },
    [showToast]
  );

  const splitTaskIntoSubtasks = useCallback(
    (id: string, subTitles: string[]) => {
      const cleanTitles = subTitles.map((s) => s.trim()).filter(Boolean);
      if (cleanTitles.length === 0) return;
      const nowIso = new Date().toISOString();

      setState((prev) => {
        const parent = prev.tasks.find((t) => t.id === id);
        if (!parent) return prev;

        const children: Task[] = cleanTitles.map((title, idx) => ({
          id: makeId('task'),
          userId: prev.settings.userId,
          goalId: parent.goalId,
          milestoneId: parent.milestoneId,
          projectId: parent.projectId,
          parentTaskId: parent.id,
          originInboxItemId: parent.originInboxItemId,
          title,
          nextAction: title,
          status: 'todo',
          estMinutes: Math.max(
            10,
            Math.round((parent.estMinutes || 30) / cleanTitles.length)
          ),
          dueDate: parent.dueDate,
          scheduledDate: idx === 0 ? parent.scheduledDate || today : null,
          rescheduleCount: 0,
          createdAt: nowIso,
          updatedAt: nowIso,
        }));

        return {
          ...prev,
          tasks: [
            ...children,
            ...prev.tasks.map((t) =>
              t.id === id
                ? { ...t, status: 'cancelled' as const, updatedAt: nowIso }
                : t
            ),
          ],
        };
      });

      showToast(
        `Bada task ${cleanTitles.length} chhote steps me split ho gaya!`,
        'success'
      );
    },
    [today, showToast]
  );

  // 4. Today, DayPlan, Routines & Water
  const upsertTodayPlan = useCallback(
    (patch: Partial<DayPlan>) => {
      setState((prev) => {
        const existing = prev.dayPlans.find((dp) => dp.planDate === today);
        const updated: DayPlan = existing
          ? { ...existing, ...patch }
          : {
              id: `${prev.settings.userId}_${today}`,
              userId: prev.settings.userId,
              planDate: today,
              isOff: false,
              dutyStart: '08:30',
              minimumDay: false,
              mainTaskId: null,
              locked: false,
              ...patch,
            };

        const others = prev.dayPlans.filter((dp) => dp.planDate !== today);
        return {
          ...prev,
          dayPlans: [...others, updated],
        };
      });
    },
    [today]
  );

  const toggleRoutineDone = useCallback(
    (routineId: string) => {
      const nowIso = new Date().toISOString();
      setState((prev) => {
        const existing = prev.routineLogs.find(
          (l) => l.routineId === routineId && l.logDate === today
        );
        if (existing && existing.status === 'done') {
          return {
            ...prev,
            routineLogs: prev.routineLogs.filter((l) => l.id !== existing.id),
          };
        }
        const newLog = {
          id: existing?.id || `${routineId}_${today}`,
          userId: prev.settings.userId,
          routineId,
          logDate: today,
          status: 'done' as const,
          value: existing?.value || 1,
          completedAt: nowIso,
        };
        const others = prev.routineLogs.filter(
          (l) => !(l.routineId === routineId && l.logDate === today)
        );
        return {
          ...prev,
          routineLogs: [...others, newLog],
        };
      });
    },
    [today]
  );

  const skipRoutineToday = useCallback(
    (routineId: string) => {
      setState((prev) => {
        const others = prev.routineLogs.filter(
          (l) => !(l.routineId === routineId && l.logDate === today)
        );
        return {
          ...prev,
          routineLogs: [
            ...others,
            {
              id: `${routineId}_${today}`,
              userId: prev.settings.userId,
              routineId,
              logDate: today,
              status: 'skipped' as const,
              value: 0,
              completedAt: null,
            },
          ],
        };
      });
      showToast('Routine aaj ke liye skip kiya gaya (no guilt).', 'info');
    },
    [today, showToast]
  );

  const addWater = useCallback(
    (routineId: string, deltaMl: number) => {
      setState((prev) => {
        const routine = prev.routines.find((r) => r.id === routineId);
        if (!routine) return prev;
        const currentLog = prev.routineLogs.find(
          (l) => l.routineId === routineId && l.logDate === today
        );
        const updatedLog = applyWaterDelta(
          currentLog,
          routine,
          deltaMl,
          today,
          prev.settings.userId
        );
        const others = prev.routineLogs.filter(
          (l) => !(l.routineId === routineId && l.logDate === today)
        );
        return {
          ...prev,
          routineLogs: updatedLog ? [...others, updatedLog] : others,
        };
      });
    },
    [today]
  );

  const createRoutine = useCallback(
    (fields: Partial<Routine>) => {
      const newRoutine: Routine = {
        id: makeId('rt'),
        userId: state.settings.userId,
        goalId: fields.goalId || null,
        title: (fields.title || 'Naya Routine').trim(),
        block: fields.block || 'morning',
        anchorType: fields.anchorType || 'clock',
        clockTime: fields.clockTime || '07:00',
        anchorOffsetMin: fields.anchorOffsetMin ?? 0,
        appliesOn: fields.appliesOn || 'all',
        daysOfWeek: fields.daysOfWeek || [1, 2, 3, 4, 5, 6, 7],
        isMust: Boolean(fields.isMust),
        targetValue: fields.targetValue ?? null,
        stepValue: fields.stepValue ?? null,
        unit: fields.unit || null,
        checkpoints: fields.checkpoints || null,
        active: true,
        sortOrder: state.routines.length + 1,
      };
      setState((prev) => ({
        ...prev,
        routines: [...prev.routines, newRoutine],
      }));
      showToast('Routine save ho gaya.', 'success');
    },
    [state.settings.userId, state.routines.length, showToast]
  );

  const updateRoutine = useCallback((id: string, patch: Partial<Routine>) => {
    setState((prev) => ({
      ...prev,
      routines: prev.routines.map((r) =>
        r.id === id ? { ...r, ...patch } : r
      ),
    }));
  }, []);

  const reorderRoutine = useCallback((id: string, direction: 'up' | 'down') => {
    setState((prev) => {
      const sorted = [...prev.routines].sort(
        (a, b) => a.sortOrder - b.sortOrder
      );
      const idx = sorted.findIndex((r) => r.id === id);
      const swapIdx = direction === 'up' ? idx - 1 : idx + 1;
      if (swapIdx < 0 || swapIdx >= sorted.length) return prev;
      const temp = sorted[idx];
      sorted[idx] = sorted[swapIdx];
      sorted[swapIdx] = temp;
      return {
        ...prev,
        routines: sorted.map((r, i) => ({ ...r, sortOrder: i + 1 })),
      };
    });
  }, []);

  // 5. Reviews & Re-entry
  const saveDailyReview = useCallback(
    (fields: Partial<DailyReview>) => {
      setState((prev) => {
        const revDate = fields.reviewDate || today;
        const entry: DailyReview = {
          id: `${prev.settings.userId}_${revDate}`,
          userId: prev.settings.userId,
          reviewDate: revDate,
          completedText: fields.completedText || '',
          pendingText: fields.pendingText || '',
          surpriseText: fields.surpriseText || '',
          changeTomorrow: fields.changeTomorrow || '',
        };
        const others = prev.dailyReviews.filter(
          (r) => r.reviewDate !== revDate
        );
        return {
          ...prev,
          dailyReviews: [...others, entry],
          settings: {
            ...prev.settings,
            lastActiveDate: today,
          },
        };
      });
      showToast('Daily Review save ho gaya. Shubh Raatri!', 'success');
    },
    [today, showToast]
  );

  const saveWeeklyReview = useCallback(
    (fields: Partial<WeeklyReview>) => {
      setState((prev) => {
        const wk = fields.weekStart || today;
        const entry: WeeklyReview = {
          id: `${prev.settings.userId}_${wk}`,
          userId: prev.settings.userId,
          weekStart: wk,
          accomplishments: fields.accomplishments || '',
          challenges: fields.challenges || '',
          decisions: fields.decisions || '',
          nextPriorities: fields.nextPriorities || '',
        };
        const others = prev.weeklyReviews.filter((r) => r.weekStart !== wk);
        return {
          ...prev,
          weeklyReviews: [...others, entry],
        };
      });
      showToast('Weekly Review save ho gaya!', 'success');
    },
    [today, showToast]
  );

  const simulateGapDays = useCallback(
    (days: number) => {
      const simulatedLastActive = addDays(today, -days);
      setState((prev) => ({
        ...prev,
        settings: {
          ...prev.settings,
          lastActiveDate: simulatedLastActive,
        },
      }));
      showToast(
        `${days}-day gap simulate kiya gaya — Today screen par Fresh Start banner dekhein.`,
        'info'
      );
    },
    [today, showToast]
  );

  const performFreshStartCleanup = useCallback(() => {
    const nowIso = new Date().toISOString();
    setState((prev) => ({
      ...prev,
      tasks: prev.tasks.map((t) => {
        if (
          (t.status === 'todo' || t.status === 'doing') &&
          t.dueDate &&
          t.dueDate < today
        ) {
          return {
            ...t,
            scheduledDate: null,
            dueDate: null,
            status: 'paused' as const,
            updatedAt: nowIso,
          };
        }
        return t;
      }),
      settings: {
        ...prev.settings,
        lastActiveDate: today,
      },
    }));
    showToast(
      'Wapas swagat! Purane overdue tasks pause ho gaye — aaj se fresh start.',
      'success'
    );
  }, [today, showToast]);

  // 6. Settings, Backup & AI
  const updateSettings = useCallback(
    (patch: Partial<UserSettings>) => {
      setState((prev) => ({
        ...prev,
        settings: {
          ...prev.settings,
          ...patch,
        },
      }));
      showToast('Settings update ho gayi.', 'success');
    },
    [showToast]
  );

  const exportBackupJson = useCallback((): ExportPayload => {
    const nowIso = new Date().toISOString();
    setState((prev) => ({
      ...prev,
      settings: {
        ...prev.settings,
        lastBackupAt: nowIso,
      },
    }));
    return {
      app: 'goal-os',
      version: 2,
      exported_at: nowIso,
      tables: {
        ...state,
        settings: {
          ...state.settings,
          lastBackupAt: nowIso,
        },
      },
    };
  }, [state]);

  const importBackupJson = useCallback(
    (
      rawJson: unknown,
      mode: 'merge' | 'replace-empty'
    ): { ok: boolean; error?: string } => {
      const validation = validateImportPayload(rawJson);
      if (!validation.ok) {
        const err = validation.errors.join(' ');
        showToast(err, 'error');
        return { ok: false, error: err };
      }

      const payload = rawJson as ExportPayload;
      if (mode === 'replace-empty') {
        setState(payload.tables);
        showToast('Backup successfully restore ho gaya!', 'success');
        return { ok: true };
      }

      // Merge by id
      setState((prev) => {
        const mergeById = <T extends { id: string }>(
          existing: T[],
          incoming: T[] = []
        ): T[] => {
          const map = new Map<string, T>();
          existing.forEach((item) => map.set(item.id, item));
          incoming.forEach((item) => map.set(item.id, item));
          return Array.from(map.values());
        };

        return {
          settings: { ...prev.settings, ...(payload.tables.settings || {}) },
          lifeAreas: mergeById(prev.lifeAreas, payload.tables.lifeAreas),
          inboxItems: mergeById(prev.inboxItems, payload.tables.inboxItems),
          inboxLinks: mergeById(prev.inboxLinks, payload.tables.inboxLinks),
          goals: mergeById(prev.goals, payload.tables.goals),
          projects: mergeById(prev.projects, payload.tables.projects),
          milestones: mergeById(prev.milestones, payload.tables.milestones),
          tasks: mergeById(prev.tasks, payload.tables.tasks),
          dayPlans: mergeById(prev.dayPlans, payload.tables.dayPlans),
          routines: mergeById(prev.routines, payload.tables.routines),
          routineLogs: mergeById(prev.routineLogs, payload.tables.routineLogs),
          dailyReviews: mergeById(
            prev.dailyReviews,
            payload.tables.dailyReviews
          ),
          weeklyReviews: mergeById(
            prev.weeklyReviews,
            payload.tables.weeklyReviews
          ),
          reminderSent: mergeById(
            prev.reminderSent,
            payload.tables.reminderSent
          ),
        };
      });

      showToast('Backup data merge ho gaya!', 'success');
      return { ok: true };
    },
    [showToast]
  );

  const requestAiSuggestion = useCallback(
    async (
      mode:
        | 'inbox_clarify'
        | 'goal_gate_assist'
        | 'goal_breakdown'
        | 'task_split',
      text: string,
      context?: Record<string, unknown>
    ): Promise<{ aiUsed: boolean; draft: AISuggestionDraft }> => {
      const res = await fetch('/api/ai/suggest', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ mode, text, context }),
      });
      const data = await res.json();
      if (typeof data.aiAvailable === 'boolean') {
        setAiAvailable(data.aiAvailable);
      }
      return {
        aiUsed: Boolean(data.aiUsed),
        draft: data.draft || {},
      };
    },
    []
  );

  const value = useMemo<GoalOsContextValue>(
    () => ({
      state,
      today,
      activeTab,
      setActiveTab,
      user,
      authLoading,
      cloudSynced,
      aiAvailable,
      darkMode,
      toggleDarkMode,
      toasts,
      showToast,
      dismissToast,
      signInWithGoogle,
      logoutUser,
      quickCaptureOpen,
      setQuickCaptureOpen,
      quickCapture,
      updateInboxItem,
      restoreInboxItem,
      splitInboxItem,
      mergeInboxItems,
      convertInboxToEntity,
      moveInboxToExistingGoal,
      captureAndMoveToGoal,
      activeQualityGateGoalId,
      setActiveQualityGateGoalId,
      createGoalCandidate,
      createDirectGoal,
      updateGoal,
      resolveGoalCandidateGate,
      createProject,
      updateProject,
      createMilestone,
      updateMilestone,
      reorderMilestone,
      createLifeArea,
      updateLifeArea,
      archiveLifeArea,
      createTask,
      updateTask,
      completeTask,
      reopenTask,
      rescheduleTask,
      splitTaskIntoSubtasks,
      todayPlan,
      upsertTodayPlan,
      toggleRoutineDone,
      skipRoutineToday,
      addWater,
      createRoutine,
      updateRoutine,
      reorderRoutine,
      saveDailyReview,
      saveWeeklyReview,
      simulateGapDays,
      performFreshStartCleanup,
      updateSettings,
      exportBackupJson,
      importBackupJson,
      requestAiSuggestion,
    }),
    [
      state,
      today,
      activeTab,
      user,
      authLoading,
      cloudSynced,
      aiAvailable,
      darkMode,
      toggleDarkMode,
      toasts,
      showToast,
      dismissToast,
      signInWithGoogle,
      logoutUser,
      quickCaptureOpen,
      quickCapture,
      updateInboxItem,
      restoreInboxItem,
      splitInboxItem,
      mergeInboxItems,
      convertInboxToEntity,
      moveInboxToExistingGoal,
      captureAndMoveToGoal,
      activeQualityGateGoalId,
      createGoalCandidate,
      createDirectGoal,
      updateGoal,
      resolveGoalCandidateGate,
      createProject,
      updateProject,
      createMilestone,
      updateMilestone,
      reorderMilestone,
      createLifeArea,
      updateLifeArea,
      archiveLifeArea,
      createTask,
      updateTask,
      completeTask,
      reopenTask,
      rescheduleTask,
      splitTaskIntoSubtasks,
      todayPlan,
      upsertTodayPlan,
      toggleRoutineDone,
      skipRoutineToday,
      addWater,
      createRoutine,
      updateRoutine,
      reorderRoutine,
      saveDailyReview,
      saveWeeklyReview,
      simulateGapDays,
      performFreshStartCleanup,
      updateSettings,
      exportBackupJson,
      importBackupJson,
      requestAiSuggestion,
    ]
  );

  return (
    <GoalOsContext.Provider value={value}>{children}</GoalOsContext.Provider>
  );
}

export function useGoalOs() {
  const ctx = useContext(GoalOsContext);
  if (!ctx) {
    throw new Error('useGoalOs must be used within GoalOsProvider');
  }
  return ctx;
}
