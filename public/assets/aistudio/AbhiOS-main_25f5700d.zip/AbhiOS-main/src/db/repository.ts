import { eq } from 'drizzle-orm';
import { db } from './index.ts';
import {
  dailyReviews,
  dayPlans,
  goals,
  inboxItems,
  inboxLinks,
  lifeAreas,
  milestones,
  projects,
  reminderSent,
  routineLogs,
  routines,
  tasks,
  users,
  userSettings,
  weeklyReviews,
} from './schema.ts';
import { AppStateData } from '../lib/types.ts';
import { createInitialSeedData } from '../lib/seed-data.ts';

export async function getOrCreateUser(uid: string, email: string) {
  try {
    const result = await db
      .insert(users)
      .values({
        uid,
        email: email || 'user@goalos.local',
      })
      .onConflictDoUpdate({
        target: users.uid,
        set: {
          email: email || 'user@goalos.local',
        },
      })
      .returning();

    return result[0];
  } catch (error) {
    console.error('Database user upsert failed:', error);
    throw new Error('Database query failed. Please try again later.', {
      cause: error,
    });
  }
}

export async function getUserFullState(
  uid: string,
  email: string
): Promise<AppStateData> {
  try {
    await getOrCreateUser(uid, email);

    const [
      settingsRows,
      areaRows,
      inboxRows,
      linkRows,
      goalRows,
      projectRows,
      milestoneRows,
      taskRows,
      dayPlanRows,
      routineRows,
      logRows,
      dailyRevRows,
      weeklyRevRows,
      remSentRows,
    ] = await Promise.all([
      db.select().from(userSettings).where(eq(userSettings.userId, uid)),
      db.select().from(lifeAreas).where(eq(lifeAreas.userId, uid)),
      db.select().from(inboxItems).where(eq(inboxItems.userId, uid)),
      db.select().from(inboxLinks).where(eq(inboxLinks.userId, uid)),
      db.select().from(goals).where(eq(goals.userId, uid)),
      db.select().from(projects).where(eq(projects.userId, uid)),
      db.select().from(milestones).where(eq(milestones.userId, uid)),
      db.select().from(tasks).where(eq(tasks.userId, uid)),
      db.select().from(dayPlans).where(eq(dayPlans.userId, uid)),
      db.select().from(routines).where(eq(routines.userId, uid)),
      db.select().from(routineLogs).where(eq(routineLogs.userId, uid)),
      db.select().from(dailyReviews).where(eq(dailyReviews.userId, uid)),
      db.select().from(weeklyReviews).where(eq(weeklyReviews.userId, uid)),
      db.select().from(reminderSent).where(eq(reminderSent.userId, uid)),
    ]);

    // First-time user: seed initial starter setup in Cloud SQL
    if (areaRows.length === 0 && routineRows.length === 0) {
      const seed = createInitialSeedData(uid);
      await saveUserFullState(uid, email, seed);
      return seed;
    }

    const defaultSeed = createInitialSeedData(uid);
    const s = settingsRows[0];

    return {
      settings: s
        ? {
            userId: uid,
            timezone: s.timezone,
            wakeTime: s.wakeTime,
            quietStart: s.quietStart,
            quietEnd: s.quietEnd,
            dayRolloverHour: s.dayRolloverHour,
            dailyWorkloadMinutes: s.dailyWorkloadMinutes,
            dutyPromptTime: s.dutyPromptTime,
            reviewTime: s.reviewTime,
            maxRemindersPerDay: s.maxRemindersPerDay,
            pushEnabled: s.pushEnabled,
            lastActiveDate: s.lastActiveDate,
          }
        : defaultSeed.settings,
      lifeAreas: areaRows.map((r) => ({
        id: r.id,
        userId: uid,
        name: r.name,
        description: r.description,
        status: (r.status as 'active' | 'archived') || 'active',
        sortOrder: r.sortOrder,
      })),
      inboxItems: inboxRows.map((r) => ({
        id: r.id,
        userId: uid,
        content: r.content,
        status: r.status as AppStateData['inboxItems'][number]['status'],
        itemType: r.itemType as AppStateData['inboxItems'][number]['itemType'],
        source: (r.source as 'manual' | 'quick_capture' | 'split') || 'manual',
        lifeAreaId: r.lifeAreaId || null,
        tags: Array.isArray(r.tags) ? (r.tags as string[]) : [],
        decisionNote: r.decisionNote,
        linkedEntityType:
          r.linkedEntityType as AppStateData['inboxItems'][number]['linkedEntityType'],
        linkedEntityId: r.linkedEntityId,
        aiSuggestionJson:
          r.aiSuggestionJson as AppStateData['inboxItems'][number]['aiSuggestionJson'],
        processedAt: r.processedAt ? r.processedAt.toISOString() : null,
        archivedAt: r.archivedAt ? r.archivedAt.toISOString() : null,
        createdAt: r.createdAt.toISOString(),
        updatedAt: r.updatedAt.toISOString(),
      })),
      inboxLinks: linkRows.map((r) => ({
        id: r.id,
        userId: uid,
        inboxItemId: r.inboxItemId,
        targetType: r.targetType as AppStateData['inboxLinks'][number]['targetType'],
        targetId: r.targetId,
        createdAt: r.createdAt.toISOString(),
      })),
      goals: goalRows.map((r) => ({
        id: r.id,
        userId: uid,
        lifeAreaId: r.lifeAreaId,
        title: r.title,
        desiredOutcome: r.desiredOutcome,
        purposeReason: r.purposeReason,
        ownershipReflection: r.ownershipReflection,
        evidenceOfProgress: r.evidenceOfProgress,
        controlNotes: r.controlNotes,
        tradeoffs: r.tradeoffs,
        capacityNotes: r.capacityNotes,
        tags: Array.isArray(r.tags) ? (r.tags as string[]) : [],
        goalType: (r.goalType as 'outcome' | 'ongoing_direction') || 'outcome',
        status: r.status as AppStateData['goals'][number]['status'],
        targetDate: r.targetDate,
        reviewDate: r.reviewDate,
        reviewCadence:
          (r.reviewCadence as 'weekly' | 'biweekly' | 'monthly') || 'weekly',
        originInboxItemId: r.originInboxItemId,
        createdAt: r.createdAt.toISOString(),
        updatedAt: r.updatedAt.toISOString(),
      })),
      projects: projectRows.map((r) => ({
        id: r.id,
        userId: uid,
        goalId: r.goalId,
        lifeAreaId: r.lifeAreaId,
        title: r.title,
        description: r.description,
        status: r.status as AppStateData['projects'][number]['status'],
        originInboxItemId: r.originInboxItemId,
        createdAt: r.createdAt.toISOString(),
        updatedAt: r.updatedAt.toISOString(),
      })),
      milestones: milestoneRows.map((r) => ({
        id: r.id,
        userId: uid,
        goalId: r.goalId,
        title: r.title,
        description: r.description,
        status: r.status as AppStateData['milestones'][number]['status'],
        seq: r.seq,
        createdAt: r.createdAt.toISOString(),
        updatedAt: r.updatedAt.toISOString(),
      })),
      tasks: taskRows.map((r) => ({
        id: r.id,
        userId: uid,
        goalId: r.goalId,
        milestoneId: r.milestoneId,
        projectId: r.projectId,
        parentTaskId: r.parentTaskId,
        originInboxItemId: r.originInboxItemId,
        title: r.title,
        nextAction: r.nextAction,
        status: r.status as AppStateData['tasks'][number]['status'],
        estMinutes: r.estMinutes,
        dueDate: r.dueDate,
        scheduledDate: r.scheduledDate,
        rescheduleCount: r.rescheduleCount,
        completedAt: r.completedAt ? r.completedAt.toISOString() : null,
        createdAt: r.createdAt.toISOString(),
        updatedAt: r.updatedAt.toISOString(),
      })),
      dayPlans: dayPlanRows.map((r) => ({
        id: r.id,
        userId: uid,
        planDate: r.planDate,
        isOff: r.isOff,
        dutyStart: r.dutyStart,
        minimumDay: r.minimumDay,
        mainTaskId: r.mainTaskId,
        locked: r.locked,
      })),
      routines: routineRows.map((r) => ({
        id: r.id,
        userId: uid,
        goalId: r.goalId,
        originInboxItemId: r.originInboxItemId,
        title: r.title,
        block: r.block as AppStateData['routines'][number]['block'],
        anchorType:
          r.anchorType as AppStateData['routines'][number]['anchorType'],
        clockTime: r.clockTime,
        anchorOffsetMin: r.anchorOffsetMin,
        appliesOn: r.appliesOn as AppStateData['routines'][number]['appliesOn'],
        daysOfWeek: Array.isArray(r.daysOfWeek)
          ? (r.daysOfWeek as number[])
          : [1, 2, 3, 4, 5, 6, 7],
        isMust: r.isMust,
        targetValue: r.targetValue,
        stepValue: r.stepValue,
        unit: r.unit,
        checkpoints:
          (r.checkpoints as AppStateData['routines'][number]['checkpoints']) ||
          null,
        active: r.active,
        sortOrder: r.sortOrder,
      })),
      routineLogs: logRows.map((r) => ({
        id: r.id,
        userId: uid,
        routineId: r.routineId,
        logDate: r.logDate,
        status: r.status as AppStateData['routineLogs'][number]['status'],
        value: r.value,
        completedAt: r.completedAt ? r.completedAt.toISOString() : null,
      })),
      dailyReviews: dailyRevRows.map((r) => ({
        id: r.id,
        userId: uid,
        reviewDate: r.reviewDate,
        completedText: r.completedText,
        pendingText: r.pendingText,
        surpriseText: r.surpriseText,
        changeTomorrow: r.changeTomorrow,
      })),
      weeklyReviews: weeklyRevRows.map((r) => ({
        id: r.id,
        userId: uid,
        weekStart: r.weekStart,
        accomplishments: r.accomplishments,
        challenges: r.challenges,
        decisions: r.decisions,
        nextPriorities: r.nextPriorities,
      })),
      reminderSent: remSentRows.map((r) => ({
        id: r.id,
        userId: uid,
        logDate: r.logDate,
        itemKey: r.itemKey,
        nudgeNo: r.nudgeNo,
        batchId: r.batchId,
        sentAt: r.sentAt.toISOString(),
      })),
    };
  } catch (error) {
    console.error('Database getUserFullState failed:', error);
    throw new Error('Database query failed. Please try again later.', {
      cause: error,
    });
  }
}

export async function saveUserFullState(
  uid: string,
  email: string,
  state: AppStateData
): Promise<void> {
  try {
    await getOrCreateUser(uid, email);

    if (state.settings) {
      await db
        .insert(userSettings)
        .values({
          userId: uid,
          timezone: state.settings.timezone || 'Asia/Kolkata',
          wakeTime: state.settings.wakeTime || '06:30',
          quietStart: state.settings.quietStart || '23:00',
          quietEnd: state.settings.quietEnd || '06:00',
          dayRolloverHour: state.settings.dayRolloverHour ?? 4,
          dailyWorkloadMinutes: state.settings.dailyWorkloadMinutes ?? 120,
          dutyPromptTime: state.settings.dutyPromptTime || '06:45',
          reviewTime: state.settings.reviewTime || '21:30',
          maxRemindersPerDay: state.settings.maxRemindersPerDay ?? 8,
          pushEnabled: state.settings.pushEnabled ?? true,
          lastActiveDate: state.settings.lastActiveDate || null,
        })
        .onConflictDoUpdate({
          target: userSettings.userId,
          set: {
            timezone: state.settings.timezone || 'Asia/Kolkata',
            wakeTime: state.settings.wakeTime || '06:30',
            quietStart: state.settings.quietStart || '23:00',
            quietEnd: state.settings.quietEnd || '06:00',
            dayRolloverHour: state.settings.dayRolloverHour ?? 4,
            dailyWorkloadMinutes: state.settings.dailyWorkloadMinutes ?? 120,
            dutyPromptTime: state.settings.dutyPromptTime || '06:45',
            reviewTime: state.settings.reviewTime || '21:30',
            maxRemindersPerDay: state.settings.maxRemindersPerDay ?? 8,
            pushEnabled: state.settings.pushEnabled ?? true,
            lastActiveDate: state.settings.lastActiveDate || null,
            updatedAt: new Date(),
          },
        });
    }

    for (const area of state.lifeAreas || []) {
      await db
        .insert(lifeAreas)
        .values({
          id: area.id,
          userId: uid,
          name: area.name,
          description: area.description || null,
          status: area.status || 'active',
          sortOrder: area.sortOrder ?? 0,
        })
        .onConflictDoUpdate({
          target: lifeAreas.id,
          set: {
            name: area.name,
            description: area.description || null,
            status: area.status || 'active',
            sortOrder: area.sortOrder ?? 0,
            updatedAt: new Date(),
          },
        });
    }

    for (const item of state.inboxItems || []) {
      await db
        .insert(inboxItems)
        .values({
          id: item.id,
          userId: uid,
          content: item.content,
          status: item.status || 'new',
          itemType: item.itemType || 'unknown',
          source: item.source || 'manual',
          lifeAreaId: item.lifeAreaId || null,
          tags: Array.isArray(item.tags) ? item.tags : [],
          decisionNote: item.decisionNote || null,
          linkedEntityType: item.linkedEntityType || null,
          linkedEntityId: item.linkedEntityId || null,
          aiSuggestionJson: item.aiSuggestionJson || null,
          processedAt: item.processedAt ? new Date(item.processedAt) : null,
          archivedAt: item.archivedAt ? new Date(item.archivedAt) : null,
        })
        .onConflictDoUpdate({
          target: inboxItems.id,
          set: {
            content: item.content,
            status: item.status || 'new',
            itemType: item.itemType || 'unknown',
            lifeAreaId: item.lifeAreaId || null,
            tags: Array.isArray(item.tags) ? item.tags : [],
            decisionNote: item.decisionNote || null,
            linkedEntityType: item.linkedEntityType || null,
            linkedEntityId: item.linkedEntityId || null,
            aiSuggestionJson: item.aiSuggestionJson || null,
            processedAt: item.processedAt ? new Date(item.processedAt) : null,
            archivedAt: item.archivedAt ? new Date(item.archivedAt) : null,
            updatedAt: new Date(),
          },
        });
    }

    for (const link of state.inboxLinks || []) {
      await db
        .insert(inboxLinks)
        .values({
          id: link.id,
          userId: uid,
          inboxItemId: link.inboxItemId,
          targetType: link.targetType,
          targetId: link.targetId,
        })
        .onConflictDoNothing();
    }

    for (const goal of state.goals || []) {
      await db
        .insert(goals)
        .values({
          id: goal.id,
          userId: uid,
          lifeAreaId: goal.lifeAreaId,
          title: goal.title,
          desiredOutcome: goal.desiredOutcome || null,
          purposeReason: goal.purposeReason || null,
          ownershipReflection: goal.ownershipReflection || null,
          evidenceOfProgress: goal.evidenceOfProgress || null,
          controlNotes: goal.controlNotes || null,
          tradeoffs: goal.tradeoffs || null,
          capacityNotes: goal.capacityNotes || null,
          tags: Array.isArray(goal.tags) ? goal.tags : [],
          goalType: goal.goalType || 'outcome',
          status: goal.status || 'candidate',
          targetDate: goal.targetDate || null,
          reviewDate: goal.reviewDate || null,
          reviewCadence: goal.reviewCadence || 'weekly',
          originInboxItemId: goal.originInboxItemId || null,
        })
        .onConflictDoUpdate({
          target: goals.id,
          set: {
            lifeAreaId: goal.lifeAreaId,
            title: goal.title,
            desiredOutcome: goal.desiredOutcome || null,
            purposeReason: goal.purposeReason || null,
            ownershipReflection: goal.ownershipReflection || null,
            evidenceOfProgress: goal.evidenceOfProgress || null,
            controlNotes: goal.controlNotes || null,
            tradeoffs: goal.tradeoffs || null,
            capacityNotes: goal.capacityNotes || null,
            tags: Array.isArray(goal.tags) ? goal.tags : [],
            goalType: goal.goalType || 'outcome',
            status: goal.status || 'candidate',
            targetDate: goal.targetDate || null,
            reviewDate: goal.reviewDate || null,
            reviewCadence: goal.reviewCadence || 'weekly',
            updatedAt: new Date(),
          },
        });
    }

    for (const proj of state.projects || []) {
      await db
        .insert(projects)
        .values({
          id: proj.id,
          userId: uid,
          goalId: proj.goalId || null,
          lifeAreaId: proj.lifeAreaId || null,
          title: proj.title,
          description: proj.description || null,
          status: proj.status || 'active',
          originInboxItemId: proj.originInboxItemId || null,
        })
        .onConflictDoUpdate({
          target: projects.id,
          set: {
            goalId: proj.goalId || null,
            lifeAreaId: proj.lifeAreaId || null,
            title: proj.title,
            description: proj.description || null,
            status: proj.status || 'active',
            updatedAt: new Date(),
          },
        });
    }

    for (const ms of state.milestones || []) {
      await db
        .insert(milestones)
        .values({
          id: ms.id,
          userId: uid,
          goalId: ms.goalId,
          title: ms.title,
          description: ms.description || null,
          status: ms.status || 'todo',
          seq: ms.seq ?? 0,
        })
        .onConflictDoUpdate({
          target: milestones.id,
          set: {
            title: ms.title,
            description: ms.description || null,
            status: ms.status || 'todo',
            seq: ms.seq ?? 0,
            updatedAt: new Date(),
          },
        });
    }

    for (const task of state.tasks || []) {
      await db
        .insert(tasks)
        .values({
          id: task.id,
          userId: uid,
          goalId: task.goalId || null,
          milestoneId: task.milestoneId || null,
          projectId: task.projectId || null,
          parentTaskId: task.parentTaskId || null,
          originInboxItemId: task.originInboxItemId || null,
          title: task.title,
          nextAction: task.nextAction || null,
          status: task.status || 'todo',
          estMinutes: task.estMinutes ?? null,
          dueDate: task.dueDate || null,
          scheduledDate: task.scheduledDate || null,
          rescheduleCount: task.rescheduleCount ?? 0,
          completedAt: task.completedAt ? new Date(task.completedAt) : null,
        })
        .onConflictDoUpdate({
          target: tasks.id,
          set: {
            goalId: task.goalId || null,
            milestoneId: task.milestoneId || null,
            projectId: task.projectId || null,
            title: task.title,
            nextAction: task.nextAction || null,
            status: task.status || 'todo',
            estMinutes: task.estMinutes ?? null,
            dueDate: task.dueDate || null,
            scheduledDate: task.scheduledDate || null,
            rescheduleCount: task.rescheduleCount ?? 0,
            completedAt: task.completedAt ? new Date(task.completedAt) : null,
            updatedAt: new Date(),
          },
        });
    }

    for (const dp of state.dayPlans || []) {
      const dpId = dp.id || `${uid}_${dp.planDate}`;
      await db
        .insert(dayPlans)
        .values({
          id: dpId,
          userId: uid,
          planDate: dp.planDate,
          isOff: dp.isOff ?? false,
          dutyStart: dp.dutyStart || null,
          minimumDay: dp.minimumDay ?? false,
          mainTaskId: dp.mainTaskId || null,
          locked: dp.locked ?? false,
        })
        .onConflictDoUpdate({
          target: dayPlans.id,
          set: {
            isOff: dp.isOff ?? false,
            dutyStart: dp.dutyStart || null,
            minimumDay: dp.minimumDay ?? false,
            mainTaskId: dp.mainTaskId || null,
            locked: dp.locked ?? false,
            updatedAt: new Date(),
          },
        });
    }

    for (const rt of state.routines || []) {
      await db
        .insert(routines)
        .values({
          id: rt.id,
          userId: uid,
          goalId: rt.goalId || null,
          originInboxItemId: rt.originInboxItemId || null,
          title: rt.title,
          block: rt.block || 'anytime',
          anchorType: rt.anchorType || 'clock',
          clockTime: rt.clockTime || null,
          anchorOffsetMin: rt.anchorOffsetMin ?? 0,
          appliesOn: rt.appliesOn || 'all',
          daysOfWeek: rt.daysOfWeek || [1, 2, 3, 4, 5, 6, 7],
          isMust: rt.isMust ?? false,
          targetValue: rt.targetValue ?? null,
          stepValue: rt.stepValue ?? null,
          unit: rt.unit || null,
          checkpoints: rt.checkpoints || null,
          active: rt.active ?? true,
          sortOrder: rt.sortOrder ?? 0,
        })
        .onConflictDoUpdate({
          target: routines.id,
          set: {
            title: rt.title,
            block: rt.block || 'anytime',
            anchorType: rt.anchorType || 'clock',
            clockTime: rt.clockTime || null,
            anchorOffsetMin: rt.anchorOffsetMin ?? 0,
            appliesOn: rt.appliesOn || 'all',
            daysOfWeek: rt.daysOfWeek || [1, 2, 3, 4, 5, 6, 7],
            isMust: rt.isMust ?? false,
            targetValue: rt.targetValue ?? null,
            stepValue: rt.stepValue ?? null,
            unit: rt.unit || null,
            checkpoints: rt.checkpoints || null,
            active: rt.active ?? true,
            sortOrder: rt.sortOrder ?? 0,
            updatedAt: new Date(),
          },
        });
    }

    // Replace today's / active routine logs cleanly
    await db.delete(routineLogs).where(eq(routineLogs.userId, uid));
    for (const log of state.routineLogs || []) {
      if (log.value <= 0 && log.status !== 'done' && log.status !== 'skipped') {
        continue;
      }
      await db
        .insert(routineLogs)
        .values({
          id: log.id || `${log.routineId}_${log.logDate}`,
          userId: uid,
          routineId: log.routineId,
          logDate: log.logDate,
          status: log.status,
          value: log.value ?? 0,
          completedAt: log.completedAt ? new Date(log.completedAt) : null,
        })
        .onConflictDoUpdate({
          target: routineLogs.id,
          set: {
            status: log.status,
            value: log.value ?? 0,
            completedAt: log.completedAt ? new Date(log.completedAt) : null,
            updatedAt: new Date(),
          },
        });
    }

    for (const dr of state.dailyReviews || []) {
      await db
        .insert(dailyReviews)
        .values({
          id: dr.id || `${uid}_${dr.reviewDate}`,
          userId: uid,
          reviewDate: dr.reviewDate,
          completedText: dr.completedText || null,
          pendingText: dr.pendingText || null,
          surpriseText: dr.surpriseText || null,
          changeTomorrow: dr.changeTomorrow || null,
        })
        .onConflictDoUpdate({
          target: dailyReviews.id,
          set: {
            completedText: dr.completedText || null,
            pendingText: dr.pendingText || null,
            surpriseText: dr.surpriseText || null,
            changeTomorrow: dr.changeTomorrow || null,
            updatedAt: new Date(),
          },
        });
    }

    for (const wr of state.weeklyReviews || []) {
      await db
        .insert(weeklyReviews)
        .values({
          id: wr.id || `${uid}_${wr.weekStart}`,
          userId: uid,
          weekStart: wr.weekStart,
          accomplishments: wr.accomplishments || null,
          challenges: wr.challenges || null,
          decisions: wr.decisions || null,
          nextPriorities: wr.nextPriorities || null,
        })
        .onConflictDoUpdate({
          target: weeklyReviews.id,
          set: {
            accomplishments: wr.accomplishments || null,
            challenges: wr.challenges || null,
            decisions: wr.decisions || null,
            nextPriorities: wr.nextPriorities || null,
            updatedAt: new Date(),
          },
        });
    }
  } catch (error) {
    console.error('Database saveUserFullState failed:', error);
    throw new Error('Database save failed. Please try again later.', {
      cause: error,
    });
  }
}
