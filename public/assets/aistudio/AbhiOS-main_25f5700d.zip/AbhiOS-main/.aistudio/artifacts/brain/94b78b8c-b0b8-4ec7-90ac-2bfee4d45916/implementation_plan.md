# Personal Goal OS (V2 — Brain Dump First + Quality-Gated Goals)

A personal growth and daily execution operating system built around a strict **Capture → Clarify → Classify → Decide → Plan → Execute → Review → Adjust** pipeline. Every fleeting thought enters a friction-free Universal Brain Dump in under five seconds without obligation, and must earn active commitment through structured triage and an adaptive Goal Quality Gate.

### User Review & Critical Decisions

> [!IMPORTANT]
> **Confirmed Decisions from Phase 1 Alignment:**
> - **Database & Authentication**: **Cloud SQL (PostgreSQL) with Firebase Authentication** (Google Sign-In), backed by Drizzle ORM and strict per-user ownership isolation on every query and mutation, plus a full local/offline resilience layer and JSON Export/Import backup.
> - **Build Scope**: **Complete End-to-End V2 Architecture** implemented in a cohesive, production-ready system covering Brain Dump Capture, 10-Category Triage Queue, Adaptive Goal Quality Gate, Life Areas & Goals/Projects/Milestones, Today Execution (Duty/Off-Day, Minimum Viable Day, Routines, Water Tracker), Guilt-Free Daily/Weekly Reviews & Gap Re-entry, Reminder Engine, and JSON Backup/Restore.
> - **Dual-Mode AI Architecture (100% Manual + Optional Gemini AI)**: The entire operating system works 100% deterministically when AI is disabled or unconfigured. When `GEMINI_API_KEY` is active, server-side Gemini (`gemini-3.8-flash`) enhances Inbox Clarification, Goal Candidate Quality Gate refinement, Goal Breakdown, Task Splitting, and Daily Priority Explanations—always labelled as *"AI Sujhaav — Aapke Approval Ke Liye"* with zero automatic state mutations.
> - **UI Language**: **Hinglish UI Labels** (`Aaj`, `+ Brain Dump`, `Goal Candidate Banao`, `Minimum Day`, `Ho Gaya`, `+250 ml`, `Daily Review Karo`, `Someday / Maybe`) centralized in a clean localization dictionary.

---

### 1. Overview & Core Concept

- **What It Does**: Personal Goal OS separates *thinking* from *committing*. Users dump raw thoughts, worries, ideas, tasks, or wishes into a Universal Inbox in seconds. When ready, they clarify one item at a time into 10 distinct item types (Task, Goal Candidate, Project, Habit Candidate, Reference, Idea, Someday/Maybe, Concern, Waiting For, or Trash). Thoughts that might be goals enter a **Goal Quality Gate**—a 9-point reflection framework checking personal reason, ownership, trade-offs, capacity, and horizon—before becoming an Active Goal. Daily execution on the **Aaj (Today)** screen adapts dynamically to shift/duty schedules (`Duty Start` vs `Off Day`), hydration checkpoints (`2500 ml` in `250 ml` steps), and low-energy days (`Minimum Viable Day`).
- **Target Audience / Persona**: Single-user personal productivity system for Abhishek (Android mobile-first PWA + full multi-column desktop workspace), tailored for shift/duty-aware daily routines and mindful long-term personal growth.
- **Key Value**: Eliminates calendar bloat, abandoned goal graveyards, and streak guilt. Capturing a thought never creates an automatic deadline or obligation, and returning after a multi-day gap offers a one-tap fresh start (`Wapas swagat. Aaj se fresh start.`).

---

### 2. User Experience & Visual Design

- **Key User Flows**:
  1. **5-Second Brain Dump (`+ Brain Dump`)**: Persistent quick-capture button in the natural thumb zone opens a focused multiline input sheet. Pressing Save immediately stores the raw text into `Unprocessed` Inbox with timestamp and source, shows a subtle toast confirmation, and clears the field for the next thought—no category, life area, or date required.
  2. **One-by-One Inbox Triage (`Brain Dump / Inbox`)**: Filterable across `Unprocessed`, `Waiting`, `Someday/Maybe`, and `Processed/Archived`. Users can process items individually or in a focused single-item Clarify Queue: edit wording, split one rambling note into multiple distinct items, merge duplicates, defer (`Abhi Nahi / Not Sure Yet`), archive, reversible trash with undo, or classify into any of the 10 item types with provenance links preserved. Optional *"AI Sujhaav"* proposes category, refined title, and next action as a draft.
  3. **Goal Quality Gate (`Consider as Goal` → `Goal Candidate`)**: Selecting Goal Candidate opens an adaptive reflection sheet covering the 9 core checks: Desired Outcome, Personal Reason, Ownership check (intrinsic vs external pressure), Evidence of Progress, Control boundary, Cost/Trade-offs, Capacity & Minimum Next Action, Horizon (`Time-Bound Outcome` vs `Ongoing Direction`), and Classification Check. Users explicitly choose one of 6 outcomes: *Accept as Active Goal*, *Refine*, *Convert to Project/Task/Habit*, *Move to Someday/Maybe*, *Keep as Idea/Reference*, or *Decline/Archive*. Large commitments show a gentle *"Kal phir dekhein / Sleep on it"* advisory (never a hard block), and >5 active goals triggers a soft capacity warning.
  4. **Mindful Planning (`Goals` & `Tasks`)**: Active goals are grouped by customizable Life Areas (`Health`, `Career & Duty`, `Finance`, `Learning`, `Personal`) while `Candidates` and `Someday/Maybe` sit in separate clean tabs. Simple goals link directly to Next Actions; complex goals optionally use Milestones (checkpoints) and Projects (bounded multi-step work). Every task includes a quality hint: *"Kya tum bina aur planning ke ye shuru kar sakte ho?"*
  5. **Context-Aware Execution (`Aaj / Today`)**:
     - **Context Header**: Local date calculated with `Asia/Kolkata` timezone + `day_rollover_hour` (default `04:00 AM` so 2:30 AM night-duty still counts as the current logical day), `Duty HH:MM` / `Off Day` toggle, and `Minimum Day` toggle.
     - **Needs Attention Banner**: Surfaces overdue tasks (<14 days), stale tasks (≥14 days flagged for review rather than auto-prioritized), due-soon items,inbox items older than 2 days (informational count only), and goals due for review.
     - **Main Priority Card**: Highlights the single highest-impact task for today, with deterministic scoring (`suggestMainPriority`) and workload-aware day budgeting (`suggestDayTasks` with 20% buffer).
     - **Routines & Hydration**: Grouped into `Morning`, `Duty`, `Evening`, and `Anytime` blocks with anchor offsets (`Clock`, `Wake Time`, or `Duty Start - 90m`). When `Minimum Day` is ON, only `is_must` routines and the Main Priority display. The Water Card tracks `ml` progress against `2500 ml` target with `[+250 ml]`, `[+500 ml]`, `[Undo]`, and time checkpoints (`11:00`, `14:00`, `18:00`).
  6. **Guilt-Free Reviews & Re-Entry (`Daily Review`, `Weekly Review`, `Fresh Start`)**: Evening close-out auto-summarizes completed routines and tasks, offering 4 friction-free buttons for each pending task (`Kal Karo`, `Reschedule`, `Chhota Karo / Split`, `Cancel`) plus reflection notes. Weekly review checks active goals, life-area balance, and next week's 3 priorities. If >3 days have elapsed since last activity, a warm Re-entry banner offers one-tap cleanup of old overdue tasks without streak penalties.

- **Visual Identity & Theme**:
  - **Aesthetic Direction**: Calm, tactile, high-craft utilitarian workspace combining mobile thumb-zone ergonomics with structured desktop multi-column clarity. Zero decorative AI slop, zero fake telemetry, and zero guilt-inducing red alarm counters.
  - **Color Palette & 60-30-10 Mood**:
    - *60% Dominant Canvas*: Crisp alabaster slate (`#F8FAFC`) in Light Mode; deep obsidian slate (`#0B0F17`) in Dark Mode.
    - *30% Structural Surfaces*: Elevated cards (`#FFFFFF` light / `#111827` dark) with subtle hairline borders (`1px solid #E2E8F0` light / `#1E293B` dark) and muted slate prose (`#475569` light / `#94A3B8` dark).
    - *10% High-Intent Accents*: Deep Indigo/Teal (`#0F766E` / `#14B8A6`) for primary CTAs and active states; Warm Amber (`#D97706`) for review nudges and trade-off reflections; Emerald (`#16A34A`) for completed actions; Sky Blue (`#0284C7`) for hydration progress.
  - **Typography & Hierarchy**:
    - *Display & Section Headings*: `Plus Jakarta Sans` (SemiBold 600 / Bold 700, `text-wrap: balance`) for crisp, modern structural authority.
    - *Body & Hinglish Labels*: `DM Sans` (Regular 400 / Medium 500, 16px input size to prevent mobile auto-zoom, generous line height).
    - *Timestamps, Metrics & Water/Time Counters*: `JetBrains Mono` with `font-variant-numeric: tabular-nums` so times (`06:45`, `1500 / 2500 ml`, `-90 min`) align vertically without jitter.
  - **Component Styling & Ergonomics**:
    - **Zero-Pill Metadata Discipline**: Task metadata (life area, due date, time estimate, provenance link, routine anchor) renders as clean, unboxed inline text separated by `·` (`Career · Due Kal · 30m · From Brain Dump`). Interactive filter tabs (`Unprocessed | Waiting | Someday/Maybe | Processed`) use segmented `<button>` controls.
    - **Thumb-Zone & Sticky Cap**: Every interactive target is at least `44x44px`. Sticky top bar + fixed bottom navigation stay strictly under the 15% mobile viewport cap, while expanding to a full `max-w-7xl` multi-column layout on desktop screens (`1440px`).
- **Interactive Feedback & Motion**:
  - Optimistic UI updates (<150ms) on routine checkboxes, water increments (`+250 ml`), and quick capture saves, with automatic rollback and toast notification on network error.
  - Smooth slide-up bottom sheets (`cubic-bezier(0.16, 1, 0.3, 1)`) for Brain Dump capture, Goal Quality Gate wizard, and Task Split drawers.

---

### 3. Key Product Decisions & Trade-Offs

- **Decision 1: Cloud SQL (PostgreSQL + Drizzle ORM) + Local Offline Cache & JSON Portability**
  - *Chosen Approach*: Primary relational persistence in AI Studio's managed Cloud SQL PostgreSQL with Firebase Auth verification, paired with automatic client-side state caching and one-click JSON Export/Import (`validateImport` + `merge` / `replace-empty`).
  - *Why*: Preserves the relational integrity of your SQL schema (composite ownership checks, provenance links between `inbox_items`, `goals`, `projects`, `milestones`, and `tasks`) while ensuring the app works smoothly and remains 100% portable via JSON backups.
  - *Alternatives Considered*: Pure browser storage (lacks cross-device cloud sync) or unstructured NoSQL (harder to enforce relational provenance and milestone-goal constraints).

- **Decision 2: Strict Separation of Goal Candidates vs Active Goals**
  - *Chosen Approach*: Storing Goal Candidates with `status = 'candidate'` and dedicated reflection columns (`desired_outcome`, `purpose_reason`, `ownership_reflection`, `evidence_of_progress`, `control_notes`, `tradeoffs`, `goal_type`, `origin_inbox_item_id`). Candidates are excluded from the Today planner and active goal count until explicitly promoted by the user.
  - *Why*: Directly enforces the V2 rule that *"A thought must earn goal status"* and prevents ambitious thoughts from polluting daily execution before trade-offs are accepted.

- **Decision 3: Dual-Mode AI Assistant (Deterministic Rules First + Optional Server-Side Gemini)**
  - *Chosen Approach*: Every feature (Inbox triage, Goal Quality Gate questionnaire, Priority scoring, Task splitting, Daily/Weekly review) runs on pure deterministic logic (`lib/logic/planner.ts`, `lib/logic/attention.ts`, `lib/logic/quality-gate.ts`). In parallel, `/api/ai/suggest` checks if `process.env.GEMINI_API_KEY` is configured; if available, users can click **"AI Sujhaav Lo"** to generate structured JSON drafts for inbox classification, goal refinement, milestone breakdown, or task splitting.
  - *Why*: Guarantees 100% reliability when offline or without an API key, while providing intelligent, schema-validated assistance when Gemini is active—never auto-committing changes without explicit user approval.

---

### 4. Technical Architecture & Data Strategy *(Technical Reference)*

- **Architecture & Component Diagram**:

```
┌──────────────────────────────────────────────────────────────────────────────────┐
│                        PERSONAL GOAL OS (PWA CLIENT)                             │
│  ┌────────────────┐  ┌─────────────────────────┐  ┌───────────────────────────┐  │
│  │ Top Bar /      │  │ Persistent "+ Brain     │  │ PWA Install & Offline     │  │
│  │ Context Strip  │  │ Dump" 5s Capture Sheet  │  │ Sync / Notification Manager│  │
│  └───────┬────────┘  └────────────┬────────────┘  └─────────────┬─────────────┘  │
│          │                        │                             │                │
│  ┌───────▼────────────────────────▼─────────────────────────────▼─────────────┐  │
│  │                     5 PRIMARY VIEWS (Bottom Nav / Sidebar)                 │  │
│  │  1. Aaj (Today)       2. Brain Dump (Inbox)   3. Tasks (All States)        │  │
│  │     - Duty/Off Chip      - Unprocessed Queue     - Aaj / Aane Wale         │  │
│  │     - Min Day Toggle     - Clarify & 10 Types    - Bina Date / Done        │  │
│  │     - Attention Alert    - Split / Merge / Defer - Split / Reschedule      │  │
│  │     - Main Priority      - Provenance Links                                │  │
│  │     - Routines & Water                        4. Goals & Quality Gate      │  │
│  │     - Daily Review   5. Settings & Backup        - Candidate Gate Wizard   │  │
│  │     - Re-Entry Flow     - Timezone & Rollover    - Active by Life Area     │  │
│  │                         - Routines Manager       - Projects & Milestones   │  │
│  │                         - Push & JSON Export     - Weekly Review Sheet     │  │
│  └───────┬────────────────────────┬─────────────────────────────┬─────────────┘  │
│          │                        │                             │                │
│  ┌───────▼────────────────────────▼─────────────────────────────▼─────────────┐  │
│  │                PURE DOMAIN LOGIC LAYER (Zero DOM / Unit Tested)            │  │
│  │  • dates.ts (Rollover & TZ)     • planner.ts (Priority & 80% Budget)       │  │
│  │  • attention.ts (Overdue/Stale) • tick-logic.ts (Quiet Hours/Nudge/Digest) │  │
│  │  • quality-gate.ts (9-Question Adaptive Gate & Classification Rules)       │  │
│  └────────────────────────────────┬───────────────────────────────────────────┘  │
└───────────────────────────────────┼──────────────────────────────────────────────┘
                                    │ HTTPS Fetch (Bearer Firebase ID Token)
┌───────────────────────────────────▼──────────────────────────────────────────────┐
│                         NEXT.JS SERVER API ROUTES (/api/*)                       │
│  ┌────────────────────────┐ ┌─────────────────────────┐ ┌─────────────────────┐  │
│  │ /api/state & /api/sync │ │ /api/cron/tick &        │ │ /api/ai/suggest     │  │
│  │ - Auth Verification    │ │ /api/done (HMAC Signed) │ │ - Server-side Gemini│  │
│  │ - Drizzle ORM CRUD     │ │ - Reminder Dedupe & Cap │ │ - Strict JSON Schema│  │
│  │ - Export / Import JSON │ │ - Web Push Dispatch     │ │ - Graceful Fallback │  │
│  └───────────┬────────────┘ └────────────┬────────────┘ └──────────┬──────────┘  │
└──────────────┼───────────────────────────┼─────────────────────────┼─────────────┘
               │                           │                         │
               ▼                           ▼                         ▼
┌──────────────────────────────┐ ┌──────────────────────┐ ┌────────────────────────┐
│ Cloud SQL (PostgreSQL)       │ │ Web Push / Service   │ │ Google Gemini API      │
│ via Drizzle ORM (15 Tables)  │ │ Worker Notifications │ │ (gemini-3.8-flash)     │
└──────────────────────────────┘ └──────────────────────┘ └────────────────────────┘
```

- **Data Model & State (Extended V2 PostgreSQL Schema via Drizzle ORM)**:
  1. `users`: `id`, `uid` (Firebase UID, unique), `email`, `created_at`.
  2. `user_settings`: `user_id`, `timezone` (`'Asia/Kolkata'`), `wake_time` (`'06:30'`), `quiet_start` (`'23:00'`), `quiet_end` (`'06:00'`), `day_rollover_hour` (`4`), `daily_workload_minutes` (`120`), `duty_prompt_time` (`'06:45'`), `review_time` (`'21:30'`), `max_reminders_per_day` (`8`), `push_enabled`, `last_active_date`.
  3. `inbox_items` (V2 Extended): `id`, `user_id`, `content`, `status` (`'new' | 'processing' | 'waiting' | 'processed' | 'someday' | 'archived' | 'trash'`), `item_type` (`'unknown' | 'task' | 'goal_candidate' | 'project' | 'habit_candidate' | 'reference' | 'idea' | 'concern' | 'waiting_for' | 'duplicate'`), `source` (`'manual' | 'quick_capture' | 'split'`), `decision_note`, `linked_entity_type`, `linked_entity_id`, `ai_suggestion_json`, `processed_at`, `archived_at`, `created_at`, `updated_at`.
  4. `inbox_links` (Provenance Table for Splits & Multi-Outputs): `id`, `user_id`, `inbox_item_id`, `target_type` (`'task' | 'goal' | 'project' | 'routine'`), `target_id`, `created_at`.
  5. `life_areas`: `id`, `user_id`, `name`, `description`, `status` (`'active' | 'archived'`), `sort_order`.
  6. `goals` (V2 Quality-Gated): `id`, `user_id`, `life_area_id`, `title`, `desired_outcome`, `purpose_reason`, `ownership_reflection`, `evidence_of_progress`, `control_notes`, `tradeoffs`, `goal_type` (`'outcome' | 'ongoing_direction'`), `status` (`'candidate' | 'active' | 'paused' | 'completed' | 'archived'`), `target_date` (nullable), `review_date`, `review_cadence` (`'weekly' | 'biweekly' | 'monthly'`), `origin_inbox_item_id`, `created_at`, `updated_at`.
  7. `projects` (V2 Bounded Work): `id`, `user_id`, `goal_id` (nullable), `life_area_id` (nullable), `title`, `description`, `status` (`'active' | 'paused' | 'completed' | 'archived'`), `origin_inbox_item_id`, `created_at`, `updated_at`.
  8. `milestones` (Checkpoints): `id`, `user_id`, `goal_id`, `title`, `description`, `status` (`'todo' | 'doing' | 'done' | 'dropped'`), `seq`.
  9. `tasks`: `id`, `user_id`, `goal_id` (nullable), `milestone_id` (nullable), `project_id` (nullable), `parent_task_id` (nullable), `origin_inbox_item_id` (nullable), `title`, `next_action`, `status` (`'todo' | 'doing' | 'done' | 'paused' | 'cancelled'`), `est_minutes`, `due_date`, `scheduled_date`, `reschedule_count`, `completed_at`.
  10. `day_plans`: `(user_id, plan_date)` PK, `is_off`, `duty_start`, `minimum_day`, `main_task_id`, `locked`.
  11. `routines`: `id`, `user_id`, `goal_id` (nullable optional link), `origin_inbox_item_id` (nullable), `title`, `block` (`'morning' | 'duty' | 'evening' | 'anytime'`), `anchor_type` (`'clock' | 'wake' | 'duty_start'`), `clock_time`, `anchor_offset_min`, `applies_on` (`'all' | 'duty_days' | 'off_days'`), `days_of_week`, `is_must`, `target_value`, `step_value`, `unit`, `checkpoints` (JSONB), `active`, `sort_order`.
  12. `routine_logs`: `id`, `user_id`, `routine_id`, `log_date`, `status` (`'partial' | 'done' | 'skipped'`), `value`, `completed_at`.
  13. `daily_reviews` & `weekly_reviews`: Structured review tables storing auto-filled completion summaries, pending resolutions, unexpected events, and next priorities.
  14. `reminder_sent` & `push_subscriptions`: Deduplication log (`user_id, log_date, item_key, nudge_no`, `batch_id`) and Web Push VAPID endpoints.

- **Interactive Component & State Mapping**:
  - **Quick Capture Modal / Bar**: Validates non-empty text, preserves line breaks, saves immediately to `inbox_items` with `status: 'new', item_type: 'unknown'`, increments Unprocessed badge, and resets input focus.
  - **Inbox Triage & Split/Merge Handlers**:
    - *Split*: Opens a multi-row editor pre-populated with lines from the original thought; creates $N$ new `inbox_items` (or direct tasks) linked via `inbox_links` and marks the parent `processed`.
    - *Merge*: Combines selected duplicate items into one consolidated note and moves the redundant item to `trash` with one-tap Undo.
    - *Classify & Decide*: Updates `item_type` and transitions item to `processed` (when creating a Task/Project/Routine), `goal_candidate` (opening the Quality Gate), `waiting`, `someday`, or `archived` (for Reference/Idea/Concern).
  - **Goal Quality Gate Wizard**: Adaptive 3-step reflection card (`1. Outcome & Personal Why`, `2. Ownership, Control & Trade-offs`, `3. Horizon & First Next Action`). Computes readiness hints and enables the 6 explicit outcome buttons. Choosing *Accept as Active Goal* transitions `status` from `'candidate'` to `'active'`, sets `review_date`, and optionally creates the initial Next Action task.
  - **Today Execution & Timezone Engine**: Computes `todayLocal(timezone, rolloverHour)` using `Intl.DateTimeFormat`. Toggling `Duty Start` or `Off Day` immediately recalculates routine due times (`anchor_type === 'duty_start'`) and filters routines (`applies_on`). Toggling `Minimum Day` filters the view to `is_must` routines + `Main Priority`.
  - **AI Suggestion Proxy (`/api/ai/suggest`)**: Accepts `mode` (`'inbox_clarify' | 'goal_gate_assist' | 'goal_breakdown' | 'task_split' | 'priority_explain'`). Returns `{ aiAvailable: boolean, suggestion: ... }`. If `GEMINI_API_KEY` is missing or errors, returns `{ aiAvailable: false, fallbackReason: ... }` so the UI smoothly continues with deterministic manual controls without crashing.
